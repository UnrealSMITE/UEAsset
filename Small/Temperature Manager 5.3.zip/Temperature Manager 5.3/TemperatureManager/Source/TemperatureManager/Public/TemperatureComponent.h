// Copyright (C) LIDEV. 2023. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "Components/ActorComponent.h"
#include "TemperatureManagerCommon.h"
#include "TemperatureComponent.generated.h"

DECLARE_DYNAMIC_MULTICAST_DELEGATE_OneParam(FOnTemperatureUpdated, float, NewTemperature);
DECLARE_DYNAMIC_MULTICAST_DELEGATE_OneParam(FOnTempActorUpdated, AActor*, NewTempActor);
DECLARE_DYNAMIC_MULTICAST_DELEGATE(FOnTempStateUpdated);


UCLASS(ClassGroup = (Custom), meta = (BlueprintSpawnableComponent))
class TEMPERATUREMANAGER_API UTemperatureComponent : public UActorComponent
{
	GENERATED_BODY()

public:
	// Sets default values for this component's properties
	UTemperatureComponent();

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "TemperatureManager | Config")
	float UpdateInterval = 0.1f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "TemperatureManager | Config")
	TEnumAsByte<ETempActorType> TempActorType = ETempActorType::TempReceiver;

	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "TemperatureManager | Temperature")
	float CurrentTemp = 0;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "TemperatureManager | Temperature")
	float MinTemp = 0;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "TemperatureManager | Temperature")
	float MaxTemp = 100;	

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "TemperatureManager | Temperature")
	float IncreaseRangeMin = 0.1;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "TemperatureManager | Temperature")
	float IncreaseRangeMax = 0.5;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "TemperatureManager | Temperature")
	float DropRangeMin = 0.1;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "TemperatureManager | Temperature")
	float DropRangeMax = 0.5;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "TemperatureManager | Temperature")
	float DefaultDropTempMultiplier = 1;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "TemperatureManager | Temperature")
	float DefaultIncreaseTempMultiplier = 1;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "TemperatureManager | Temperature")
	TEnumAsByte<EIdleTempStatus> IdleTempStatus = EIdleTempStatus::Idle;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "TemperatureManager | FluctuateTemperature")
	bool CanFluctuateTemp;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "TemperatureManager | FluctuateTemperature")
	float FluctuateDelay = 5;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "TemperatureManager | FluctuateTemperature")
	float FluctuateTempRange = 3;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "TemperatureManager | TempSource")
	float IncreaseImpactRangeMin = 0.1;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "TemperatureManager | TempSource")
	float IncreaseImpactRangeMax = 0.5;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "TemperatureManager | TempSource")
	float DropImpactRangeMin = 0.1;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "TemperatureManager | TempSource")
	float DropImpactRangeMax = 0.5;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "TemperatureManager | TempSource")
	TArray<AActor*> ActorsToImpact;


	// INTERNAL
	UPROPERTY(BlueprintReadOnly, Category = "TemperatureManager | Internal")
	bool IsDroppingTemp;

	UPROPERTY(BlueprintReadOnly, Category = "TemperatureManager | Internal")
	bool IsIncreasingTemp;

	UPROPERTY(BlueprintReadOnly, Category = "TemperatureManager | Internal")
	bool IsIdleTemp;

	UPROPERTY(BlueprintReadOnly, Category = "TemperatureManager | Internal")
	bool IsFluctuatingTemp;

	UPROPERTY(BlueprintReadOnly, Category = "TemperatureManager | Internal")
	float DropTempMultiplier = 1;

	UPROPERTY(BlueprintReadOnly, Category = "TemperatureManager | Internal")
	float IncreaseTempMultiplier = 1;

	UPROPERTY(BlueprintReadOnly, Category = "TemperatureManager | Internal")
	AActor* CurrentAssignedTempSource;

	UPROPERTY()
	FTimerHandle DroppingTempTimerHandle;

	UPROPERTY()
	FTimerHandle IncreasingTempTimerHandle;

	UPROPERTY()
	FTimerHandle FluctuateTempTimerHandle;

	UPROPERTY()
	FTimerHandle UpdateTempTimerHandle;


	// DELEGATES 
	UPROPERTY(BlueprintAssignable, Category = "TemperatureManager | Delegates")
	FOnTemperatureUpdated OnTemperatureUpdated;

	UPROPERTY(BlueprintAssignable, Category = "TemperatureManager | Delegates")
	FOnTempActorUpdated OnTempSourceActorUpdated;

	UPROPERTY(BlueprintAssignable, Category = "TemperatureManager | Delegates")
	FOnTempActorUpdated OnTempActorsToImpactUpdated;

	UPROPERTY(BlueprintAssignable, Category = "TemperatureManager | Delegates")
	FOnTempStateUpdated OnTempIncreaseStarted;

	UPROPERTY(BlueprintAssignable, Category = "TemperatureManager | Delegates")
	FOnTempStateUpdated OnTempDropStarted;

	UPROPERTY(BlueprintAssignable, Category = "TemperatureManager | Delegates")
	FOnTempStateUpdated OnTempDropStopped;

	UPROPERTY(BlueprintAssignable, Category = "TemperatureManager | Delegates")
	FOnTempStateUpdated OnTempIncreaseStopped;

	UPROPERTY(BlueprintAssignable, Category = "TemperatureManager | Delegates")
	FOnTempStateUpdated OnTempFluctuateStarted;

	UPROPERTY(BlueprintAssignable, Category = "TemperatureManager | Delegates")
	FOnTempStateUpdated OnTempIdle;


protected:
	// Called when the game starts
	virtual void BeginPlay() override;


public:
	// Called every frame
	virtual void TickComponent(float DeltaTime, ELevelTick TickType, FActorComponentTickFunction* ThisTickFunction) override;

	UFUNCTION()
	virtual void UpdateTemperature();

	UFUNCTION(BlueprintCallable, Category = "TemperatureManager")
	virtual void SetCurrentTemp(const float& NewTemp);

	UFUNCTION(BlueprintCallable, Category = "TemperatureManager")
	virtual void SetIdleTempStatus(const EIdleTempStatus& NewStatus);

	UFUNCTION(BlueprintCallable, Category = "TemperatureManager")
	virtual void StartIdleTemperature();

	UFUNCTION(BlueprintCallable, Category = "TemperatureManager")
	virtual void StartFluctuateTemperature();

	UFUNCTION(BlueprintCallable, Category = "TemperatureManager")
	virtual void StartDropTemperature(const float& TempMultiplierValue, const float& DelayToStartIdle);

	UFUNCTION(BlueprintCallable, Category = "TemperatureManager")
	virtual void StopDropTemperature();

	UFUNCTION(BlueprintCallable, Category = "TemperatureManager")
	virtual void StartIncreaseTemperature(const float& TempMultiplierValue, const float& DelayToStartIdle);

	UFUNCTION(BlueprintCallable, Category = "TemperatureManager")
	virtual void StopIncreaseTemperature();

	UFUNCTION(BlueprintCallable, Category = "TemperatureManager")
	virtual void AddActorToImpact(AActor* Actor);

	UFUNCTION(BlueprintCallable, Category = "TemperatureManager")
	virtual void RemoveActorToImpact(AActor* Actor);

	UFUNCTION(BlueprintPure, Category = "TemperatureManager")
	float GetCurrentTemp();

	UFUNCTION(BlueprintPure, Category = "TemperatureManager")
	bool IsDroppingTemperature();

	UFUNCTION(BlueprintPure, Category = "TemperatureManager")
	bool IsIncreasingTemperature();

	UFUNCTION(BlueprintPure, Category = "TemperatureManager")
	bool IsFluctuatingTemperature();

	UFUNCTION(BlueprintPure, Category = "TemperatureManager")
	bool IsIdleTemperature();

	UFUNCTION(BlueprintPure, Category = "TemperatureManager")
	bool CanFluctuateTemperature();

	UFUNCTION(BlueprintPure, Category = "TemperatureManager")
	EIdleTempStatus GetIdleTempStatus();

	UFUNCTION(BlueprintPure, Category = "TemperatureManager")
	TArray<AActor*> GetActorsToImpact();

	UFUNCTION(BlueprintPure, Category = "TemperatureManager")
	bool IsImpactedByTempSource();


	// INTERNAL //
	UFUNCTION(Category = "TemperatureManager")
	virtual void AssignTempSource(AActor* TempSourceActor);
};