// Copyright (C) LIDEV. 2023. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"

/* ENUMs */
UENUM()
enum ETempActorType
{
	None			UMETA(DisplayName = "NONE"),
	TempSource      UMETA(DisplayName = "Temp Source"),
	TempReceiver    UMETA(DisplayName = "Temp Receiver")
};


UENUM()
enum EIdleTempStatus
{
	Idle		UMETA(DisplayName = "Idle"),
	Increase    UMETA(DisplayName = "Increase"),
	Drop		UMETA(DisplayName = "Decrease")
};