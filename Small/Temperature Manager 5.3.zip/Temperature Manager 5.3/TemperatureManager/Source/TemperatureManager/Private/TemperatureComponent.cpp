// Copyright (C) LIDEV. 2023. All Rights Reserved.

#include "TemperatureComponent.h"
#include "Math/UnrealMathUtility.h"
#include "GameFramework/Actor.h"
#include "TimerManager.h"


// Sets default values for this component's properties
UTemperatureComponent::UTemperatureComponent()
{
	// Set this component to be initialized when the game starts, and to be ticked every frame.  You can turn these features
	// off to improve performance if you don't need them.
	PrimaryComponentTick.bCanEverTick = true;

	// ...
}


// Called when the game starts
void UTemperatureComponent::BeginPlay()
{
	Super::BeginPlay();

	DropTempMultiplier = DefaultDropTempMultiplier;
	IncreaseTempMultiplier = DefaultIncreaseTempMultiplier;

	if (GetOwner() != nullptr)
	{
		GetOwner()->GetWorldTimerManager().SetTimer(UpdateTempTimerHandle, this, &UTemperatureComponent::UpdateTemperature, UpdateInterval, true);
		OnTemperatureUpdated.Broadcast(CurrentTemp);
	}
}


// Called every frame
void UTemperatureComponent::TickComponent(float DeltaTime, ELevelTick TickType, FActorComponentTickFunction* ThisTickFunction)
{
	Super::TickComponent(DeltaTime, TickType, ThisTickFunction);

	// ...
}


void UTemperatureComponent::UpdateTemperature()
{
	if (PrimaryComponentTick.bCanEverTick == false)
	{
		return;
	}

	if (IsDroppingTemperature() == true)
	{
		if (IsImpactedByTempSource() == false)
		{
			SetCurrentTemp(GetCurrentTemp() - (FMath::RandRange(DropRangeMin, DropRangeMax) * DropTempMultiplier));
		}
		else
		{
			UTemperatureComponent* ActorTempComponent = CurrentAssignedTempSource->FindComponentByClass<UTemperatureComponent>();
			if (ActorTempComponent != nullptr)
			{
				SetCurrentTemp(GetCurrentTemp() - (FMath::RandRange(ActorTempComponent->DropImpactRangeMin, ActorTempComponent->DropImpactRangeMax) * DropTempMultiplier));
			}
		}
	}
	else if (IsIncreasingTemperature() == true)
	{
		if (IsImpactedByTempSource() == false)
		{
			SetCurrentTemp(GetCurrentTemp() + (FMath::RandRange(IncreaseRangeMin, IncreaseRangeMax) * IncreaseTempMultiplier));
		}
		else
		{
			UTemperatureComponent* ActorTempComponent = CurrentAssignedTempSource->FindComponentByClass<UTemperatureComponent>();
			if (ActorTempComponent != nullptr)
			{
				SetCurrentTemp(GetCurrentTemp() + (FMath::RandRange(ActorTempComponent->IncreaseImpactRangeMin, ActorTempComponent->IncreaseImpactRangeMax) * IncreaseTempMultiplier));
			}
		}
	}
	else if (IsFluctuatingTemperature() == true)
	{
		if (FMath::RandBool() == true)
		{
			SetCurrentTemp(GetCurrentTemp() + FMath::RandRange(0.0f, FluctuateTempRange));
		}
		else {
			SetCurrentTemp(GetCurrentTemp() - FMath::RandRange(0.0f, FluctuateTempRange));
		}
	}
	else if (IsIdleTemperature() == true) {
		if (IdleTempStatus == EIdleTempStatus::Drop)
		{
			SetCurrentTemp(GetCurrentTemp() - (FMath::RandRange(DropRangeMin, DropRangeMax) * DropTempMultiplier));
		}
		else if (IdleTempStatus == EIdleTempStatus::Increase)
		{
			SetCurrentTemp(GetCurrentTemp() + (FMath::RandRange(IncreaseRangeMin, IncreaseRangeMax) * IncreaseTempMultiplier));
		}
	}
}


void UTemperatureComponent::SetCurrentTemp(const float& NewTemp)
{
	CurrentTemp = FMath::Clamp(NewTemp, MinTemp, MaxTemp);
	OnTemperatureUpdated.Broadcast(CurrentTemp);
}


void UTemperatureComponent::SetIdleTempStatus(const EIdleTempStatus& NewStatus)
{
	IdleTempStatus = NewStatus;
}


void UTemperatureComponent::StartIdleTemperature()
{
	StopIncreaseTemperature();
	StopDropTemperature();
	IsFluctuatingTemp = false;
	IsIdleTemp = true;		

	OnTempIdle.Broadcast();
}


void UTemperatureComponent::StartFluctuateTemperature()
{
	StopIncreaseTemperature();
	StopDropTemperature();
	IsFluctuatingTemp = true;	

	if (GetOwner() != nullptr)
	{
		GetOwner()->GetWorldTimerManager().SetTimer(FluctuateTempTimerHandle, this, &UTemperatureComponent::StartIdleTemperature, FluctuateDelay, false);
	}

	OnTempFluctuateStarted.Broadcast();
}


void UTemperatureComponent::StartDropTemperature(const float& TempMultiplierValue, const float& DelayToStartIdle)
{
	StopIncreaseTemperature();

	IsIdleTemp = false;
	IsDroppingTemp = true;
	DropTempMultiplier = TempMultiplierValue;

	if (GetOwner() != nullptr)
	{
		if (CanFluctuateTemperature() == true)
		{
			GetOwner()->GetWorldTimerManager().SetTimer(DroppingTempTimerHandle, this, &UTemperatureComponent::StartFluctuateTemperature, DelayToStartIdle, false);
		}
		else
		{
			GetOwner()->GetWorldTimerManager().SetTimer(DroppingTempTimerHandle, this, &UTemperatureComponent::StartIdleTemperature, DelayToStartIdle, false);
		}
	}

	OnTempDropStarted.Broadcast();
}


void UTemperatureComponent::StopDropTemperature()
{
	IsDroppingTemp = false;
	DropTempMultiplier = DefaultDropTempMultiplier;

	if (DroppingTempTimerHandle.IsValid() == true)
	{
		DroppingTempTimerHandle.Invalidate();
	}

	OnTempDropStopped.Broadcast();
}


void UTemperatureComponent::StartIncreaseTemperature(const float& TempMultiplierValue, const float& DelayToStartIdle)
{
	StopDropTemperature();

	IsIdleTemp = false;
	IsIncreasingTemp = true;
	IncreaseTempMultiplier = TempMultiplierValue;

	if (GetOwner() != nullptr)
	{
		if (CanFluctuateTemperature() == true)
		{
			GetOwner()->GetWorldTimerManager().SetTimer(IncreasingTempTimerHandle, this, &UTemperatureComponent::StartFluctuateTemperature, DelayToStartIdle, false);
		}
		else
		{
			GetOwner()->GetWorldTimerManager().SetTimer(IncreasingTempTimerHandle, this, &UTemperatureComponent::StartIdleTemperature, DelayToStartIdle, false);
		}
	}

	OnTempIncreaseStarted.Broadcast();
}


void UTemperatureComponent::StopIncreaseTemperature()
{
	IsIncreasingTemp = false;
	IncreaseTempMultiplier = DefaultIncreaseTempMultiplier;

	if (IncreasingTempTimerHandle.IsValid() == true)
	{
		IncreasingTempTimerHandle.Invalidate();
	}

	OnTempIncreaseStopped.Broadcast();
}


void UTemperatureComponent::AddActorToImpact(AActor* Actor)
{
	if (Actor != nullptr)
	{
		ActorsToImpact.AddUnique(Actor);
		OnTempActorsToImpactUpdated.Broadcast(Actor);

		UTemperatureComponent* ActorTempComponent = Actor->FindComponentByClass<UTemperatureComponent>();
		if (ActorTempComponent != nullptr)
		{
			ActorTempComponent->AssignTempSource(GetOwner());
		}
	}
}


void UTemperatureComponent::RemoveActorToImpact(AActor* Actor)
{
	if (Actor != nullptr)
	{
		ActorsToImpact.Remove(Actor);
		OnTempActorsToImpactUpdated.Broadcast(Actor);

		UTemperatureComponent* ActorTempComponent = Actor->FindComponentByClass<UTemperatureComponent>();
		if (ActorTempComponent != nullptr)
		{
			ActorTempComponent->AssignTempSource(nullptr);
		}
	}
}


void UTemperatureComponent::AssignTempSource(AActor* TempSourceActor)
{
	CurrentAssignedTempSource = TempSourceActor;
	OnTempSourceActorUpdated.Broadcast(TempSourceActor);
}


float UTemperatureComponent::GetCurrentTemp()
{
	return CurrentTemp;
}


bool UTemperatureComponent::IsDroppingTemperature()
{
	return IsDroppingTemp;
}


bool UTemperatureComponent::IsIncreasingTemperature()
{
	return IsIncreasingTemp;
}


bool UTemperatureComponent::IsFluctuatingTemperature()
{
	return IsFluctuatingTemp;
}


bool UTemperatureComponent::IsIdleTemperature()
{
	return IsIdleTemp;
}


bool UTemperatureComponent::CanFluctuateTemperature()
{
	return CanFluctuateTemp;
}


EIdleTempStatus UTemperatureComponent::GetIdleTempStatus()
{
	return IdleTempStatus;
}


TArray<AActor*> UTemperatureComponent::GetActorsToImpact()
{
	return ActorsToImpact;
}


bool UTemperatureComponent::IsImpactedByTempSource()
{
	if (CurrentAssignedTempSource == nullptr)
	{
		return false;
	}
	else
	{
		return true;
	}
}