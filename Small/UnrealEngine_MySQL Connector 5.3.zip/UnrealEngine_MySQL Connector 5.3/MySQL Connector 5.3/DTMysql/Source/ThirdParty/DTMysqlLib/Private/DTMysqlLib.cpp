// Copyright Epic Games, Inc. All Rights Reserved.

#include "DTMysqlLib.h"

#define LOCTEXT_NAMESPACE "FDTMysqlLibModule"

void FDTMysqlLibModule::StartupModule()
{
}

void FDTMysqlLibModule::ShutdownModule()
{
}

#undef LOCTEXT_NAMESPACE
	
IMPLEMENT_MODULE(FDTMysqlLibModule, DTMysqlLib)