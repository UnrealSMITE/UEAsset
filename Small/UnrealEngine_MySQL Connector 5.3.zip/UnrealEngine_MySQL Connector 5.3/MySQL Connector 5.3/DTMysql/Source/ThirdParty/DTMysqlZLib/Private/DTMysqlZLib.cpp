﻿// Copyright 2021 - 2022 Dexter.Wan. All Rights Reserved. 
// EMail: 45141961@qq.com

#include "DTMysqlZLib.h"

#define LOCTEXT_NAMESPACE "FDTMysqlZLibModule"

void FDTMysqlZLibModule::StartupModule()
{
}

void FDTMysqlZLibModule::ShutdownModule()
{
}

#undef LOCTEXT_NAMESPACE
	
IMPLEMENT_MODULE(FDTMysqlZLibModule, DTMysqlZLib)
