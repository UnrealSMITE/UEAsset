﻿// Copyright 2021 - 2022 Dexter.Wan. All Rights Reserved. 
// EMail: 45141961@qq.com


#include "DTK2Node_ExecuteSQL.h"
#include "K2Node_MakeArray.h"
#include "BlueprintActionDatabaseRegistrar.h"
#include "BlueprintNodeSpawner.h"
#include "KismetCompiler.h"
#include "K2Node_CallFunction.h"
#include "EdGraph/EdGraphNode.h"
#include "ToolMenus.h"

#include "DTMysqlObject.h"
#include "DTMysqlResult.h"
#include "DTK2Node_AnalyzeArrayMysqlResult.h"
#include "DTGraphNodeArrayMysqlResult.h"

UDTK2Node_ExecuteSQL::UDTK2Node_ExecuteSQL(const FObjectInitializer& ObjectInitializer) : Super(ObjectInitializer), NumInputs(1)
{
}

// 节点初始化
void UDTK2Node_ExecuteSQL::AllocateDefaultPins()
{
	Super::AllocateDefaultPins();

	// 执行节点
	CreatePin(EGPD_Input, UEdGraphSchema_K2::PC_Exec, UEdGraphSchema_K2::PN_Execute);
	CreatePin(EGPD_Output, UEdGraphSchema_K2::PC_Exec, UEdGraphSchema_K2::PN_Then);

	// 输入节点
	CreatePin(EGPD_Input, UEdGraphSchema_K2::PC_String, FName(TEXT("SQL")));

	// 输出节点
	CreatePin(EGPD_Output, UEdGraphSchema_K2::PC_Boolean, FName(TEXT("Success")));
	CreatePin(EGPD_Output, UEdGraphSchema_K2::PC_Int, FName(TEXT("ErrorNo")));
	CreatePin(EGPD_Output, UEdGraphSchema_K2::PC_String, FName(TEXT("ErrorMsg")));
	CreatePin(EGPD_Output, UEdGraphSchema_K2::PC_Int, FName(TEXT("Rows")));
	for (int32 nIndex = 0; nIndex < NumInputs; ++nIndex)
	{
		CreatePin(EGPD_Output, UEdGraphSchema_K2::PC_Struct, FDTArrayMysqlResult::StaticStruct(), FName(FString::Format(TEXT("Result {0}"), { nIndex })));
	}
}

// 菜单注册
void UDTK2Node_ExecuteSQL::GetMenuActions(FBlueprintActionDatabaseRegistrar& ActionRegistrar) const
{
	UClass* ActionKey = GetClass();

	if (ActionRegistrar.IsOpenForRegistration(ActionKey))
	{
		UBlueprintNodeSpawner* NodeSpawner = UBlueprintNodeSpawner::Create(GetClass());
		check(NodeSpawner != nullptr);

		ActionRegistrar.AddBlueprintAction(ActionKey, NodeSpawner);
	}
}

// 编译节点
void UDTK2Node_ExecuteSQL::ExpandNode(FKismetCompilerContext& CompilerContext, UEdGraph* SourceGraph)
{
	Super::ExpandNode(CompilerContext, SourceGraph);

	UEdGraphPin* ExecPin = GetExecPin();
	UEdGraphPin* ThenPin = GetThenPin();
	if (ExecPin && ThenPin)
	{
		// 创建函数回调
		FName FunctionName = GET_FUNCTION_NAME_CHECKED(UDTMysqlObject, OnExecuteSQL);
		UK2Node_CallFunction* CallFuncNode = CompilerContext.SpawnIntermediateNode<UK2Node_CallFunction>(this, SourceGraph);
		CallFuncNode->FunctionReference.SetExternalMember(FunctionName, UDTMysqlObject::StaticClass());
		CallFuncNode->AllocateDefaultPins();

		// 绑定参数节点
		CompilerContext.MovePinLinksToIntermediate(*(FindPinChecked(TEXT("SQL"), EGPD_Input)), *(CallFuncNode->FindPinChecked(TEXT("SQL"))));

		CompilerContext.MovePinLinksToIntermediate(*(FindPinChecked(TEXT("Success"), EGPD_Output)), *(CallFuncNode->FindPinChecked(UEdGraphSchema_K2::PN_ReturnValue)));
		CompilerContext.MovePinLinksToIntermediate(*(FindPinChecked(TEXT("ErrorNo"), EGPD_Output)), *(CallFuncNode->FindPinChecked(TEXT("ErrorNo"))));
		CompilerContext.MovePinLinksToIntermediate(*(FindPinChecked(TEXT("ErrorMsg"), EGPD_Output)), *(CallFuncNode->FindPinChecked(TEXT("ErrorMsg"))));
		CompilerContext.MovePinLinksToIntermediate(*(FindPinChecked(TEXT("Rows"), EGPD_Output)), *(CallFuncNode->FindPinChecked(TEXT("Rows"))));

		{
			// 绑定输出节点
			UDTK2Node_AnalyzeArrayMysqlResult* MakeArrayNode = CompilerContext.SpawnIntermediateNode<UDTK2Node_AnalyzeArrayMysqlResult>(this, SourceGraph);
			MakeArrayNode->AllocateDefaultPins();

			// 绑定到变量
			UEdGraphPin* ArrayInput = MakeArrayNode->GetInputPin();
			UEdGraphPin* FuncArgPin = CallFuncNode->FindPinChecked(TEXT("OutResult"));
			FuncArgPin->MakeLinkTo(ArrayInput);
			MakeArrayNode->PinConnectionListChanged(ArrayInput);

			// 绑定到输入值
			for (int nIndex = 0; nIndex < NumInputs; ++nIndex)
			{
				// 新增默认点
				if (nIndex > 0)
					MakeArrayNode->AddInputPin();

				// 绑定节点
				UEdGraphPin* OutPin = FindPinChecked(FString::Format(TEXT("Result {0}"), { nIndex }), EGPD_Output);
				UEdGraphPin* ArrayPin = MakeArrayNode->GetOutputPin(nIndex);
				CompilerContext.MovePinLinksToIntermediate(*OutPin, *ArrayPin);
			}
		}

		// 绑定执行节点
		CompilerContext.MovePinLinksToIntermediate(*ExecPin, *(CallFuncNode->GetExecPin()));
		CompilerContext.MovePinLinksToIntermediate(*ThenPin, *(CallFuncNode->GetThenPin()));
	}

	BreakAllNodeLinks();
}

// 获取执行结束节点
UEdGraphPin* UDTK2Node_ExecuteSQL::GetThenPin() const
{
	UEdGraphPin* Pin = FindPin(UEdGraphSchema_K2::PN_Then);
	check(Pin == nullptr || Pin->Direction == EGPD_Output);
	return Pin;
}


// 返回添加界面
TSharedPtr<SGraphNode> UDTK2Node_ExecuteSQL::CreateVisualWidget()
{
	return SNew(SDTGraphNodeArrayMysqlResult, this);
}

// 添加节点
bool UDTK2Node_ExecuteSQL::AddInputPin()
{
	// 通知修改
	Modify();

	// 节点添加
	CreatePin(EGPD_Output, UEdGraphSchema_K2::PC_Struct, FDTArrayMysqlResult::StaticStruct(), FName(FString::Format(TEXT("Result {0}"), { NumInputs })));
	NumInputs++;

	// 标记蓝图
	FBlueprintEditorUtils::MarkBlueprintAsModified(GetBlueprint());
	GetGraph()->NotifyGraphChanged();

	return true;
}

// 删除节点
bool UDTK2Node_ExecuteSQL::RemoveInputPin()
{
	// 最小数量
	if (NumInputs <= 1)
	{
		return false;
	}

	// 通知修改
	Modify();

	// 节点删除
	UEdGraphPin* Pin = FindPin(FName(FString::Format(TEXT("Result {0}"), { NumInputs - 1})), EGPD_Output);
	if (Pin != nullptr && RemovePin(Pin))
	{
		NumInputs--;
	}

	// 标记蓝图
	FBlueprintEditorUtils::MarkBlueprintAsModified(GetBlueprint());
	GetGraph()->NotifyGraphChanged();

	return true;
}
