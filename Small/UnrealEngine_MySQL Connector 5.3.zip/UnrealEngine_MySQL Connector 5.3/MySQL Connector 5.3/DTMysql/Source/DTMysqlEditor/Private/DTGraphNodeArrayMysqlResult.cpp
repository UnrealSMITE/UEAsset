﻿// Copyright 2021 - 2022 Dexter.Wan. All Rights Reserved. 
// EMail: 45141961@qq.com

#include "DTGraphNodeArrayMysqlResult.h"
#include "DTK2Node_ExecuteSQL.h"
#include "Kismet2/BlueprintEditorUtils.h"
#include "GraphEditorSettings.h"

// 初始化
void SDTGraphNodeArrayMysqlResult::Construct(const FArguments& InArgs, UDTK2Node_ExecuteSQL* InNode)
{
	this->GraphNode = Cast<UEdGraphNode>(InNode);

	this->SetCursor( EMouseCursor::CardinalCross );

	this->UpdateGraphNode();
}

// 创建菜单
void SDTGraphNodeArrayMysqlResult::CreateOutputSideAddButton(TSharedPtr<SVerticalBox> OutputBox)
{
	// 添加按钮
	TSharedRef<SButton> AddPinButton = SNew(SButton)
		.ContentPadding(0.0f)
		.ButtonStyle(FAppStyle::Get(), "NoBorder")
		.OnClicked(this, &SDTGraphNodeArrayMysqlResult::OnAddPin)
		.ToolTipText(NSLOCTEXT("DT Mysql", "Add Result", "Add Result"))
		[
			SNew(SHorizontalBox)
			+ SHorizontalBox::Slot()
			.AutoWidth()
			.HAlign(HAlign_Left)
		[
			SNew(STextBlock)
			.Text(NSLOCTEXT("DT Mysql", "Add Result", "Add Result"))
			.ColorAndOpacity(FLinearColor::White)
		]
	+ SHorizontalBox::Slot()
		.AutoWidth()
		.VAlign(VAlign_Center)
		.Padding(7, 0, 0, 0)
		[
			SNew(SImage)
			.Image(FAppStyle::GetBrush(TEXT("Icons.Plus")))
		]
		];

	AddPinButton->SetCursor(EMouseCursor::Hand);

	// 移除按钮
	TSharedRef<SButton> RemovePinButton = SNew(SButton)
		.ContentPadding(0.0f)
		.ButtonStyle(FAppStyle::Get(), "NoBorder")
		.OnClicked(this, &SDTGraphNodeArrayMysqlResult::OnRemovePin)
		.ToolTipText(NSLOCTEXT("DT Mysql", "Remove Result", "Remove Result"))
		[
			SNew(SHorizontalBox)
			+ SHorizontalBox::Slot()
			.AutoWidth()
			.HAlign(HAlign_Left)
		[
			SNew(STextBlock)
			.Text(NSLOCTEXT("DT Mysql", "Remove Result", "Remove Result"))
			.ColorAndOpacity(FLinearColor::White)
		]
	+ SHorizontalBox::Slot()
		.AutoWidth()
		.VAlign(VAlign_Center)
		.Padding(7, 0, 0, 0)
		[
			SNew(SImage)
			.Image(FAppStyle::GetBrush(TEXT("Icons.Minus")))
		]
		];

	RemovePinButton->SetCursor(EMouseCursor::Hand);

	FMargin AddPinPadding = Settings->GetInputPinPadding();
	AddPinPadding.Top += 6.0f;
	OutputBox->AddSlot()
		.AutoHeight()
		.VAlign(VAlign_Center)
		.HAlign(HAlign_Right)
		.Padding(AddPinPadding)
		[
			AddPinButton
		];
	OutputBox->AddSlot()
		.AutoHeight()
		.VAlign(VAlign_Center)
		.HAlign(HAlign_Right)
		.Padding(AddPinPadding)
		[
			RemovePinButton
		];
}

// 添加节点
FReply SDTGraphNodeArrayMysqlResult::OnAddPin()
{
	UDTK2Node_ExecuteSQL* BPNode = CastChecked<UDTK2Node_ExecuteSQL>(GraphNode);
	if (BPNode != nullptr && BPNode->AddInputPin())
	{
		UpdateGraphNode();
	}

	return FReply::Handled();
}

// 删除节点
FReply SDTGraphNodeArrayMysqlResult::OnRemovePin()
{
	UDTK2Node_ExecuteSQL* BPNode = CastChecked<UDTK2Node_ExecuteSQL>(GraphNode);
	if (BPNode != nullptr && BPNode->RemoveInputPin())
	{
		UpdateGraphNode();
	}

	return FReply::Handled();
}