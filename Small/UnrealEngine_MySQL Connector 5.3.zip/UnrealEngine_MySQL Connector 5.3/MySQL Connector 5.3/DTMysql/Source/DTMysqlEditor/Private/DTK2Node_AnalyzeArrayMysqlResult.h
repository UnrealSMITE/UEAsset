﻿// Copyright 2021 - 2022 Dexter.Wan. All Rights Reserved. 
// EMail: 45141961@qq.com

#pragma once

#include "CoreMinimal.h"
#include "DTK2Node_AnalyzeArrayMysqlResult.generated.h"

/**
 * 
 */
UCLASS(MinimalAPI)
class UDTK2Node_AnalyzeArrayMysqlResult : public UK2Node
{
	GENERATED_UCLASS_BODY()

public:
	// 初始化节点
	virtual void AllocateDefaultPins() override;
	// 编译节点
	virtual void ExpandNode(class FKismetCompilerContext& CompilerContext, UEdGraph* SourceGraph) override;
	// 添加节点
	virtual void AddInputPin();
	// 纯节点
	virtual bool IsNodePure() const override { return true; }

public:
	// 获取输出节点名称
	FName GetPinOutName(int32 Num);
	// 获取输入节点
	UEdGraphPin* GetInputPin();
	// 获取输出节点
	UEdGraphPin* GetOutputPin(int32 Num);
		
private:
	// 输出数量
	UPROPERTY()
	int32 NumInputs;
	
};
