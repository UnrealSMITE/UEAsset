﻿// Copyright 2021 - 2022 Dexter.Wan. All Rights Reserved. 
// EMail: 45141961@qq.com

#pragma once

#include "CoreMinimal.h"
#include "K2Node.h"
#include "DTK2Node_ExecuteSQL.generated.h"

/**
 * 
 */
UCLASS()
class UDTK2Node_ExecuteSQL : public UK2Node
{
	GENERATED_UCLASS_BODY()
	
public:
	// 返回节点信息
	virtual FText GetTooltipText() const override { return NSLOCTEXT("DT Mysql", "Execute the SQL statement to get the stored result", "Execute the SQL statement to get the stored result"); }
	virtual FText GetNodeTitle(ENodeTitleType::Type TitleType) const override { return NSLOCTEXT("DT Mysql", "Execute SQL", "Execute SQL"); }
	virtual FText GetMenuCategory() const { return FText::FromString(TEXT("DT Mysql")); }
	virtual bool IsNodePure() const override { return false; }

	// 节点初始化
	virtual void AllocateDefaultPins() override;
	// 菜单注册
	virtual void GetMenuActions(FBlueprintActionDatabaseRegistrar& ActionRegistrar) const override;
	// 编译节点
	virtual void ExpandNode(class FKismetCompilerContext& CompilerContext, UEdGraph* SourceGraph) override;
	// 返回添加界面
	virtual TSharedPtr<SGraphNode> CreateVisualWidget() override;
	// 添加节点
	bool AddInputPin();
	// 删除节点
	bool RemoveInputPin();

public:
	// 获取执行结束节点
	UEdGraphPin* GetThenPin() const;

private:
	// 输出结果集数量
	UPROPERTY()
	int32 NumInputs;
};
