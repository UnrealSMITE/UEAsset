﻿// Copyright 2021 - 2022 Dexter.Wan. All Rights Reserved. 
// EMail: 45141961@qq.com

#pragma once

#include "CoreMinimal.h"
#include "KismetNodes/SGraphNodeK2Base.h"

class SVerticalBox;
class UDTK2Node_ExecuteSQL;

// 输入节点编辑菜单
class SDTGraphNodeArrayMysqlResult : public SGraphNodeK2Base
{

public:

	SLATE_BEGIN_ARGS(SDTGraphNodeArrayMysqlResult){}
	SLATE_END_ARGS()

public:
	// 初始化
	void Construct(const FArguments& InArgs, UDTK2Node_ExecuteSQL* InNode);
	// 创建菜单
	virtual void CreateOutputSideAddButton(TSharedPtr<SVerticalBox> OutputBox) override;
	// 添加节点
	virtual FReply OnAddPin() override;
	// 删除节点
	virtual FReply OnRemovePin();
};
