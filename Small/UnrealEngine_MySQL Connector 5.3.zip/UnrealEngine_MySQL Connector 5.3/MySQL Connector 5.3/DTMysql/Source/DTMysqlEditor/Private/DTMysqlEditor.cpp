﻿// Copyright 2021 - 2022 Dexter.Wan. All Rights Reserved. 
// EMail: 45141961@qq.com

#include "DTMysqlEditor.h"

#define LOCTEXT_NAMESPACE "FDTMysqlEditorModule"

// 系统开始运行
void FDTMysqlEditorModule::StartupModule()
{

}

// 系统结束运行
void FDTMysqlEditorModule::ShutdownModule()
{

}

#undef LOCTEXT_NAMESPACE
	
IMPLEMENT_MODULE(FDTMysqlEditorModule, DTMysqlEditor)