﻿// Copyright 2021 - 2022 Dexter.Wan. All Rights Reserved. 
// EMail: 45141961@qq.com

#include "DTK2Node_AnalyzeArrayMysqlResult.h"
#include "DTMysqlBPLib.h"

#include "Kismet2/BlueprintEditorUtils.h"
#include "KismetCompiler.h"
#include "K2Node_CallFunction.h"

#define TEXT_INOUT TEXT("InArray_UDTK2Node_FDTArrayMysqlResult")

#define LOCTEXT_NAMESPACE "K2Node_Json"

// UDTK2Node_AnalyzeArrayMysqlResult 构造函数 
UDTK2Node_AnalyzeArrayMysqlResult::UDTK2Node_AnalyzeArrayMysqlResult(const FObjectInitializer& ObjectInitializer) : Super(ObjectInitializer), NumInputs(1)
{

}

// 初始化节点
void UDTK2Node_AnalyzeArrayMysqlResult::AllocateDefaultPins()
{
	FCreatePinParams ArrayPinParams;
	ArrayPinParams.ContainerType = EPinContainerType::Array;
	CreatePin(EGPD_Input, UEdGraphSchema_K2::PC_Struct, FDTArrayMysqlResult::StaticStruct(), FName(TEXT_INOUT), ArrayPinParams);

	for (int32 i = 0; i < NumInputs; i++) 
	{
		CreatePin(EGPD_Output, UEdGraphSchema_K2::PC_Struct, FDTArrayMysqlResult::StaticStruct(), GetPinOutName(i));
	}
}

// 编译节点
void UDTK2Node_AnalyzeArrayMysqlResult::ExpandNode(FKismetCompilerContext& CompilerContext, UEdGraph* SourceGraph)
{
	Super::ExpandNode(CompilerContext, SourceGraph);

	// 输入数组节点
	UEdGraphPin* InPinArrayCase = FindPin(TEXT_INOUT);

	for (int32 i = 0; i < NumInputs; i++)
	{
		// 创建函数回调
		UK2Node_CallFunction* PinCallFunction = CompilerContext.SpawnIntermediateNode<UK2Node_CallFunction>(this, SourceGraph);
		const UFunction* Function = UDTMysqlBPLib::StaticClass()->FindFunctionByName(GET_FUNCTION_NAME_CHECKED(UDTMysqlBPLib, OnArrayMysqlResultOut));
		PinCallFunction->SetFromFunction(Function);
		PinCallFunction->AllocateDefaultPins();

		// 默认节点
		UEdGraphPin* FuncArgPin = PinCallFunction->FindPinChecked(TEXT("Index"));
		FuncArgPin->DefaultValue = FString::Format(TEXT("{0}"), { i });

		// 绑定输入数组节点
		UEdGraphPin* FuncInArray = PinCallFunction->FindPinChecked(TEXT("InArray"));
		CompilerContext.CopyPinLinksToIntermediate(*InPinArrayCase, *FuncInArray);

		// 绑定输出节点
		UEdGraphPin* OutPinCase = FindPin(GetPinOutName(i));
		UEdGraphPin* OutPin = PinCallFunction->GetReturnValuePin();
		if (OutPinCase && OutPin)
		{
			CompilerContext.MovePinLinksToIntermediate(*OutPinCase, *OutPin);
		}
	}

	BreakAllNodeLinks();
}

// 添加节点
void UDTK2Node_AnalyzeArrayMysqlResult::AddInputPin()
{
	// 通知修改
	Modify();

	// 添加节点
	CreatePin(EGPD_Output, UEdGraphSchema_K2::PC_Struct, FDTArrayMysqlResult::StaticStruct(), GetPinOutName(NumInputs));
	++NumInputs;

	// 标记蓝图
	FBlueprintEditorUtils::MarkBlueprintAsModified(GetBlueprint());
	GetGraph()->NotifyGraphChanged();

	return;
}

// 获取输出节点名称
FName UDTK2Node_AnalyzeArrayMysqlResult::GetPinOutName(int32 Num)
{
	return *FString::Printf(TEXT("[%d]"), Num);
}

// 获取输入节点
UEdGraphPin* UDTK2Node_AnalyzeArrayMysqlResult::GetInputPin()
{
	return FindPinChecked(TEXT_INOUT, EGPD_Input);
}

// 获取输出节点
UEdGraphPin* UDTK2Node_AnalyzeArrayMysqlResult::GetOutputPin(int32 Num)
{
	return FindPinChecked(GetPinOutName(Num), EGPD_Output);
}


#undef LOCTEXT_NAMESPACE