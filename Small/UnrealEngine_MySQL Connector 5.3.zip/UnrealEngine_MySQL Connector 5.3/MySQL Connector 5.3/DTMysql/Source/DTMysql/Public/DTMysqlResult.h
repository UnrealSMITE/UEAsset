﻿// Copyright 2021 - 2022 Dexter.Wan. All Rights Reserved. 
// EMail: 45141961@qq.com

#pragma once

#include "CoreMinimal.h"
#include "UObject/NoExportTypes.h"
#include "DTMysqlResult.generated.h"


USTRUCT(BlueprintType, meta = (HasNativeBreak = "DTMysql.DTMysqlBPLib.BreakDTMysqlResult"))
struct FDTMysqlResult
{
	GENERATED_BODY()

public:
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "DT Mysql")
	TMap<FString, FString> Result;

	FDTMysqlResult() {}

	FDTMysqlResult(const FDTMysqlResult& Right)
	{
		*this = Right;
	}
	FDTMysqlResult& operator= (const FDTMysqlResult& Right)
	{
		Result.Empty(Right.Result.Num());
		Result.Append(Right.Result);
		return *this;
	}
};


USTRUCT(BlueprintType, meta = (HasNativeBreak = "DTMysql.DTMysqlBPLib.BreakDTArrayMysqlResult"))
struct FDTArrayMysqlResult
{
	GENERATED_BODY()

public:
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "DT Mysql")
	TArray<FDTMysqlResult> ArrayResult;

	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "DT Mysql")
	int Rows;

	FDTArrayMysqlResult() : Rows(0){}

	FDTArrayMysqlResult(const FDTArrayMysqlResult& Right)
	{
		*this = Right;
	}

	FDTArrayMysqlResult& operator= (const FDTArrayMysqlResult& Right)
	{
		ArrayResult.Empty(Right.ArrayResult.Num());
		ArrayResult.Append(Right.ArrayResult);
		Rows = Right.Rows;
		return *this;
	}
};


