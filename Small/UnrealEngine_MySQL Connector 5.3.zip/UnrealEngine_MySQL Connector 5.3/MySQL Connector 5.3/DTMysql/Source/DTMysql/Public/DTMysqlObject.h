﻿// Copyright 2021 - 2022 Dexter.Wan. All Rights Reserved. 
// EMail: 45141961@qq.com

#pragma once

#include "CoreMinimal.h"
#include "UObject/NoExportTypes.h"
#include "DTMysqlHead.h"
#include "DTMysqlResult.h"
#include "DTMysqlObject.generated.h"

/**
 * 
 */
UCLASS()
class DTMYSQL_API UDTMysqlObject : public UObject
{
	GENERATED_BODY()

private:
	bool					m_bInitialize = false;				// 是否初始化
	bool					m_bConnect = false;					// 是否连接数据
	MYSQL					m_MysqlObject;						// MYSQL对象连接

private:
	FString					m_Host;
	int 					m_Port;
	FString					m_User;
	FString					m_Password;
	FString					m_DBName;

private:
	static UDTMysqlObject* g_UDTMysqlObject;					// 当前对象指针

public:
	// 初始化
	bool Initialize();
	// 关闭数据
	bool Close();
	// 连接数据库
	bool Connect(const FString& Host, int Port, const FString& User, const FString& Password, const FString& DBName, int32& ErrorNo, FString& ErrorMsg);

private:
	// 判断是否初始化
	bool IsInitialize() const { return m_bInitialize; }
	// 判断是否连接数据库
	bool IsConnect() const { return m_bConnect; }
	// 获取数据库对象
	MYSQL* GetMYSQL() { return &m_MysqlObject; }

public:
	// Create Database Link
	UFUNCTION(BlueprintCallable, meta = (DisplayName = "Connect MySql"), Category = "DT Mysql")
	static void CreateMysql(const FString& Host, int Port, const FString& User, const FString& Password, const FString& DBName, bool & Success, int32& ErrorNo, FString& ErrorMsg);

	// 执行SQL语句
	UFUNCTION(BlueprintCallable, meta = (BlueprintInternalUseOnly = "true"))
	static bool OnExecuteSQL(const FString& SQL, int32& ErrorNo, FString& ErrorMsg, int& Rows, TArray<FDTArrayMysqlResult> & OutResult);
};
