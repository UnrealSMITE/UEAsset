﻿// Copyright 2021 - 2022 Dexter.Wan. All Rights Reserved. 
// EMail: 45141961@qq.com

#pragma once

#include "CoreMinimal.h"
#include "Kismet/BlueprintFunctionLibrary.h"
#include "DTMysqlResult.h"
#include "DTMysqlBPLib.generated.h"

/**
 * 
 */
UCLASS()
class DTMYSQL_API UDTMysqlBPLib : public UBlueprintFunctionLibrary
{
	GENERATED_BODY()
	
public:
	// Array Mysql Result Out
	UFUNCTION(BlueprintPure, meta = (BlueprintInternalUseOnly = "true"))
	static FDTArrayMysqlResult OnArrayMysqlResultOut(const TArray<FDTArrayMysqlResult>& InArray, const int32 Index);

	// Break DTMysqlResult
	UFUNCTION(BlueprintPure, Category = "DT Mysql", meta = (BlueprintThreadSafe))
	static void BreakDTMysqlResult(const FDTMysqlResult& DTMysqlResult, TMap<FString, FString>& MysqlResult);

	// Break DTArrayMysqlResult
	UFUNCTION(BlueprintPure, Category = "DT Mysql", meta = (BlueprintThreadSafe))
	static void BreakDTArrayMysqlResult(const FDTArrayMysqlResult& DTArrayMysqlResult, TArray<FDTMysqlResult>& DTMysqlResults, int& Rows);

	// DTMysqlResult To Json
	UFUNCTION(BlueprintPure, Category = "DT Mysql")
	static FString DTMysqlResultToJson(const FDTMysqlResult& DTMysqlResult);

	// DTMysqlResult Find Value By Key
	UFUNCTION(BlueprintPure, Category = "DT Mysql")
	static FString DTMysqlResultFind(const FDTMysqlResult& DTMysqlResult, const FString& Key);

	// DTArrayMysqlResult To JsonArray
	UFUNCTION(BlueprintPure, Category = "DT Mysql")
	static FString DTArrayMysqlResultToJson(const FDTArrayMysqlResult& DTArrayMysqlResult);

	// DTArrayMysqlResult To JsonArray
	UFUNCTION(BlueprintPure, Category = "DT Mysql")
	static TArray<FString> DTArrayMysqlResultToJsonArray(const FDTArrayMysqlResult& DTArrayMysqlResult);

	// FDTArrayMysqlResult By Index To FDTMysqlResult
	UFUNCTION(BlueprintPure, Category = "DT Mysql")
	static FDTMysqlResult DTArrayMysqlResultIndex(const FDTArrayMysqlResult& DTArrayMysqlResult, int32 Index);

	// FDTArrayMysqlResult Rows
	UFUNCTION(BlueprintPure, Category = "DT Mysql")
	static int DTArrayMysqlResultRows(const FDTArrayMysqlResult& DTArrayMysqlResult);
};
