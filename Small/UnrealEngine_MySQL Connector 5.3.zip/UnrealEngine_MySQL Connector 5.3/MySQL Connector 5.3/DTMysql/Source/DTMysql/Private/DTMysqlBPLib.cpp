﻿// Copyright 2021 - 2022 Dexter.Wan. All Rights Reserved. 
// EMail: 45141961@qq.com

#include "DTMysqlBPLib.h"

// 数组返回
FDTArrayMysqlResult UDTMysqlBPLib::OnArrayMysqlResultOut(const TArray<FDTArrayMysqlResult>& InArray, const int32 Index)
{
    if (Index >= InArray.Num())
    {
        return FDTArrayMysqlResult();
    }
    return InArray[Index];
}

// 拆分 DTMysqlResult
void UDTMysqlBPLib::BreakDTMysqlResult(const FDTMysqlResult& DTMysqlResult, TMap<FString, FString>& MysqlResult)
{
    MysqlResult.Append(DTMysqlResult.Result);
}


// 拆分 DTArrayMysqlResult
void UDTMysqlBPLib::BreakDTArrayMysqlResult(const FDTArrayMysqlResult& DTArrayMysqlResult, TArray<FDTMysqlResult>& DTMysqlResults, int& Rows)
{
    DTMysqlResults.Append(DTArrayMysqlResult.ArrayResult);
    Rows = DTArrayMysqlResult.Rows;
}

// 转换为Json
FString UDTMysqlBPLib::DTMysqlResultToJson(const FDTMysqlResult& DTMysqlResult)
{
    // Json
    FString Json = TEXT("{");

    // 遍历所有
    for (auto& Elem : DTMysqlResult.Result)
    {
        Json += TEXT("\"");
        Json += Elem.Key;
        Json += TEXT("\":\"");
        Json += Elem.Value;
        Json += TEXT("\",");
    }

    // 结尾判断
    if (DTMysqlResult.Result.Num() > 0)
    {
        Json.RemoveAt(Json.Len() - 1);
    }
    Json += TEXT("}");

    return Json;
}

// 查询值
FString UDTMysqlBPLib::DTMysqlResultFind(const FDTMysqlResult& DTMysqlResult, const FString& Key)
{
    const FString* Value = DTMysqlResult.Result.Find(Key);
    return Value == nullptr ? TEXT("") : *Value;
}

// 转换为Json
FString UDTMysqlBPLib::DTArrayMysqlResultToJson(const FDTArrayMysqlResult& DTArrayMysqlResult)
{
    // Json
    FString Json = TEXT("[");

    // 遍历所有
    for (auto& Elem : DTArrayMysqlResult.ArrayResult)
    {
        Json += DTMysqlResultToJson(Elem);
        Json += TEXT(",");
    }
    // 结尾判断
    if (DTArrayMysqlResult.ArrayResult.Num() > 0)
    {
        Json.RemoveAt(Json.Len() - 1);
    }
    Json += TEXT("]");

    return Json;
}

// 转换为Json
TArray<FString> UDTMysqlBPLib::DTArrayMysqlResultToJsonArray(const FDTArrayMysqlResult& DTArrayMysqlResult)
{
    // Json
    TArray<FString> ArrayJson;

    // 遍历所有
    for (auto& Elem : DTArrayMysqlResult.ArrayResult)
    {
        ArrayJson.Add(DTMysqlResultToJson(Elem));
    }

    return ArrayJson;
}

// 查找队列里面数据
FDTMysqlResult UDTMysqlBPLib::DTArrayMysqlResultIndex(const FDTArrayMysqlResult& DTArrayMysqlResult, int32 Index)
{
    if (Index >= DTArrayMysqlResult.ArrayResult.Num())
    {
        return FDTMysqlResult();
    }

    return DTArrayMysqlResult.ArrayResult[Index];
}

// 多少条数据
int UDTMysqlBPLib::DTArrayMysqlResultRows(const FDTArrayMysqlResult& DTArrayMysqlResult)
{
    return DTArrayMysqlResult.ArrayResult.Num();
}