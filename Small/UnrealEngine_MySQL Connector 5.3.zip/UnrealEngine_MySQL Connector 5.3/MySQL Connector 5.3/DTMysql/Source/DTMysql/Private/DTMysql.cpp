﻿// Copyright 2021 - 2022 Dexter.Wan. All Rights Reserved. 
// EMail: 45141961@qq.com

#include "DTMysql.h"

#define LOCTEXT_NAMESPACE "FDTMysqlModule"

void FDTMysqlModule::StartupModule()
{
}

void FDTMysqlModule::ShutdownModule()
{
}

#undef LOCTEXT_NAMESPACE
	
IMPLEMENT_MODULE(FDTMysqlModule, DTMysql)
