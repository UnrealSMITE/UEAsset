﻿// Copyright 2021 - 2022 Dexter.Wan. All Rights Reserved. 
// EMail: 45141961@qq.com

#include "DTMysqlObject.h"

// 全局对象
UDTMysqlObject* UDTMysqlObject::g_UDTMysqlObject = nullptr;

// 初始化
bool UDTMysqlObject::Initialize()
{
	// 已经初始化
	if (m_bInitialize)
	{
		return false;
	}

	// 初始化MYSQL
	mysql_init(&m_MysqlObject);
	m_bInitialize = true;

	return true;
}

// 关闭数据
bool UDTMysqlObject::Close()
{
	// 没有初始化
	if (!m_bInitialize)
	{
		return false;
	}

	// 关闭
	mysql_close(&m_MysqlObject);
	m_bInitialize = false;

	return true;
}

// 连接数据库
bool UDTMysqlObject::Connect(const FString& Host, int Port, const FString& User, const FString& Password, const FString& DBName, int32& ErrorNo, FString& ErrorMsg)
{
	// 没有初始化
	if (!m_bInitialize)
	{
		Initialize();
	}

	// 获取数据信息
	MYSQL* pMysql = GetMYSQL();

	// 连接数据库
	if (!(mysql_real_connect(pMysql, TCHAR_TO_UTF8(*Host), TCHAR_TO_UTF8(*User), TCHAR_TO_UTF8(*Password), TCHAR_TO_UTF8(*DBName), Port, NULL, 0)))
	{
		ErrorNo = mysql_errno(pMysql);
		ErrorMsg = UTF8_TO_TCHAR(mysql_error(pMysql));

		return false;
	}

	// 修改自动重连
	char value = 1;
	mysql_options(pMysql, MYSQL_OPT_RECONNECT, &value);

	// 记录数据
	m_Host = Host;
	m_Port = Port;
	m_User = User;
	m_Password = Password;
	m_DBName = DBName;

	// 连接成功
	m_bConnect = true;
	return true;
}


// 创建数据库
void UDTMysqlObject::CreateMysql(const FString& Host, int Port, const FString& User, const FString& Password, const FString& DBName, bool& Success, int32& ErrorNo, FString& ErrorMsg)
{
	// 没有对象
	if (g_UDTMysqlObject == nullptr)
	{
		// 创建对象并初始化
		g_UDTMysqlObject = NewObject<UDTMysqlObject>();
		g_UDTMysqlObject->AddToRoot();
	}

	// 连接数据库
	g_UDTMysqlObject->Close();
	g_UDTMysqlObject->Initialize();
	if (!g_UDTMysqlObject->Connect(Host, Port, User, Password, DBName, ErrorNo, ErrorMsg))
	{
		Success = false;
		g_UDTMysqlObject = nullptr;
		return;
	}

	// 连接成功
	Success = true;
	ErrorNo = 0;
	ErrorMsg = TEXT("success");
	return;
}

// 执行SQL语句
bool UDTMysqlObject::OnExecuteSQL( const FString& SQL, int32& ErrorNo, FString& ErrorMsg, int & Rows, TArray<FDTArrayMysqlResult>& OutResult)
{
	// 判断数据连接
	if (g_UDTMysqlObject == nullptr)
	{
		ErrorNo = -1;
		ErrorMsg = TEXT("mysql is not create.");

		return false;
	}

	// 判断数据连接
	if (!g_UDTMysqlObject->IsInitialize()
		|| !g_UDTMysqlObject->IsConnect()
		|| SQL.IsEmpty())
	{
		ErrorNo = -1;
		ErrorMsg = TEXT("mysql not initialize or not connect or SQL is empty.");

		return false;
	}

	// 获取数据库指针
	MYSQL* pMysql = g_UDTMysqlObject->GetMYSQL();

	// 查询
	int nRel = mysql_query(pMysql, TCHAR_TO_UTF8(*SQL));
	if (nRel != 0)
	{
		ErrorNo = mysql_errno(pMysql);
		ErrorMsg = UTF8_TO_TCHAR(mysql_error(pMysql));

		return false;
	}
	
	// 获取影响行数
	Rows = mysql_affected_rows(pMysql);
	if (Rows == -1)
	{
		Rows = 0;
	}

	// 读取结果
	while (true)
	{
		// 返回定义
		FDTArrayMysqlResult ArrayMysqlResult;
		ArrayMysqlResult.Rows = 0;

		// 获取返回值数据
		MYSQL_RES* res = mysql_store_result(pMysql);
		if (res == NULL)
		{
			break;
		}

		// 获取列数
		int fieldCount = mysql_num_fields(res);
		TArray<FString> ArrayFieldName;

		// 获取列头
		while (true)
		{
			MYSQL_FIELD* _field = mysql_fetch_field(res);
			if (_field == NULL)
			{
				break;
			}
			ArrayFieldName.Add(UTF8_TO_TCHAR(_field->name));
		}
		if (fieldCount > ArrayFieldName.Num())
		{
			fieldCount = ArrayFieldName.Num();
		}

		// 获取列数据
		while (true)
		{
			MYSQL_ROW column = mysql_fetch_row(res);
			if (column == NULL)
			{
				break;
			}
			FDTMysqlResult DTMysqlResult;
			for (size_t i = 0; i < fieldCount; i++)
			{
				DTMysqlResult.Result.Add(ArrayFieldName[i], UTF8_TO_TCHAR(column[i]));
			}
			ArrayMysqlResult.ArrayResult.Add(DTMysqlResult);
			ArrayMysqlResult.Rows++;
			Rows++;
		}

		// 添加到返回结果
		OutResult.Add(ArrayMysqlResult);

		// 移动到下一个结果集
		if (mysql_more_results(pMysql))
		{
			mysql_next_result(pMysql);
		}
	}

	// 返回成功
	ErrorNo = 0;
	ErrorMsg = TEXT("success");

	return true;
}