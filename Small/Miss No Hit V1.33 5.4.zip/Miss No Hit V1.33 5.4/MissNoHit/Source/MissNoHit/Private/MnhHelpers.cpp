﻿// Copyright 2024 Eren Balatkan. All Rights Reserved.

#include "MnhHelpers.h"

