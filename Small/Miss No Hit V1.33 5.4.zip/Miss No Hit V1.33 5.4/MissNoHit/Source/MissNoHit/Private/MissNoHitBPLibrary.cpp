﻿// Copyright 2024 Eren Balatkan. All Rights Reserved.

#include "MissNoHitBPLibrary.h"

UMissNoHitBPLibrary::UMissNoHitBPLibrary(const FObjectInitializer& ObjectInitializer)
: Super(ObjectInitializer)
{

}
