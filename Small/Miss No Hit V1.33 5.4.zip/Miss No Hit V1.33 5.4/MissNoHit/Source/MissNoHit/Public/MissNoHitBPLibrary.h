﻿// Copyright 2024 Eren Balatkan. All Rights Reserved.

#pragma once

#include "Kismet/BlueprintFunctionLibrary.h"
#include "MissNoHitBPLibrary.generated.h"


UCLASS()
class UMissNoHitBPLibrary : public UBlueprintFunctionLibrary
{
	GENERATED_UCLASS_BODY()
};
