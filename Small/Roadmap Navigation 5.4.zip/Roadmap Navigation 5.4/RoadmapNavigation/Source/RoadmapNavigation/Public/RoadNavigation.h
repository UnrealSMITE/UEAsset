// Copyright RestrictedStudio� 2021 by Koorosh Torabi All Rights Reserved

#pragma once

#include "CoreMinimal.h"
#include "HAL/Runnable.h"
#include "GameFramework/Actor.h"
#include "RoadNavigation.generated.h"

/*
* Grid nodes struct
*/
USTRUCT(BlueprintType)
struct FNavGridNode
{
	GENERATED_BODY()

public:

	// Node Location on Grid
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Grid")
		int GridX;
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Grid")
		int GridY;
	// Z Offset in world space
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Grid")
		float ZOffset;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Linking")
		int CentralSquareX;
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Linking")
		int CentralSquareY;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Grid")
		bool bIsOnRoad;

	FNavGridNode* Parent = nullptr;

	float G = 0;
	float H = 0;
	float F = 0;

	FNavGridNode() { GridX = GridY = -1, ZOffset = -1, bIsOnRoad = false, CentralSquareX = CentralSquareY = -1; }
	FNavGridNode(int InGridX, int InGridY) { GridX = InGridX, GridY = InGridY, CentralSquareX = CentralSquareY = -1, bIsOnRoad = false; }
	// Make sure you update this one if you added any new variables to struct
	FNavGridNode(int InGridX, int InGridY, float InZOffset, bool bInIsOnRoad, int InCentralSquareX, int InCentralSquareY, FNavGridNode* InParent = nullptr, float InG = 0, float InH = 0, float InF = 0) { GridX = InGridX, GridY = InGridY, ZOffset = InZOffset, bIsOnRoad = bInIsOnRoad, G = InG, H = InH, F = InF, Parent = InParent, CentralSquareX = InCentralSquareX, CentralSquareY = InCentralSquareY; }

	// Makes the node on ram and returns it
	FNavGridNode* Clone() { return (new FNavGridNode(GridX, GridY, ZOffset, bIsOnRoad, CentralSquareX, CentralSquareY, Parent, G, H, F)); }

	void SetCentralSquare(int X, int Y) { CentralSquareX = X, CentralSquareY = Y; }
	bool IsLinked() { return (CentralSquareX != -1 || CentralSquareY != -1); }
	void Print() { UE_LOG(LogTemp, Warning, TEXT("(%d, %d, %f, %s)"), GridX, GridY, ZOffset, (bIsOnRoad ? TEXT("True") : TEXT("False"))); }

	// Serialize for saving
	FString Serialize() { return (FString::FromInt(GridX) + " " + FString::FromInt(GridY) + " " + FString::SanitizeFloat(FMath::Floor(100.0 * ZOffset) / 100.0, 0) + " " + FString::FromInt(CentralSquareX) + " " + FString::FromInt(CentralSquareY)); }

	// this one is for the FArray::Contains to work!
	friend bool operator==(const FNavGridNode& l, const FNavGridNode& r)
	{
		return (l.GridX == r.GridX && l.GridY == r.GridY);
	}

	bool IsValid() { return (GridX != -1 && GridY != -1); }
};

/*
* it handles everything, generation, finding path, syncing path with the source actor
*/
UCLASS()
class ROADMAPNAVIGATION_API ARoadNavigation : public AActor
{
	GENERATED_BODY()

private:

	// Thread Friends
	friend class TFindPath;
	friend class TFindStaticPath;
	friend class TGenerateRoadNav;

	// Sets default values for this actor's properties
	ARoadNavigation();

protected:

	// Called when the game starts or when spawned
	virtual void BeginPlay() override;

	UPROPERTY(VisibleDefaultsOnly, Category = "Components")
		class UBillboardComponent* Billboard;

	// Size of the navigation grid in world space
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Settings")
		FVector2D GridSize;
	// Each node is a square and this it the length of each square edge
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Settings")
		float NodeSize;
	// Maximum Z Offset that your roads have, this is the z offset that tracing starts from
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Settings")
		float MaxRoadZOffset;
	// Length of each line trace to find the road from the MaxRoadZOffset
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Settings")
		float TraceLength;
	// Distance from ground for each path point
	// * it should be the nav agent halfheigh for best result *
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Settings")
		float PathHeight;

	// Navigation will be generated every single time on begin play, save and load will be disabled.
	// * It is highly recommended to leave it unchecked *
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Settings|Saving")
		bool bGenerateNavigationEveryTimeOnBeginPlay;

	// The save name on disk
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Settings|Saving", meta = (EditCondition = "!bGenerateNavigationEveryTimeOnBeginPlay"))
		FString SaveName;

	// Navigation generated data directory in which all the data will be saved there
	// Use this format: Folder/SubFolder/ OR Folder/ OR ... (put a slash (/) in the end!)
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Settings|Saving", meta = (EditCondition = "!bGenerateNavigationEveryTimeOnBeginPlay"))
		FString SavesDirectory;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Settings|Saving", meta = (EditCondition = "!bGenerateNavigationEveryTimeOnBeginPlay"))
		bool bPrefixSavesWithMapName;

	// You can load a custom file in SavesDirectory
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Settings|Saving", meta = (EditCondition = "!bGenerateNavigationEveryTimeOnBeginPlay"))
		bool bCustomLoad;

	// Whenever LoadData() get called, this will be loaded (you can switch between generated data)
	// * Make sure you write the file extension (.txt) as well
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Settings|Saving", meta = (EditCondition = "!bGenerateNavigationEveryTimeOnBeginPlay && bCustomLoad"))
		FString CustomLoadFilePath;

	// The higher, the more performance in finding the road while the source or destination is not on the road
	// but it runs on a thread, so don't worry.
	// Increase it if you have so many blank space between your roads.
	// Kojekstra Algorithm will fail after crossed this number.
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Settings|Advanced")
		int MaxKojestraIterations;

	// Increase it if you have very wide roads and decrease it if you have ONLY thin roads. 
	// be careful! it has to be (3 + 2n) otherwise it will break the whole navigation
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Settings|Advanced")
		int MaxLinkingSquareSize;

	// This is used in optimizations try not to change it!
	// This is basically the max distance between each 2 points of the path
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Settings|Advanced")
		float MaxDistanceBetweenPathPoints;

	// Decrease it if you want more accurate path points
	// Used in optimizations
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Settings|Advanced")
		float MinDistanceBetweenPathPoints;

	// This will give you so many unnecessary path points.
	// * It is highly recommended to leave it unchecked *
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Settings|Advanced")
		bool DoNOT_OptimizePath;

	// Linking nodes is used to draw the path in the middle of road
	// If your roads are made of only one square then you can turn it off
	// otherwise turn it on for best result
	// * It is highly recommended to leave it unchecked *
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Settings|Advanced")
		bool DoNOT_LinkGridNodes;

	UPROPERTY(EditAnywhere, Category = "Debugging|In-Editor")
		bool bDrawGridBounds;

	UPROPERTY(EditAnywhere, Category = "Debugging|In-Editor")
		bool bDrawRoadSquares;

	UPROPERTY(EditAnywhere, Category = "Debugging|In-Editor")
		bool bDrawRoadDetectorLineTraces;

	UPROPERTY(EditAnywhere, Category = "Debugging|In-Editor")
		bool bDrawLinkedNodesConnection;

	// The colorful snowflake shape
	UPROPERTY(EditAnywhere, Category = "Debugging|In-Game")
		bool bDrawKojekstra;

	UPROPERTY(EditAnywhere, Category = "Debugging|In-Game")
		bool bDrawPathPoints;

	UPROPERTY(EditAnywhere, Category = "Debugging|In-Game")
		bool bDrawPathArrowIndicator;

	UPROPERTY(EditAnywhere, Category = "Debugging|In-Game")
		bool bDrawRemovedPathPointsDueToOptimzation;

	// Expensive debug, be careful
	UPROPERTY(EditAnywhere, Category = "Debugging|In-Game")
		bool bDrawAStarMovement;

	// Set this to null if your path is static
	// Path start will be updated with this actor
	// Without SourceActor there will be no ticking either
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Settings")
		AActor* SourceActor;

	// Finds the roads and stores them for path finding
	UFUNCTION(BlueprintCallable, Category = "Construction")
		void GenerateNavigation();

	// Save nodes data in text format under the given SavesDirectory
	UFUNCTION(BlueprintCallable, Category = "Data")
		void SaveData();

	// Loads data from SavesDirectory, CustomLoad also works with it
	UFUNCTION(BlueprintCallable, Category = "Data")
		void LoadData();

	// All the Navigation Grid Nodes, this is the main data
	UPROPERTY(BlueprintReadWrite, Category = "Data")
		TArray<FNavGridNode> Nodes;

	UFUNCTION(BlueprintImplementableEvent, CallInEditor, Category = "DO NOT CALL MANUALLY")
		void IsOnRoad();

	// Sets the road detection result from blueprint to c++
	UFUNCTION(BlueprintCallable, Category = "Road Detection")
		void SetIsOnRoadResult(float NodeZOffset, bool bIsOnRoad);

	// Sets automatically by C++, Use in Blueprint CustomeRoadDetectionLogic()
	UPROPERTY(BlueprintReadOnly, Category = "Road Detection")
		FVector RoadDetectionStartLocation;
	// Sets by C++, Use in Blueprint CustomeRoadDetectionLogic()
	UPROPERTY(BlueprintReadOnly, Category = "Road Detection")
		FVector RoadDetectionEndLocation;

public:
	// Called every frame
	virtual void Tick(float DeltaTime) override;

	// Main path finding function with syncing feature
	// Finds the path from SourceLoc to the DestinationLoc ASync
	// 
	// * Use GetPath function to get the result *
	// @param NewSourceActor if you pass null, previous SourceActor will be used and if you pass an actor, it will replace the SourceActor
	UFUNCTION(BlueprintCallable, Category = "Path Finding")
		void FindPath(AActor* NewSourceActor, FVector DestinationLoc);

	// Finds the path immediately, it may cause some lags so be careful
	// In other words, finds the path in a single frame
	UFUNCTION(BlueprintCallable, Category = "Path Finding")
		TArray<FVector> FindPathInstantly(FVector SourceLoc, FVector DestinationLoc, bool bDrawDebug = false);

	// Finds a static path (without syncing) asynchronously
	// This path finding method offers no debugging features.	
	// OnStaticPathFound event fires on path found	
	// 
	// * Use GetStaticPath function to get the result *
	UFUNCTION(BlueprintCallable, Category = "Path Finding")
		void FindStaticPathAsync(FVector SourceLoc, FVector DestinationLoc);

	// Returns path points and an active index which path will start from that index
	// If source actor pass through a path point, the ActiveIndex will increment and vice versa.
	UFUNCTION(BlueprintPure, Category = "Path Finding")
		TArray<FVector> GetPath(int& ActiveIndex);

	// Returns path points found from calling FindStaticPath	
	UFUNCTION(BlueprintPure, Category = "Path Finding")
		TArray<FVector> GetStaticPath(bool& bIsValid);

	// Set the source actor, the one which is going to move along the path
	UFUNCTION(BlueprintCallable, Category = "Setup")
		void SetSourceActor(AActor* Source);

	// Disables Ticking and Syncing actor
	// @param bResetPath: will clear out the path points
	UFUNCTION(BlueprintCallable, Category = "Power")
		void Disable(bool bResetPath = true);

	// Enables actor ticking and path syncing
	UFUNCTION(BlueprintCallable, Category = "Power")
		void Enable();

	UFUNCTION(BlueprintPure, Category = "Power")
		bool IsEnabled() { return IsActorTickEnabled(); }

	/* Events */

	// Fires when a path found
	UFUNCTION(BlueprintImplementableEvent, Category = "Events")
		void OnPathFound();

	// Fires when path finding fails
	UFUNCTION(BlueprintImplementableEvent, Category = "Events")
		void OnPathFindingFailed();

	// Fires on path finding started
	UFUNCTION(BlueprintImplementableEvent, Category = "Events")
		void OnPathFindingStarted();

	// Fires when navigation was generated | this works in-game only!
	UFUNCTION(BlueprintImplementableEvent, Category = "Events")
		void OnNavigationGenerated();

	// Fires when the static path is found
	UFUNCTION(BlueprintImplementableEvent, Category = "Events")
		void OnStaticPathFound();

	// Fires when path finding fails
	UFUNCTION(BlueprintImplementableEvent, Category = "Events")
		void OnStaticPathFindingFailed();

	// Fires on path finding started
	UFUNCTION(BlueprintImplementableEvent, Category = "Events")
		void OnStaticPathFindingStarted();

protected:

	// Simple Convertion of 2D index to 1D index
	UFUNCTION(BlueprintPure, Category = "Utility")
		int GetLinearIndex(int X, int Y) { return (Y * (NodesCount.Y - 1) + X); }

	// Converts grid x,y to world location
	UFUNCTION(BlueprintPure, Category = "Utility")
		FVector CalculateNodeWorldLocation(FNavGridNode Node);

	// Finds the adjacents if they are in perfect square shape | usage in linking
	// @param SquareLength should be an odd number and greater or equal to 3 (3 + 2n) | 3x3, 5x5, 7x7, 9x9 ...
	// @return False: it didn't have adjacents as much as count
	// @return True : if had adjacents as much as count
	UFUNCTION(BlueprintPure, Category = "Linking")
		bool GetSquareAdjacents(FNavGridNode Node, int SquareLength, TArray<FNavGridNode>& Adjacents);

	// Sets CentralSquare of all AdjNodes to CurrentNode
	UFUNCTION(BlueprintCallable, Category = "Linking")
		void SetCentralSquare(FNavGridNode CentralNode, TArray<FNavGridNode> AdjNodes);

	// Find closest linked square and link the Node to that under certain conditions!
	UFUNCTION(BlueprintCallable, Category = "Linking")
		bool LinkToNearbyCentralSquare(FNavGridNode Node);

	// Converts world location to the grid space and then return the closest Node to that point
	UFUNCTION(BlueprintPure, Category = "Grid")
		FNavGridNode FindClosestNode(FVector WorldLocation);

	// Synchronize the path with the source actor location
	UFUNCTION(BlueprintCallable, Category = "PathFinding|Synchronizing")
		void SyncPath();

	// Make sure all the path points are in front of the source actor
	UFUNCTION(BlueprintCallable, Category = "PathFinding|Synchronizing")
		void PreSyncPathWithSourceActor();

	// SyncPath uses it for detemining the source actor's movement direction
	UPROPERTY(BlueprintReadOnly, Category = "Synchronizing")
		float SourceDistanceFromPathStart = 0;

	// Debugging Purposes Only
	UPROPERTY(BlueprintReadOnly, Category = "Debugging")
		TArray<FVector> RemovedNodesDueToOptimize;

	// Debugging Purposes Only
	UPROPERTY(BlueprintReadOnly, Category = "Debugging")
		TArray<FNavGridNode> AStarVisitedNodes;

	// Debugging Purposes Only
	UPROPERTY(BlueprintReadOnly, Category = "Debugging")
		TArray<FVector> KojekstraNodesLocations;

	UFUNCTION(BlueprintCallable, Category = "Debugging")
		void DrawPathDebug(TArray<FVector> PathPoints);

	UFUNCTION(BlueprintCallable, Category = "Debugging")
		void DrawGeneratedNavigation();

	// Clears all debugging arrays
	UFUNCTION(BlueprintCallable, Category = "Debugging")
		void ClearDebugArrays();

	// Threads manager this variable's value
	UPROPERTY(BlueprintReadOnly, Category = "Status")
		bool bIsNavigationBaked = true;

	UPROPERTY(BlueprintReadOnly, Category = "Status")
		bool bIsPathFindingInProgress = false;

	UPROPERTY(BlueprintReadOnly, Category = "Status")
		bool bIsStaticPathFindingInProgress = false;

	// Changes current MaxLinkingSquare size to (3 + 2n) closest n
	UFUNCTION(BlueprintCallable, Category = "Validation")
		void ValidateMaxLinkingSquareSize();

	// Set it via FindPath function
	UPROPERTY(BlueprintReadOnly, Category = "PathFinding")
		FVector SourceLocation;

	// Set it via FindPath function
	UPROPERTY(BlueprintReadOnly, Category = "PathFinding")
		FVector	DestinationLocation;

	// Closest Node to SourceActor, index
	UPROPERTY(BlueprintReadOnly, Category = "PathFinding")
		int CurrentPathStartIndex;

	// Finds the closest road enterance while the point is not on the road
	// The algorithm will grows like a snowflake!
	UFUNCTION(BlueprintPure, Category = "PathFinding")
		FNavGridNode Kojekstra(FVector Origin);

	// Removes unnecessary path points based on 4 conditions
	UFUNCTION(BlueprintCallable, Category = "PathFinding")
		void OptimizePath(TArray<FVector>& PathPoints);

	// Invalid adjacents have Grid X and Y of -1
	// @return Adjacent array with length of 8!
	// UFUNCTION(BlueprintPure, Category = "PathFinding|A*") * Sorry, blueprint only accepts TArrays and this is faster! *
	FNavGridNode* GetAdjacentNodes(FNavGridNode Node);

	// A* heuristic
	UFUNCTION(BlueprintPure, Category = "PathFinding|A*")
		float GetDiagonalDistance(FNavGridNode A, FNavGridNode B);

	// Checks whether the point is inside of the grid or not
	UFUNCTION(BlueprintPure, Category = "PathFinding|A*")
		bool IsPointValid(FVector Point);

	// Makes the path from visited nodes by A* and reverses them (Recursive Function)
	// and stores them in PathPoints param.
	//UFUNCTION(BlueprintCallable, Category = "PathFinding|A*") * Blueprint do not accept pointers, sorry :( *
	void MakePath(FNavGridNode* PathNode, TArray<FVector>& PathPoints);

	/* Optimization functions */

	// If one's point X or Y was eqaul to the next 2 points, then remove the middle one.
	UFUNCTION(BlueprintPure, Category = "PathFinding|Optimzation")
		bool AreXsOrYsEqual(FVector Prev, FVector Current, FVector Next);

	// If delta X and delta Y of 2 points were equal it means they're diagonally aligned
	UFUNCTION(BlueprintPure, Category = "PathFinding|Optimzation")
		bool AreDiagonallyAligned(FVector Prev, FVector Current, FVector Next);

	// Max valid distance between 2 points is MaxDistanceBetweenPathPoints
	UFUNCTION(BlueprintPure, Category = "PathFinding|Optimzation")
		bool IsDistanceValid(FVector Prev, FVector Next);

	// If the distance between 2 points is less than MinDistanceBetweenPathPoints, we assume they are similar
	UFUNCTION(BlueprintPure, Category = "PathFinding|Optimzation")
		bool AreSimilar(FVector Prev, FVector Current, FVector Next);

	// Ensures all path points are in front of one another (rare case)
	UFUNCTION(BlueprintPure, Category = "PathFinding|Optimzation")
		bool AreOrderedIncorrectly(FVector Prev, FVector Current, FVector Next);

private:

	UWorld* World;

	// Road Detection | Fill by BP	
	bool bIsOnRoadResult;
	float IsOnRoadNodeZOffset;

	// The Generated path via A* and Kojestra
	// SyncPath is constantly checking and updating it
	TArray<FVector> Path;

	// Path points found using the FindPathInstantly()	
	TArray<FVector> InstantPath;

	// Path points found using the FindStaticPathAsync()	
	// Use GetStaticPath to access this variable
	TArray<FVector> StaticPath;

	// Number of Grid Nodes	
	FVector2D NodesCount;
};

// ----------------- Threads Header ------------------------

class TFindPath : public FRunnable
{
public:

	ARoadNavigation* RoadNav;

	// Constructor
	TFindPath(ARoadNavigation* InRoadNav);

	// Works
	virtual uint32 Run() override;

};

class TFindStaticPath : public FRunnable
{
public:

	ARoadNavigation* RoadNav;
	FVector SourceLoc, DestinationLoc;

	// Constructor
	TFindStaticPath(ARoadNavigation* InRoadNav, FVector SourceLocation, FVector DestinationLocation);

	// Works
	virtual uint32 Run() override;

};

class TGenerateRoadNav : public FRunnable
{
public:

	ARoadNavigation* RoadNav;

	// Constructor
	TGenerateRoadNav(ARoadNavigation* InRoadNav);

	// Works
	virtual uint32 Run() override;

};
