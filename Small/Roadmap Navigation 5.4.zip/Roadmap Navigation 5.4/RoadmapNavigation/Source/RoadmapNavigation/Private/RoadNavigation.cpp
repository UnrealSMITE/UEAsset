// Copyright RestrictedStudio� 2021 by Koorosh Torabi All Rights Reserved

#include "RoadNavigation.h"
#include "Kismet/KismetSystemLibrary.h"
#include "DrawDebugHelpers.h"
#include "HAL/RunnableThread.h"
#include "HAL/PlatformFilemanager.h"
#include "Serialization/JsonSerializerMacros.h"
#include "TimerManager.h"
#include "Engine/Engine.h"
#include "Misc/FileHelper.h"
#include "Async/AsyncWork.h"
#include "Async/Async.h"
#include "Misc/Paths.h"
#include "Components/BillboardComponent.h"

// Sets default values
ARoadNavigation::ARoadNavigation()
{
	// Set this actor to call Tick() every frame.  You can turn this off to improve performance if you don't need it.
	PrimaryActorTick.bCanEverTick = true;
	SetActorTickInterval(0.5);

	Billboard = CreateDefaultSubobject<UBillboardComponent>(TEXT("Billboard"));

	GridSize = FVector2D(50000, 50000);
	NodeSize = 400;

	MaxRoadZOffset = 5000;
	TraceLength = 10000;
	PathHeight = 100;

	SaveName = TEXT("NavData");
	SavesDirectory = TEXT("RoadNavData/");
	CustomLoadFilePath = TEXT("None");
	bPrefixSavesWithMapName = true;
	bCustomLoad = false;

	bDrawGridBounds = true;
	bDrawRoadSquares = true;
	bDrawRoadDetectorLineTraces = false;
	bDrawLinkedNodesConnection = true;
	bDrawPathPoints = true;
	bDrawKojekstra = false;
	bDrawPathArrowIndicator = true;
	bDrawRemovedPathPointsDueToOptimzation = false;
	bDrawAStarMovement = false;

	MaxKojestraIterations = 512;
	MaxLinkingSquareSize = 7;
	MaxDistanceBetweenPathPoints = 3000;
	MinDistanceBetweenPathPoints = 1500;

	CurrentPathStartIndex = 0;
}

// Called when the game starts or when spawned
void ARoadNavigation::BeginPlay()
{
	// we need this almost everywhere! for calculations and etc...
	NodesCount = FVector2D((GridSize.X / NodeSize) + 1, (GridSize.Y / NodeSize) + 1);

	World = GetWorld();

	// Disabled on default | No Ticking
	Disable();

	if (bGenerateNavigationEveryTimeOnBeginPlay)
		GenerateNavigation();
	else
		LoadData();

	// Blueprint BeginPlay
	Super::BeginPlay();
}

// Sets the road detection result from blueprint to c++
void ARoadNavigation::SetIsOnRoadResult(float NodeZOffset, bool bIsOnRoad)
{
	bIsOnRoadResult = bIsOnRoad;
	IsOnRoadNodeZOffset = NodeZOffset;
}

// Called every 0.5s (on default)
void ARoadNavigation::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);

	SyncPath();
}

// Set the source actor, the one which is going to move along the path
void ARoadNavigation::SetSourceActor(AActor* Source)
{
	SourceActor = Source;

	if (!Source && Path.Num())
		Enable();
}

// Disables Ticking and Syncing actor
// @param bResetPath: will clear out the path points
void ARoadNavigation::Disable(bool bResetPath)
{
	if (bResetPath)
		Path.Empty(0);

	SetActorTickEnabled(false);
}

// Enables actor ticking and path syncing
void ARoadNavigation::Enable()
{
	SetActorTickEnabled(true);
}

// Finds the roads and stores them for path finding
void ARoadNavigation::GenerateNavigation()
{
	World = GetWorld();

	bIsNavigationBaked = false;

	ValidateMaxLinkingSquareSize();

	TGenerateRoadNav* RoadNavGeneratorThread = new TGenerateRoadNav(this);
	FRunnableThread::Create(RoadNavGeneratorThread, TEXT("Road Navigation Generator"));

	DrawGeneratedNavigation();
}

// Save nodes data in text format under the given SavesDirectory
void ARoadNavigation::SaveData()
{
	FString Directory = FPaths::ProjectContentDir();
	IPlatformFile& FileManager = FPlatformFileManager::Get().GetPlatformFile();

	TArray<FString> StringNodes;
	// We only save the nodes that they are on the road map (we don't care about the rest!)
	for (int i = 0; i < Nodes.Num(); ++i)
		if (Nodes[i].bIsOnRoad)
			StringNodes.Add(Nodes[i].Serialize());

	if (FileManager.CreateDirectory(*Directory))
	{
		FString SavePath = Directory + "/" + SavesDirectory + (bPrefixSavesWithMapName ? World->GetName() + "_" : TEXT("")) + SaveName + ".txt";

		FText Error;
		// Validating file save path
		if (FFileHelper::IsFilenameValidForSaving(SavePath, Error))
			// Saving Data on Disk
			FFileHelper::SaveStringArrayToFile(StringNodes, *SavePath);
		else
			UE_LOG(LogTemp, Error, TEXT("%s"), *Error.ToString());

	}
}

// Loads data from SavesDirectory, CustomLoad also works with it
void ARoadNavigation::LoadData()
{
	FString Directory = FPaths::ProjectContentDir();
	IPlatformFile& FileManager = FPlatformFileManager::Get().GetPlatformFile();

	if (FileManager.CreateDirectory(*Directory))
	{
		FString SavePath = Directory + "/" + SavesDirectory;
		if (!bCustomLoad) // Automatic Loading
			SavePath += (bPrefixSavesWithMapName ? World->GetName() + "_" : TEXT("")) + SaveName + ".txt";
		else // Custom Loading
		{
			// If user forgot to add .txt at the end
			if (CustomLoadFilePath[CustomLoadFilePath.Len() - 4] != '.')
				CustomLoadFilePath += TEXT(".txt");

			SavePath += CustomLoadFilePath;
		}

		// If Data Was Saved Before
		if (FileManager.FileExists(*SavePath))
		{
			TArray<FString> SerializedNodes;
			FFileHelper::LoadFileToStringArray(SerializedNodes, *SavePath);

			Nodes.Init(FNavGridNode(), (NodesCount.X + 1) * (NodesCount.Y + 1));

			for (int i = 0; i < SerializedNodes.Num(); ++i)
			{
				FJsonSerializableArray Result;
				SerializedNodes[i].ParseIntoArray(Result, TEXT(" "));
				FNavGridNode Node = FNavGridNode(FCString::Atoi(*Result[0]), FCString::Atoi(*Result[1]), FCString::Atof(*Result[2]), true, FCString::Atoi(*Result[3]), FCString::Atoi(*Result[4]));
				Nodes[GetLinearIndex(Node.GridX, Node.GridY)] = Node;
			}
		}
		// If Loading Without Saved Data
		else
			GenerateNavigation();
	}
}

// Returns path points and an active index which path will start from that index
// If source actor pass through a path point, the ActiveIndex will increment and vice versa.
TArray<FVector> ARoadNavigation::GetPath(int& ActiveIndex)
{
	ActiveIndex = CurrentPathStartIndex;
	return Path;
}

TArray<FVector> ARoadNavigation::GetStaticPath(bool& bIsValid)
{
	bIsValid = !bIsStaticPathFindingInProgress;
	return StaticPath;
}

// Invalid adjacents have Grid X and Y of -1
// Each node has 8 neighbors (north, east, south, west, noth-east, north-west, south-east and south-west)
// @return Adjacent array with length of 8!
FNavGridNode* ARoadNavigation::GetAdjacentNodes(FNavGridNode Node)
{
	FNavGridNode* Adjacents = new FNavGridNode[8];
	int Index = 0;
	for (int x = -1; x <= 1; x++) {
		for (int y = -1; y <= 1; y++) {
			// the origin should be skipped bc we already have it
			if (x == 0 && y == 0)
				continue;

			// Adj Grid Address
			int AdjX = Node.GridX + x,
				AdjY = Node.GridY + y;

			FNavGridNode Adj(-1, -1); // Invalid as default
			if (AdjX >= 0 && AdjY >= 0 && AdjX < NodesCount.X && AdjY < NodesCount.Y)
				Adj = Nodes[GetLinearIndex(AdjX, AdjY)];

			Adjacents[Index++] = Adj;
		}
	}
	return Adjacents;
}

// Finds the adjacents if they are in perfect square shape | usage in linking
// @param SquareLength should be an odd number and greater or equal to 3 (3 + 2n) | 3x3, 5x5, 7x7, 9x9 ...
// @return False: it didn't have adjacents as much as count
// @return True : if had adjacents as much as count
bool ARoadNavigation::GetSquareAdjacents(FNavGridNode Node, int SquareLength, TArray<FNavGridNode>& Adjacents)
{
	int AdjX, AdjY;
	int Index = 0;
	int Range = SquareLength / 2;
	FNavGridNode Adj;
	for (int x = -Range; x <= Range; ++x) {
		for (int y = -Range; y <= Range; ++y) {
			// the origin should be skipped bc we already have it
			if (x == 0 && y == 0)
				continue;

			// Adj Grid Address
			AdjX = Node.GridX + x,
				AdjY = Node.GridY + y;

			Adj = FNavGridNode();

			// Return false if there wasn't an adjacent or adjacent was not walkable
			if (AdjX >= 0 && AdjY >= 0 && AdjX < NodesCount.X && AdjY < NodesCount.Y)
			{
				Adj = Nodes[GetLinearIndex(AdjX, AdjY)];
				if (!Adj.bIsOnRoad || Adj.IsLinked())
					return false;
			}
			else
				return false;

			Adjacents[Index++] = Adj;
		}
	}

	return true;
}

// Converts world location to the grid space and then return the closest Node to that point
FNavGridNode ARoadNavigation::FindClosestNode(FVector WorldLocation)
{
	// Bottom Left Corner of the Grid
	float LocX = GetActorLocation().X - GridSize.X / 2
		, LocY = GetActorLocation().Y - GridSize.Y / 2;

	// Setting Z to zero to find the XY distance between start and end	
	WorldLocation.Z = 0;

	FVector DeltaLoc = WorldLocation - FVector(LocX, LocY, 0);

	int GridX = DeltaLoc.X / NodeSize;
	int GridY = DeltaLoc.Y / NodeSize;

	if (GridX >= NodesCount.X || GridY >= NodesCount.Y || GridX < 0 || GridY < 0) // Out of Bounds Exception
		return FNavGridNode(-1, -1);

	// Because some nodes may have -1 GridX and GridY, so we make sure they have the correct location
	// This happens due to optimization policy
	auto NodeIndex = GetLinearIndex(GridX, GridY);
	Nodes[NodeIndex].GridX = GridX;
	Nodes[NodeIndex].GridY = GridY;

	return Nodes[GetLinearIndex(GridX, GridY)];
}

// Finds the closest road enterance while the point is not on the road
// The algorithm will grows like a snowflake!
FNavGridNode ARoadNavigation::Kojekstra(FVector Origin)
{
	// The case that Origin was already on the road map
	FNavGridNode OriginNode = FindClosestNode(Origin);

	if (!OriginNode.IsValid())
	{
		UE_LOG(LogTemp, Error, TEXT("Location is not the gird, please increase the grid size and bake navigation."));
		return FNavGridNode(-1, -1);
	}

	if (OriginNode.bIsOnRoad)
		return OriginNode;

	for (int i = 1; i < MaxKojestraIterations; ++i)
		for (int x = -1; x <= 1; x++)
			for (int y = -1; y <= 1; y++) {
				// the origin should be skipped bc we already have it
				if (x == 0 && y == 0)
					continue;

				int AdjX = OriginNode.GridX + (x * i)
					, AdjY = OriginNode.GridY + (y * i);

				if (AdjX >= NodesCount.X || AdjY >= NodesCount.Y || AdjX < 0 || AdjY < 0) // Out of Bounds Exception
					continue;

				// Adj Grid Address
				FNavGridNode Adj = Nodes[GetLinearIndex(AdjX, AdjY)];

				if (bDrawKojekstra) // Debug Drawing
					KojekstraNodesLocations.Add(FVector(FVector2D(CalculateNodeWorldLocation(FNavGridNode(AdjX, AdjY))), (Adj.bIsOnRoad ? MaxRoadZOffset : MaxRoadZOffset / 2)));

				if (Adj.bIsOnRoad)
					return Adj;
			}

	return FNavGridNode(-1, -1);
}

// Main path finding function with syncing feature
// Finds the path from SourceLoc to the DestinationLoc ASync
// 
// * Use GetPath function to get the result *
// @param NewSourceActor if you pass null, previous SourceActor will be used and if you pass an actor, it will replace the SourceActor
void ARoadNavigation::FindPath(AActor* NewSourceActor, FVector DestinationLoc)
{
	if (NewSourceActor)
		SourceActor = NewSourceActor;

	bool bReturn = false;
	if (!SourceActor)
	{
		UE_LOG(LogTemp, Error, TEXT("You should set a source actor if you want to use this path finding method. Set source actor with SetSourceActor() in RoadNavigation blueprint."));
		bReturn = true;
	}
	else if (!bIsNavigationBaked)
	{
		UE_LOG(LogTemp, Error, TEXT("Navigation is not baked yet, please wait."));
		bReturn = true;
	}
	else if (!IsPointValid(SourceActor->GetActorLocation()) || !IsPointValid(DestinationLoc))
	{
		UE_LOG(LogTemp, Error, TEXT("Road Path Finding Error: Route is not part of the grid!"));
		bReturn = true;
	}
	else if (bIsPathFindingInProgress)
	{
		UE_LOG(LogTemp, Error, TEXT("Another Path finding is in progress. you should wait until that's finished"));
		bReturn = true;
	}
	// Path Finding Failure
	if (bReturn)
	{
		// Event
		OnPathFindingFailed();
		return;
	}

	// Activate Path Syncing
	Enable();

	SourceLocation = SourceActor->GetActorLocation();
	DestinationLocation = DestinationLoc;

	// Debugging
	ClearDebugArrays();

	// Multi-Threading | Finding path on a thread
	TFindPath* PathFindingThread = new TFindPath(this);
	FRunnableThread::Create(PathFindingThread, TEXT("Path Finding"));
}

// Finds the path immediately, it may cause some lags so be careful (finds the path in a single frame)
TArray<FVector> ARoadNavigation::FindPathInstantly(FVector SourceLoc, FVector DestinationLoc, bool bDrawDebug)
{
	bool bReturn = false;
	if (!bIsNavigationBaked)
	{
		UE_LOG(LogTemp, Error, TEXT("Navigation is not baked yet, please wait."));
		bReturn = true;
	}
	else if (!IsPointValid(SourceLoc) || !IsPointValid(DestinationLoc))
	{
		UE_LOG(LogTemp, Error, TEXT("Road Path Finding Error: Route is not part of the grid!"));
		bReturn = true;
	}

	// Path Finding Failure
	if (bReturn)
		return TArray<FVector>();

	if (bDrawDebug)
		ClearDebugArrays();

	bool bTemp = bDrawKojekstra;
	bDrawKojekstra = bDrawDebug; // To handle draw debugging

	FNavGridNode SourceNode = Kojekstra(SourceLoc)
		, DestinationNode = Kojekstra(DestinationLoc);

	bDrawKojekstra = bTemp;

	if (!SourceNode.IsValid() || !DestinationNode.IsValid())
	{
		UE_LOG(LogTemp, Error, TEXT("There is no path between these 2 points."));

		if (bDrawDebug)
		{
			InstantPath.Empty(0);
			DrawPathDebug(InstantPath);
		}

		return TArray<FVector>();
	}

	TArray<FNavGridNode> OpenNodes /*Nodes to visit*/, ClosedNodes /*Nodes that been visited*/;

	SourceNode.G = 0;
	SourceNode.H = GetDiagonalDistance(SourceNode, DestinationNode);
	SourceNode.F = SourceNode.H;

	OpenNodes.Add(SourceNode);

	while (OpenNodes.Num() > 0)
	{
		int SelectedNodeIndex = 0;
		FNavGridNode CurrentNode = OpenNodes[0];

		// Find the node with least F cost
		for (int i = 1; i < OpenNodes.Num(); ++i)
			if (OpenNodes[i].F < CurrentNode.F)
			{
				CurrentNode = OpenNodes[i];
				SelectedNodeIndex = i;
			}

		if (bDrawAStarMovement && bDrawDebug)
			AStarVisitedNodes.Add(CurrentNode);

		if (CurrentNode == DestinationNode) // Path Found!
		{
			InstantPath.Empty(ClosedNodes.Num() /* to prevent dynamic allocation */);

			MakePath(&CurrentNode, InstantPath);

			OptimizePath(InstantPath);

			InstantPath.Shrink(); // The path's not gonna change anymore so we shrink it									

			if (bDrawDebug)
				DrawPathDebug(InstantPath);

			return InstantPath;
		}

		OpenNodes.RemoveAt(SelectedNodeIndex);
		ClosedNodes.Add(CurrentNode);

		// Length is 8 | Adjacents: N, S, E, W, NE, NW, SE, SW
		FNavGridNode* Adjacents = GetAdjacentNodes(CurrentNode);

		// Going through all adjacent nodes
		for (int i = 0; i < 8; ++i)
		{
			if (!Adjacents[i].bIsOnRoad || Adjacents[i].GridX == -1 || ClosedNodes.Contains<FNavGridNode>(Adjacents[i]))
				continue;

			Adjacents[i].G = CurrentNode.G + GetDiagonalDistance(CurrentNode, Adjacents[i]);
			Adjacents[i].H = GetDiagonalDistance(Adjacents[i], DestinationNode);
			Adjacents[i].F = Adjacents[i].G + Adjacents[i].H;
			Adjacents[i].Parent = CurrentNode.Clone(); // Because we need a ref

			if (bDrawAStarMovement && bDrawDebug) // For Debugging
				AStarVisitedNodes.Add(Adjacents[i]);

			bool bIsOpen = false;
			for (int j = 0; j < OpenNodes.Num(); ++j)
				if (Adjacents[i] == OpenNodes[j])
				{
					bIsOpen = true;
					if (Adjacents[i].G < OpenNodes[j].G) // It means there is a better path
					{
						OpenNodes.RemoveAt(j);
						bIsOpen = false;
						break;
					}
				}

			if (!bIsOpen)
				OpenNodes.Add(Adjacents[i]);
		}
	}

	UE_LOG(LogTemp, Error, TEXT("\n -- Unexpected A* Failure -- \n There is no path to destination. If you are sure that there is, then: \n - There might be some unexpected gap between the nodes! \n - Bake navigation again and observe the generated data. \n - Enable 'DrawAStarMovement' from the debugging section in RoadNavigation blueprint details panel and see where it goes. \n\n"));

	if (bDrawDebug)
	{
		InstantPath.Empty(0);
		DrawPathDebug(InstantPath);
	}

	return TArray<FVector>();
}

// Finds a static path (without syncing) asynchronously
// This path finding method offers no debugging features.	
// OnStaticPathFound event fires on path found	
// 
// * Use GetStaticPath function to get the result *
void ARoadNavigation::FindStaticPathAsync(FVector SourceLoc, FVector DestinationLoc)
{
	bool bReturn = false;
	if (!bIsNavigationBaked)
	{
		UE_LOG(LogTemp, Error, TEXT("Navigation is not baked yet, please wait."));
		bReturn = true;
	}
	else if (!IsPointValid(SourceLoc) || !IsPointValid(DestinationLoc))
	{
		UE_LOG(LogTemp, Error, TEXT("Road Path Finding Error: Route is not part of the grid!"));
		bReturn = true;
	}
	else if (bIsStaticPathFindingInProgress)
	{
		UE_LOG(LogTemp, Error, TEXT("Another Static Path finding is in progress. you should wait until that's finished"));
		bReturn = true;
	}

	// Path Finding Failure
	if (bReturn)
	{
		// Event
		OnStaticPathFindingFailed();
		return;
	}

	StaticPath.Empty();

	// Multi-Threading | Finding path on a thread
	TFindStaticPath* StaticPathFindingThread = new TFindStaticPath(this, SourceLoc, DestinationLoc);
	FRunnableThread::Create(StaticPathFindingThread, TEXT("Path Finding"));
}

void ARoadNavigation::ClearDebugArrays()
{
	if (bDrawRemovedPathPointsDueToOptimzation)
		RemovedNodesDueToOptimize.Empty(20);

	if (bDrawAStarMovement)
		AStarVisitedNodes.Empty(100);

	if (bDrawKojekstra)
		KojekstraNodesLocations.Empty(20);
}

// A* heuristic
float ARoadNavigation::GetDiagonalDistance(FNavGridNode A, FNavGridNode B)
{
	int X = FMath::Abs(A.GridX - B.GridX)
		, Y = FMath::Abs(A.GridY - B.GridY);

	float D = 1, D2 = 1;

	return D * (X + Y) + (D2 - 2 * D) * FMath::Min(X, Y);
}

// Checks whether the point is inside of the grid or not
bool ARoadNavigation::IsPointValid(FVector Point)
{
	float MaxX = GetActorLocation().X + GridSize.X / 2,
		MinX = GetActorLocation().X - GridSize.X / 2,
		MaxY = GetActorLocation().Y + GridSize.Y / 2,
		MinY = GetActorLocation().Y - GridSize.Y / 2;

	return (Point.X < MaxX&& Point.X > MinX && Point.Y < MaxY&& Point.Y > MinY);
}

// Makes the path from visited nodes by A* and reverses them (Recursive Function)
void ARoadNavigation::MakePath(FNavGridNode* PathNode, TArray<FVector>& PathPoints)
{
	if (!PathNode) return;

	FVector Location = CalculateNodeWorldLocation(
		!PathNode->IsLinked() ? *PathNode
		: Nodes[GetLinearIndex(PathNode->CentralSquareX, PathNode->CentralSquareY)]);

	MakePath(PathNode->Parent, PathPoints);

	Location.Z += PathHeight;

	// If we have a similar point already, we refuse to add it again (it happens a lot bc of CentralSquare thing!)
	if (PathPoints.Num() && PathPoints.Last() == Location)
		return;

	PathPoints.Add(Location);
}

// Removes unnecessary path points based on 4 conditions
void ARoadNavigation::OptimizePath(TArray<FVector>& PathPoints)
{
	if (DoNOT_OptimizePath) // Skip Optimization			
		return;

	for (int i = 2; i < Path.Num(); ++i)
	{
		FVector Prev = PathPoints[i - 2], Current = PathPoints[i - 1], Next = PathPoints[i];

		if (IsDistanceValid(Prev, Next)
			&&
			(AreSimilar(Prev, Current, Next) || AreXsOrYsEqual(Prev, Current, Next) || AreDiagonallyAligned(Prev, Current, Next)) || AreOrderedIncorrectly(Prev, Current, Next))
		{
			if (bDrawRemovedPathPointsDueToOptimzation)
				RemovedNodesDueToOptimize.Add(PathPoints[i - 1]);

			PathPoints.RemoveAt(i - 1);
			--i; // bc TArray shifts elements after deletion			
		}
	}
}

// If one's point X or Y was eqaul to the next 2 points, then remove the middle one.
bool ARoadNavigation::AreXsOrYsEqual(FVector Prev, FVector Current, FVector Next)
{
	return (Current.X == Next.X && Current.X == Prev.X || Current.Y == Next.Y && Current.Y == Prev.Y);
}

// If delta X and delta Y of 2 points were equal it means they're diagonally aligned
bool ARoadNavigation::AreDiagonallyAligned(FVector Prev, FVector Current, FVector Next)
{
	return (FMath::Abs(Prev.X - Current.X) == FMath::Abs(Prev.Y - Current.Y)) && (FMath::Abs(Current.X - Next.X) == FMath::Abs(Current.Y - Next.Y));
}

// Max valid distance between 2 points is MaxDistanceBetweenPathPoints
bool ARoadNavigation::IsDistanceValid(FVector Prev, FVector Next)
{
	return ((Prev - Next).Size2D() < MaxDistanceBetweenPathPoints);
}

// If the distance between 2 points is less than MinDistanceBetweenPathPoints, we assume they are similar
bool ARoadNavigation::AreSimilar(FVector Prev, FVector Current, FVector Next)
{
	return ((Current - Next).Size2D() < MinDistanceBetweenPathPoints || (Prev - Current).Size2D() < MinDistanceBetweenPathPoints);
}

// Ensures all path points are in front of one another (rare case)
bool ARoadNavigation::AreOrderedIncorrectly(FVector Prev, FVector Current, FVector Next)
{
	return (((Current - Prev).GetSafeNormal() | (Next - Current).GetSafeNormal()) < 0);
}

// Synchronize the path with the source actor location
void ARoadNavigation::SyncPath()
{
	// Sync path only works if you have a source actor
	// It should be set via blueprint, you can see it in BP_RoadNavigation
	if (!SourceActor)
	{
		Disable(false);
		return;
	}

	if (!Path.Num() || bIsPathFindingInProgress) return;

	FVector2D Source2DLocation = FVector2D(SourceActor->GetActorLocation());
	FVector2D Vec1, Vec2;
	float Dot;

	// Distance to Path
	float NewPathDistance = (Source2DLocation - FVector2D(Path[CurrentPathStartIndex])).Size();
	float DeltaDistance = NewPathDistance - SourceDistanceFromPathStart;

	if (CurrentPathStartIndex < Path.Num() - 1)
	{
		Vec1 = (FVector2D(Path[CurrentPathStartIndex]) - Source2DLocation).GetSafeNormal(),
			Vec2 = (FVector2D(Path[CurrentPathStartIndex + 1]) - FVector2D(Path[CurrentPathStartIndex])).GetSafeNormal();

		// Dot Product
		Dot = Vec1 | Vec2;

		// Passed from the Active Path Index | SourceActor's Moving along the Path (Towards Destination)
		if (Dot < 0.25)
		{
			++CurrentPathStartIndex;

			// Updating Distance to Path
			NewPathDistance = (Source2DLocation - FVector2D(Path[CurrentPathStartIndex])).Size();
		}
	}
	else if (CurrentPathStartIndex > 0 && DeltaDistance > 0)
	{
		Vec1 = (Source2DLocation - FVector2D(Path[CurrentPathStartIndex])).GetSafeNormal(),
			Vec2 = (Source2DLocation - FVector2D(Path[CurrentPathStartIndex - 1])).GetSafeNormal();

		// Dot Product
		Dot = Vec1 | Vec2;

		// SourceActor's Returning to the Previous Path Point | SourceActor's Moving in the Opposite Direction of Path
		if (Dot > 0.5)
		{
			--CurrentPathStartIndex;

			// Updating Distance to Path
			NewPathDistance = (Source2DLocation - FVector2D(Path[CurrentPathStartIndex])).Size();
		}
	}

	// Find Path Again If:
	// - Player was moving quite opposite of the path and crossed MaxDistanceBetweenPathPoints
	// 	   or
	// - Player was getting away from the end of the path
	if ((DeltaDistance > 0 && NewPathDistance > MaxDistanceBetweenPathPoints) || (CurrentPathStartIndex >= Path.Num() - 1 && NewPathDistance > MaxDistanceBetweenPathPoints * 0.75))
	{
		FindPath(nullptr, DestinationLocation);
	}

	// Storing Path distance for next tick
	SourceDistanceFromPathStart = NewPathDistance;
}

void ARoadNavigation::PreSyncPathWithSourceActor()
{
	if (!SourceActor || !Path.Num())
		return;

	FVector2D Source2DLocation = FVector2D(SourceActor->GetActorLocation());
	FVector2D Vec1, Vec2;
	float Dot;

	// Distance to Path
	float NewPathDistance = (Source2DLocation - FVector2D(Path[CurrentPathStartIndex])).Size();
	float DeltaDistance = NewPathDistance - SourceDistanceFromPathStart;

	for (int i = 0; i < Path.Num() - 1; ++i)
	{
		Vec1 = (FVector2D(Path[CurrentPathStartIndex]) - Source2DLocation).GetSafeNormal(),
			Vec2 = (FVector2D(Path[CurrentPathStartIndex + 1]) - FVector2D(Path[CurrentPathStartIndex])).GetSafeNormal();

		// Dot Product
		Dot = Vec1 | Vec2;

		// Means source actor is in front of the point
		if (Dot < 0.25)
			++CurrentPathStartIndex;
		else
			return;
	}
}

// Sets CentralSquare of all AdjNodes to CurrentNode
void ARoadNavigation::SetCentralSquare(FNavGridNode CentralNode, TArray<FNavGridNode> AdjNodes)
{
	for (int i = AdjNodes.Num() - 1; i >= 0; --i)
		Nodes[GetLinearIndex(AdjNodes[i].GridX, AdjNodes[i].GridY)]
		.SetCentralSquare(CentralNode.GridX, CentralNode.GridY);

	CentralNode.SetCentralSquare(CentralNode.GridX, CentralNode.GridY);
}

// Find closest linked square and link the Node to that under certain conditions!
bool ARoadNavigation::LinkToNearbyCentralSquare(FNavGridNode Node)
{
	for (int x = -1; x <= 1; x++) {
		for (int y = -1; y <= 1; y++) {
			// the origin should be skipped bc we already have it
			if (x == 0 && y == 0)
				continue;

			// Adj Grid Address
			int AdjX = Node.GridX + x,
				AdjY = Node.GridY + y;

			FNavGridNode Adj;
			if (AdjX >= 0 && AdjY >= 0 && AdjX < NodesCount.X && AdjY < NodesCount.Y)
			{
				Adj = Nodes[GetLinearIndex(AdjX, AdjY)];

				if (!Adj.bIsOnRoad) continue;

				if (Adj.IsLinked())
					// If the distance between nodes weren't so much
					if (FMath::Abs(Node.GridX - Adj.CentralSquareX) < MaxLinkingSquareSize / 2 && FMath::Abs(Node.GridY - Adj.CentralSquareY) < MaxLinkingSquareSize / 2)
					{
						Nodes[GetLinearIndex(Node.GridX, Node.GridY)].SetCentralSquare(Adj.CentralSquareX, Adj.CentralSquareY);
						return true;
					}
			}
		}
	}
	return false;
}

// Converts grid x,y to world location
FVector ARoadNavigation::CalculateNodeWorldLocation(FNavGridNode Node)
{
	float X = (GetActorLocation().X - GridSize.X / 2) + (NodeSize * Node.GridX + NodeSize / 2)
		, Y = (GetActorLocation().Y - GridSize.Y / 2) + (NodeSize * Node.GridY + NodeSize / 2)
		, Z = Node.ZOffset;
	return FVector(X, Y, Z);
}

// Changes current MaxLinkingSquare size to (3 + 2n) closest n
void ARoadNavigation::ValidateMaxLinkingSquareSize()
{
	int Remaining = (MaxLinkingSquareSize - 3) % 2;

	if (!Remaining) // Number was correct
		return;

	UE_LOG(LogTemp, Warning, TEXT("You chosed the wrong MaxLinkingSquareSize (it's not (3 + 2n)), I fixed it for you ;)"));

	// Update
	MaxLinkingSquareSize -= Remaining;
}

void ARoadNavigation::DrawPathDebug(TArray<FVector> PathPoints)
{
	if (!bDrawPathPoints && !bDrawKojekstra && !bDrawRemovedPathPointsDueToOptimzation && !bDrawAStarMovement && !bDrawPathArrowIndicator)
		return;

	FlushPersistentDebugLines(World);

	// Removed due to optimization logic
	if (bDrawRemovedPathPointsDueToOptimzation)
		for (int i = 0; i < RemovedNodesDueToOptimize.Num(); ++i)
			DrawDebugSphere(World, RemovedNodesDueToOptimize[i], 100, 6, FColor::Red, true, 0, 0, 10);

	// A* visited nodes
	if (bDrawAStarMovement)
		for (int i = 0; i < AStarVisitedNodes.Num(); ++i)
			DrawDebugBox(World, CalculateNodeWorldLocation(AStarVisitedNodes[i]), FVector(NodeSize / 2), FColor::Red, true, 0, 0, 10);

	if (bDrawKojekstra)
	{
		for (int i = 0; i < KojekstraNodesLocations.Num(); ++i)
			if (KojekstraNodesLocations[i].Z != MaxRoadZOffset) // Not the found point by kojekstra			
				DrawDebugBox(World, KojekstraNodesLocations[i], FVector(NodeSize / 2), FColor::MakeRandomColor(), true, -1, 0, 50);
			else
				DrawDebugLine(World, KojekstraNodesLocations[i], KojekstraNodesLocations[i] + FVector::DownVector * TraceLength, FColor::Green, true, -1, 0, 50);
	}

	// The final path
	if (bDrawPathPoints || bDrawPathArrowIndicator)
	{
		for (int i = 0; i < PathPoints.Num(); ++i)
		{
			if (i < PathPoints.Num() - 1) // Except Last Point
			{
				if (bDrawPathArrowIndicator)
				{
					// Drawing arrow between each to points
					FVector Start = PathPoints[i], End = PathPoints[i + 1];
					Start += (End - Start).GetSafeNormal() * 300;
					End += (Start - End).GetSafeNormal() * 300;
					DrawDebugDirectionalArrow(World, Start, End, 50000, FColor(10, 150, 10), true, 0, 0, 25);
				}
				if (bDrawPathPoints)
					DrawDebugSphere(World, PathPoints[i], 100, 6, FColor::Green, true, 0, 0, 10);
			}
			// Last Path Point
			else
			{
				const float ConeLength = 400;
				DrawDebugCone(World, PathPoints[i], FVector::UpVector, ConeLength, 0.5, 0.5, 6, FColor::Green, true, 0, 0, 20);
				DrawDebugCone(World, PathPoints[i] + FVector::UpVector * 1.75 * ConeLength, FVector::DownVector, ConeLength, 0.5, 0.5, 6, FColor::Green, true, 0, 0, 20);
			}
		}
	}
}

void ARoadNavigation::DrawGeneratedNavigation()
{
	if (!bDrawRoadSquares && !bDrawRoadDetectorLineTraces && !bDrawLinkedNodesConnection && !bDrawGridBounds)
		return;

	if (!bIsNavigationBaked)
	{
		World->GetTimerManager().SetTimer(*(new FTimerHandle), this, &ARoadNavigation::DrawGeneratedNavigation, 1, false);
		return;
	}

	if (bDrawGridBounds) // Drawing Navigation Bounds
	{
		FVector Loc = GetActorLocation();
		Loc.Z = MaxRoadZOffset - TraceLength / 2;
		UKismetSystemLibrary::DrawDebugBox(World, Loc, FVector(GridSize, TraceLength) / 2, FColor::Red, FRotator(), 10, 999);
	}

	for (int y = 0; y < NodesCount.Y; ++y)
		for (int x = 0; x < NodesCount.X; ++x)
		{
			auto Node = Nodes[GetLinearIndex(x, y)];

			if (!Node.bIsOnRoad) continue;

			auto NodeLoc = CalculateNodeWorldLocation(Node);

			if (bDrawRoadSquares) // Draw Road Square					
			{
				if (Node.IsLinked())
				{
					UKismetSystemLibrary::DrawDebugBox(World, NodeLoc, FVector(NodeSize / 2), FColor::MakeRandomColor(), FRotator(0), 15);
				}
				else
				{
					UKismetSystemLibrary::DrawDebugBox(World, NodeLoc, FVector(NodeSize / 2), FColor::Red, FRotator(0), 15);
				}
			}

			if (bDrawRoadDetectorLineTraces) // Draw Line Trace Debug
			{
				FVector StartLocation, EndLocation;
				StartLocation = EndLocation = FVector(NodeLoc.X, NodeLoc.Y, MaxRoadZOffset);
				EndLocation.Z -= TraceLength;
				UKismetSystemLibrary::DrawDebugLine(World, StartLocation, EndLocation, FColor::Red, 10, 2);
			}

			if (bDrawLinkedNodesConnection && Node.IsLinked()) // Drawing linked nodes connection
			{
				FVector CentralSquareLocation = FVector(CalculateNodeWorldLocation(Nodes[GetLinearIndex(Node.CentralSquareX, Node.CentralSquareY)]));
				CentralSquareLocation.Z += 2000;
				UKismetSystemLibrary::DrawDebugLine(World, NodeLoc, CentralSquareLocation, FColor::Green, 10, 40);
			}
		}
}

// ------------- THREAD CODES --------------------

// -------------------- Path Finding Thread -----------------
TFindPath::TFindPath(ARoadNavigation* InRoadNav)
{
	RoadNav = InRoadNav;
}

// Works
uint32 TFindPath::Run()
{
	// Event
	AsyncTask(ENamedThreads::GameThread, [=, this]() // Events run on game thread
		{
			RoadNav->OnPathFindingStarted();
		});

	FNavGridNode SourceNode = RoadNav->Kojekstra(RoadNav->SourceLocation)
		, DestinationNode = RoadNav->Kojekstra(RoadNav->DestinationLocation);

	if (!SourceNode.IsValid() || !DestinationNode.IsValid())
	{
		UE_LOG(LogTemp, Error, TEXT("There is no path between these 2 points."));

		// Event
		AsyncTask(ENamedThreads::GameThread, [=, this]() // Events and Renders run on game thread
			{
				RoadNav->OnPathFindingFailed();
				RoadNav->DrawPathDebug(RoadNav->Path);
			});

		return 1;
	}

	RoadNav->bIsPathFindingInProgress = true;

	TArray<FNavGridNode> OpenNodes /*Nodes to visit*/, ClosedNodes /*Nodes that been visited*/;

	SourceNode.G = 0;
	SourceNode.H = RoadNav->GetDiagonalDistance(SourceNode, DestinationNode);
	SourceNode.F = SourceNode.H;

	OpenNodes.Add(SourceNode);

	while (OpenNodes.Num() > 0)
	{
		int SelectedNodeIndex = 0;
		FNavGridNode CurrentNode = OpenNodes[0];

		// Find the node with least F cost
		for (int i = 1; i < OpenNodes.Num(); ++i)
			if (OpenNodes[i].F < CurrentNode.F)
			{
				CurrentNode = OpenNodes[i];
				SelectedNodeIndex = i;
			}

		if (RoadNav->bDrawAStarMovement)
			RoadNav->AStarVisitedNodes.Add(CurrentNode);

		if (CurrentNode == DestinationNode) // Path Found!
		{
			RoadNav->Path.Empty(ClosedNodes.Num() /* to prevent dynamic allocation */);

			RoadNav->CurrentPathStartIndex = 0;

			RoadNav->MakePath(&CurrentNode, RoadNav->Path);

			RoadNav->OptimizePath(RoadNav->Path);

			RoadNav->PreSyncPathWithSourceActor();

			RoadNav->Path.Shrink(); // The path's not gonna change anymore so we shrink it

			RoadNav->bIsPathFindingInProgress = false;

			// Event		
			AsyncTask(ENamedThreads::GameThread, [=, this]() // Events and Renders run on game thread
				{
					RoadNav->OnPathFound();
					RoadNav->DrawPathDebug(RoadNav->Path);
				});

			return 1;
		}

		OpenNodes.RemoveAt(SelectedNodeIndex);
		ClosedNodes.Add(CurrentNode);

		// Length is 8 | Adjacents: N, S, E, W, NE, NW, SE, SW
		FNavGridNode* Adjacents = RoadNav->GetAdjacentNodes(CurrentNode);

		// Going through all adjacent nodes
		for (int i = 0; i < 8; ++i)
		{
			if (!Adjacents[i].bIsOnRoad || Adjacents[i].GridX == -1 || ClosedNodes.Contains<FNavGridNode>(Adjacents[i]))
				continue;

			Adjacents[i].G = CurrentNode.G + RoadNav->GetDiagonalDistance(CurrentNode, Adjacents[i]);
			Adjacents[i].H = RoadNav->GetDiagonalDistance(Adjacents[i], DestinationNode);
			Adjacents[i].F = Adjacents[i].G + Adjacents[i].H;
			Adjacents[i].Parent = CurrentNode.Clone(); // Because we need a ref

			if (RoadNav->bDrawAStarMovement) // For Debugging
				RoadNav->AStarVisitedNodes.Add(Adjacents[i]);

			bool bIsOpen = false;
			for (int j = 0; j < OpenNodes.Num(); ++j)
				if (Adjacents[i] == OpenNodes[j])
				{
					bIsOpen = true;
					if (Adjacents[i].G < OpenNodes[j].G) // It means there is a better path
					{
						OpenNodes.RemoveAt(j);
						bIsOpen = false;
						break;
					}
				}

			if (!bIsOpen)
				OpenNodes.Add(Adjacents[i]);
		}
	}

	RoadNav->bIsPathFindingInProgress = false;

	UE_LOG(LogTemp, Error, TEXT("\n -- Unexpected A* Failure -- \n There is no path to destination. If you are sure that there is, then: \n - There might be some unexpected gap between the nodes! \n - Bake navigation again and observe the generated data. \n - Enable 'DrawAStarMovement' from the debugging section in RoadNavigation blueprint details panel and see where it goes. \n\n"));

	// Event
	AsyncTask(ENamedThreads::GameThread, [=, this]() // Events and Renders run on game thread
		{
			RoadNav->OnPathFindingFailed();
			RoadNav->DrawPathDebug(RoadNav->Path);
		});

	return 1;
}


TFindStaticPath::TFindStaticPath(ARoadNavigation* InRoadNav, FVector SourceLocation, FVector DestinationLocation)
{
	RoadNav = InRoadNav;
	SourceLoc = SourceLocation;
	DestinationLoc = DestinationLocation;
}

// Works
uint32 TFindStaticPath::Run()
{
	// Event
	AsyncTask(ENamedThreads::GameThread, [=, this]() // Events run on game thread
		{
			RoadNav->OnStaticPathFindingStarted();
		});

	bool bTemp = RoadNav->bDrawKojekstra;
	RoadNav->bDrawKojekstra = false; // Handling Debugging

	FNavGridNode SourceNode = RoadNav->Kojekstra(SourceLoc)
		, DestinationNode = RoadNav->Kojekstra(DestinationLoc);

	RoadNav->bDrawKojekstra = bTemp;

	if (!SourceNode.IsValid() || !DestinationNode.IsValid())
	{
		UE_LOG(LogTemp, Error, TEXT("There is no path between these 2 points."));

		// Event
		AsyncTask(ENamedThreads::GameThread, [=, this]() // Events run on game thread
			{
				RoadNav->OnStaticPathFindingFailed();
			});

		return 1;
	}

	RoadNav->bIsStaticPathFindingInProgress = true;

	TArray<FNavGridNode> OpenNodes /*Nodes to visit*/, ClosedNodes /*Nodes that been visited*/;

	SourceNode.G = 0;
	SourceNode.H = RoadNav->GetDiagonalDistance(SourceNode, DestinationNode);
	SourceNode.F = SourceNode.H;

	OpenNodes.Add(SourceNode);

	while (OpenNodes.Num() > 0)
	{
		int SelectedNodeIndex = 0;
		FNavGridNode CurrentNode = OpenNodes[0];

		// Find the node with least F cost
		for (int i = 1; i < OpenNodes.Num(); ++i)
			if (OpenNodes[i].F < CurrentNode.F)
			{
				CurrentNode = OpenNodes[i];
				SelectedNodeIndex = i;
			}

		if (CurrentNode == DestinationNode) // Path Found!
		{
			RoadNav->StaticPath.Empty(ClosedNodes.Num() /* to prevent dynamic allocation */);

			RoadNav->CurrentPathStartIndex = 0;

			RoadNav->MakePath(&CurrentNode, RoadNav->StaticPath);

			RoadNav->OptimizePath(RoadNav->StaticPath);

			RoadNav->StaticPath.Shrink(); // The path's not gonna change anymore so we shrink it

			RoadNav->bIsStaticPathFindingInProgress = false;

			AsyncTask(ENamedThreads::GameThread, [=, this]() // Events run on game thread
				{
					RoadNav->OnStaticPathFound();
				});

			return 1;
		}

		OpenNodes.RemoveAt(SelectedNodeIndex);
		ClosedNodes.Add(CurrentNode);

		// Length is 8 | Adjacents: N, S, E, W, NE, NW, SE, SW
		FNavGridNode* Adjacents = RoadNav->GetAdjacentNodes(CurrentNode);

		// Going through all adjacent nodes
		for (int i = 0; i < 8; ++i)
		{
			if (!Adjacents[i].bIsOnRoad || Adjacents[i].GridX == -1 || ClosedNodes.Contains<FNavGridNode>(Adjacents[i]))
				continue;

			Adjacents[i].G = CurrentNode.G + RoadNav->GetDiagonalDistance(CurrentNode, Adjacents[i]);
			Adjacents[i].H = RoadNav->GetDiagonalDistance(Adjacents[i], DestinationNode);
			Adjacents[i].F = Adjacents[i].G + Adjacents[i].H;
			Adjacents[i].Parent = CurrentNode.Clone(); // Because we need a ref			

			bool bIsOpen = false;
			for (int j = 0; j < OpenNodes.Num(); ++j)
				if (Adjacents[i] == OpenNodes[j])
				{
					bIsOpen = true;
					if (Adjacents[i].G < OpenNodes[j].G) // It means there is a better path
					{
						OpenNodes.RemoveAt(j);
						bIsOpen = false;
						break;
					}
				}

			if (!bIsOpen)
				OpenNodes.Add(Adjacents[i]);
		}
	}

	RoadNav->bIsStaticPathFindingInProgress = false;

	UE_LOG(LogTemp, Error, TEXT("\n -- Unexpected A* Failure -- \n There is no path to destination. If you are sure that there is, then: \n - There might be some unexpected gap between the nodes! \n - Bake navigation again and observe the generated data. \n - Enable 'DrawAStarMovement' from the debugging section in RoadNavigation blueprint details panel and see where it goes. \n\n"));

	// Event
	AsyncTask(ENamedThreads::GameThread, [=, this]() // Events run on game thread
		{
			RoadNav->OnStaticPathFindingFailed();
		});

	return 1;
}

// -------------------- Road Nav Generator Thread -------------------
TGenerateRoadNav::TGenerateRoadNav(ARoadNavigation* InRoadNav)
{
	RoadNav = InRoadNav;
}

// Works
uint32 TGenerateRoadNav::Run()
{
	RoadNav->NodesCount = FVector2D((RoadNav->GridSize.X / RoadNav->NodeSize) + 1, (RoadNav->GridSize.Y / RoadNav->NodeSize) + 1);
	RoadNav->Nodes.SetNum((RoadNav->NodesCount.X + 1) * (RoadNav->NodesCount.Y + 1), false);

	// We start tracing from the bottom left and go up gradually
	float CurrentX = RoadNav->GetActorLocation().X - RoadNav->GridSize.X / 2;
	float CurrentY = RoadNav->GetActorLocation().Y - RoadNav->GridSize.Y / 2;

	for (int y = 0; y < RoadNav->NodesCount.Y; ++y)
	{
		for (int x = 0; x < RoadNav->NodesCount.X; ++x)
		{
			if (GEngine)
				GEngine->AddOnScreenDebugMessage(-1, 0, FColor::Yellow, TEXT("Road Map Genearation In Progress..."));

			RoadNav->RoadDetectionStartLocation = RoadNav->RoadDetectionEndLocation = FVector(CurrentX + RoadNav->NodeSize / 2, CurrentY + RoadNav->NodeSize / 2, RoadNav->MaxRoadZOffset);
			RoadNav->RoadDetectionEndLocation.Z -= RoadNav->TraceLength;

			// Blueprint Logic to find the road
			RoadNav->IsOnRoad();

			FNavGridNode Node(x, y);

			// Blueprint fills these data
			Node.bIsOnRoad = RoadNav->bIsOnRoadResult;
			Node.ZOffset = RoadNav->IsOnRoadNodeZOffset;

			// Store the found road piece
			RoadNav->Nodes[RoadNav->GetLinearIndex(x, y)] = Node;

			CurrentX += RoadNav->NodeSize;
		}
		CurrentX = RoadNav->GetActorLocation().X - RoadNav->GridSize.X / 2;
		CurrentY += RoadNav->NodeSize;
	}

	// Skip linking if DoNOT_LinkGridNodes was true
	if (!RoadNav->DoNOT_LinkGridNodes)
	{

		if (GEngine)
			GEngine->AddOnScreenDebugMessage(-1, 2.0f, FColor::Yellow, TEXT("Linking adjacent squares to the central square."));

		int BestMaxLinkingSquareSize = RoadNav->MaxLinkingSquareSize;
		int LinkedNodesCount = 0, UnLinkedNodesCount = 0;

		// Linking all 3x3, 5x5, 7x7, ...(MaxLinkingSquareSize x MaxLinkingSquareSize) 
		// Start from the biggest one
		// Squares to each other for drawing the path line in the middle of the road
		for (int i = RoadNav->MaxLinkingSquareSize; i >= 3; i -= 2)
		{
			for (int y = 0; y < RoadNav->NodesCount.Y; ++y)
				for (int x = 0; x < RoadNav->NodesCount.X; ++x)
				{
					auto Node = RoadNav->Nodes[RoadNav->GetLinearIndex(x, y)];

					if (!Node.bIsOnRoad || Node.IsLinked()) continue;

					TArray<FNavGridNode> Adjacents;
					Adjacents.SetNum(i * i - 1, false);

					if (RoadNav->GetSquareAdjacents(Node, i, Adjacents))
						RoadNav->SetCentralSquare(Node, Adjacents), ++LinkedNodesCount;
				}

			if (!LinkedNodesCount)
				BestMaxLinkingSquareSize -= 2;
		}

		// Bad MaxLinkingSquareSize Error
		if (BestMaxLinkingSquareSize < RoadNav->MaxLinkingSquareSize - 4)
			UE_LOG(LogTemp, Error, TEXT(" Please set the 'Max Linking Square Size' to %d or %d since there is no square linked above these sizes \n and bake the navigation again afterwards."), BestMaxLinkingSquareSize + 2, BestMaxLinkingSquareSize + 4);					

		// Linking alone nearby nodes to the central square nearby them
		for (int y = 0; y < RoadNav->NodesCount.Y; ++y)
			for (int x = 0; x < RoadNav->NodesCount.X; ++x)
			{
				auto Node = RoadNav->Nodes[RoadNav->GetLinearIndex(x, y)];

				if (!Node.bIsOnRoad || Node.IsLinked()) continue;

				if (!RoadNav->LinkToNearbyCentralSquare(Node)) // Links node if possible
					++UnLinkedNodesCount;
			}

		UE_LOG(LogTemp, Warning, TEXT("There are %d unlinked nodes in the grid."), UnLinkedNodesCount);

		if (GEngine)		
			GEngine->AddOnScreenDebugMessage(-1, 3.0f, FColor::Green, TEXT("Linking Finished Successfuly."));		

	}

	RoadNav->bIsNavigationBaked = true;

	UE_LOG(LogTemp, Warning, TEXT("Road Map Generated Successfuly!"));
	if (GEngine)
		GEngine->AddOnScreenDebugMessage(-1, 5.0f, FColor::Green, TEXT("Road Map Generated Successfuly!"));


	if (!RoadNav->bGenerateNavigationEveryTimeOnBeginPlay)
	{
		RoadNav->SaveData();
		if (GEngine)
			GEngine->AddOnScreenDebugMessage(-1, 5.0f, FColor::Green, TEXT("Generated Data Saved Successfuly."));
	}

	// Event
	AsyncTask(ENamedThreads::GameThread, [=, this]() // Events and Renders run on game thread
		{
			RoadNav->OnNavigationGenerated();
		});

	// Return success
	return 0;
}
