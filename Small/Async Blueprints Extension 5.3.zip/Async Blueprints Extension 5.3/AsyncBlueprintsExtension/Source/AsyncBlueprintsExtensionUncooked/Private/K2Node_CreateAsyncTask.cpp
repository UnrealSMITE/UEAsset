// Copyright (c) 2023 Semyon Gritsenko

#include "K2Node_CreateAsyncTask.h"

#include "Tasks/AsyncTask.h"

#include "AsyncBlueprintsExtensionUncookedStyle.h"

FText UK2Node_CreateAsyncTask::GetNodeTitle(ENodeTitleType::Type TitleType) const
{
	static const FText nodeTitle = FText::FromString("Create Async Task");

	return nodeTitle;
}

FText UK2Node_CreateAsyncTask::GetTooltipText() const
{
	static const FText tooltipText = FText::FromString("Create specific async task from class");

	return tooltipText;
}

FText UK2Node_CreateAsyncTask::GetMenuCategory() const
{
	static const FText menuCategory = FText::FromString("Threading|Utility");

	return menuCategory;
}

FSlateIcon UK2Node_CreateAsyncTask::GetIconAndTint(FLinearColor& OutColor) const
{
	static const FSlateIcon icon(FAsyncBlueprintsExtensionUncookedStyle::getStyleSetName(), "AsyncBlueprintsExtensionUncookedStyle.NodeIcon");

	return icon;
}

UClass* UK2Node_CreateAsyncTask::GetClassPinBaseClass() const
{
	return UAsyncTask::StaticClass();
}
