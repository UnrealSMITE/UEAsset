// Copyright (c) 2023 Semyon Gritsenko

#include "AsyncBlueprintsExtensionUncooked.h"

#include "AsyncBlueprintsExtensionUncookedStyle.h"

void FAsyncBlueprintsExtensionUncookedModule::StartupModule()
{
    FAsyncBlueprintsExtensionUncookedStyle::initialize();

    FAsyncBlueprintsExtensionUncookedStyle::reloadTextures();
}

void FAsyncBlueprintsExtensionUncookedModule::ShutdownModule()
{
    FAsyncBlueprintsExtensionUncookedStyle::shutdown();
}

IMPLEMENT_MODULE(FAsyncBlueprintsExtensionUncookedModule, AsyncBlueprintsExtensionUncooked)
