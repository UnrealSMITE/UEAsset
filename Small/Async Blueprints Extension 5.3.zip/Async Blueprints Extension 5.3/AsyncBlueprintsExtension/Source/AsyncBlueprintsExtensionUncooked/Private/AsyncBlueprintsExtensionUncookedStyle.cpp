// Copyright (c) 2023 Semyon Gritsenko

#include "AsyncBlueprintsExtensionUncookedStyle.h"

#include "Styling/SlateStyleRegistry.h"
#include "Framework/Application/SlateApplication.h"
#include "Slate/SlateGameResources.h"
#include "Interfaces/IPluginManager.h"

TSharedPtr<FSlateStyleSet> FAsyncBlueprintsExtensionUncookedStyle::styleInstance = nullptr;

TSharedRef<FSlateStyleSet> FAsyncBlueprintsExtensionUncookedStyle::create()
{
	TSharedRef<FSlateStyleSet> style = MakeShareable(new FSlateStyleSet(FAsyncBlueprintsExtensionUncookedStyle::getStyleSetName()));

	style->SetContentRoot(IPluginManager::Get().FindPlugin("AsyncBlueprintsExtension")->GetBaseDir() / TEXT("Resources"));

	style->Set
	(
		"AsyncBlueprintsExtensionUncookedStyle.NodeIcon",
		new FSlateImageBrush(style->RootToContentDir("NodeIcon16", TEXT(".png")), FVector2D(16.0f))
	);

	return style;
}

void FAsyncBlueprintsExtensionUncookedStyle::initialize()
{
	if (!styleInstance.IsValid())
	{
		styleInstance = create();

		FSlateStyleRegistry::RegisterSlateStyle(*styleInstance);
	}
}

void FAsyncBlueprintsExtensionUncookedStyle::shutdown()
{
	FSlateStyleRegistry::UnRegisterSlateStyle(*styleInstance);

	styleInstance.Reset();
}

void FAsyncBlueprintsExtensionUncookedStyle::reloadTextures()
{
	if (FSlateApplication::IsInitialized())
	{
		FSlateApplication::Get().GetRenderer()->ReloadTextureResources();
	}
}

const ISlateStyle& FAsyncBlueprintsExtensionUncookedStyle::get()
{
	return *styleInstance;
}

FName FAsyncBlueprintsExtensionUncookedStyle::getStyleSetName()
{
	static FName styleSetName("AsyncBlueprintsExtensionUncookedStyle");

	return styleSetName;
}
