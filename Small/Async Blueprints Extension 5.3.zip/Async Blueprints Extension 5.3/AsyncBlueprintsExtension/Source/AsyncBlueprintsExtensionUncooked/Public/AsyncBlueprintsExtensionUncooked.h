// Copyright (c) 2023 Semyon Gritsenko

#pragma once

#include "Modules/ModuleManager.h"

class FAsyncBlueprintsExtensionUncookedModule : public IModuleInterface
{
public:
    FAsyncBlueprintsExtensionUncookedModule() = default;

	void StartupModule() override;

	void ShutdownModule() override;

    ~FAsyncBlueprintsExtensionUncookedModule() = default;
};
