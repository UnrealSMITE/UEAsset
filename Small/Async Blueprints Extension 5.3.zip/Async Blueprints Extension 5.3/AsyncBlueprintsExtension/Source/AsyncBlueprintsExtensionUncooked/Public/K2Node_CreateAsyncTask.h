// Copyright (c) 2023 Semyon Gritsenko

#pragma once

#include "CoreMinimal.h"

#include "K2Node_GenericCreateObject.h"

#include "K2Node_CreateAsyncTask.generated.h"

UCLASS()
class ASYNCBLUEPRINTSEXTENSIONUNCOOKED_API UK2Node_CreateAsyncTask : public UK2Node_GenericCreateObject
{
	GENERATED_BODY()
	
protected:
	FText GetNodeTitle(ENodeTitleType::Type TitleType) const override;

	FText GetTooltipText() const override;

	FText GetMenuCategory() const override;

	FSlateIcon GetIconAndTint(FLinearColor& OutColor) const override;

public:
	UK2Node_CreateAsyncTask() = default;

	UClass* GetClassPinBaseClass() const override;

	~UK2Node_CreateAsyncTask() = default;
};
