// Copyright (c) 2022 Semyon Gritsenko

#pragma once

#include "CoreMinimal.h"

#include "UObject/NoExportTypes.h"
#include "Misc/QueuedThreadPool.h"

#include "Tasks/AsyncTask.h"

#include "AsyncTasksManager.generated.h"

DECLARE_DYNAMIC_DELEGATE(FStatelessAsyncTaskCallback);

DECLARE_DYNAMIC_DELEGATE_OneParam(FStatefulAsyncTaskCallback, UAsyncTask*, task);

DECLARE_DYNAMIC_DELEGATE(FGameThreadFunction);

/**
 * Handle async task instances
 */
UCLASS()
class ASYNCBLUEPRINTSEXTENSION_API UAsyncTasksManager : public UObject
{
	GENERATED_BODY()

private:
	TArray<UAsyncTask*> tasks;
	FCriticalSection tasksMutex;
	FQueuedThreadPool* threadPool;

private:
	UAsyncTasksManager() = default;

	~UAsyncTasksManager() = default;
	
public:
	static UAsyncTasksManager& get();

	void addTask(UAsyncTask* task);

	void removeTask(UAsyncTask* task);

	/**
	* Stop and wait task
	*/
	UFUNCTION(Category = "Threading|Async", BlueprintCallable)
	void stopAndWaitTask(UAsyncTask* task);

	/**
	* Stop and wait for all tasks
	*/
	UFUNCTION(Category = "Threading|Async", BlueprintCallable)
	void clearAllTasks();

	/**
	* Stop and wait for all infinite tasks
	*/
	UFUNCTION(Category = "Threading|Async", BlueprintCallable)
	void clearInfiniteTasks();

	bool createThreadPool(int32 threadsNumber, int32 stackSize = 32768, const FString& threadPoolName = "UnknownThreadPool");

	void destroyThreadPool();

	FQueuedThreadPool* getThreadPool();
};
