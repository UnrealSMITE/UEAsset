// Copyright (c) 2022 Semyon Gritsenko

#pragma once

#include "CoreMinimal.h"

#include "AsyncTask.h"

#include "LongAsyncTask.generated.h"

/**
 * Base class for long tasks
 */
UCLASS(Category = "Threading|Async", Abstract, Blueprintable, BlueprintType)
class ASYNCBLUEPRINTSEXTENSION_API ULongAsyncTask : public UAsyncTask
{
	GENERATED_BODY()
	
protected:
	virtual void startThread(TFunction<void()>&& callback) override;

public:
	ULongAsyncTask() = default;

	virtual ~ULongAsyncTask() = default;
};
