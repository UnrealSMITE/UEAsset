// Copyright (c) 2022 Semyon Gritsenko

#pragma once

#include "CoreMinimal.h"

#include "UObject/NoExportTypes.h"

#include "AsyncTask.generated.h"

/**
* Base async task class
*/
UCLASS(Category = "Threading|Async", Abstract, BlueprintType)
class ASYNCBLUEPRINTSEXTENSION_API UAsyncTask : public UObject
{
	GENERATED_BODY()

protected:
	/**
	* Running state
	*/
	UPROPERTY(Category = "Threading|Async", BlueprintReadOnly, Meta = (AllowPrivateAccess))
	bool isStillRunning;

	TFuture<void> future;

protected:
	virtual void startThread(TFunction<void()>&& callback);

	virtual void stopThread();

public:
	UAsyncTask();

	/**
	* Called before Execute
	*/
	UFUNCTION(Category = Initialization, BlueprintImplementableEvent)
	void initialization();

	/**
	* This method will run asynchronously in another thread
	*/
	UFUNCTION(Category = Async, BlueprintImplementableEvent)
	void execute();

	/**
	 * Most world functions(GetAllActorsOfClass, SpawnActorFromClass) must be called in game thread
	*/
	UFUNCTION(Category = Utility, BlueprintCallable)
	bool isWorldAvailable() const;

	virtual bool run(TFunction<void()>&& callback);

	virtual void stop();

	virtual UWorld* GetWorld() const override;

	virtual ~UAsyncTask() = default;
};
