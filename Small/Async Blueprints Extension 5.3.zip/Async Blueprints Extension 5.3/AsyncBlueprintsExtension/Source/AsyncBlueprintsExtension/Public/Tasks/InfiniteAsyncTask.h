// Copyright (c) 2022 Semyon Gritsenko

#pragma once

#include "CoreMinimal.h"

#include "Tasks/LongAsyncTask.h"

#include "InfiniteAsyncTask.generated.h"

/**
 * Base class for infinite tasks
 */
UCLASS(Category = "Threading|Async", Abstract, Blueprintable, BlueprintType)
class ASYNCBLUEPRINTSEXTENSION_API UInfiniteAsyncTask : public ULongAsyncTask
{
	GENERATED_BODY()

protected:
	virtual void startThread(TFunction<void()>&& callback) override;

public:
	UInfiniteAsyncTask() = default;

	/**
	* Stop task
	*/
	UFUNCTION(Category = "Threding|Async", BlueprintCallable)
	void stop() override;

	virtual ~UInfiniteAsyncTask() = default;
};
