// Copyright (c) 2022 Semyon Gritsenko

#pragma once

#include "Modules/ModuleManager.h"

DECLARE_LOG_CATEGORY_EXTERN(LogAsyncBlueprintsExtension, Display, All);

class FAsyncBlueprintsExtensionModule : public IModuleInterface
{
public:
	void StartupModule() override;

	void ShutdownModule() override;
};
