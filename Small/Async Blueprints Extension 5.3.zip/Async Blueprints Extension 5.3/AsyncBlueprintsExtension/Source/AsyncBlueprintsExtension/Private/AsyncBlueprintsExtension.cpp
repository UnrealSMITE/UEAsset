// Copyright (c) 2022 Semyon Gritsenko

#include "AsyncBlueprintsExtension.h"

#include "Kismet/GameplayStatics.h"

DEFINE_LOG_CATEGORY(LogAsyncBlueprintsExtension);

void FAsyncBlueprintsExtensionModule::StartupModule()
{
	if (!FPlatformProcess::SupportsMultithreading())
	{
		UE_LOG(LogAsyncBlueprintsExtension, Error, TEXT("Platform %s does not support multithreading"), *UGameplayStatics::GetPlatformName());
	}
}

void FAsyncBlueprintsExtensionModule::ShutdownModule()
{
	
}

IMPLEMENT_MODULE(FAsyncBlueprintsExtensionModule, AsyncBlueprintsExtension)
