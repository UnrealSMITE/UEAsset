// Copyright (c) 2022 Semyon Gritsenko

#include "Tasks/InfiniteAsyncTask.h"

#include "Async/Async.h"

void UInfiniteAsyncTask::startThread(TFunction<void()>&& callback)
{
	future = Async
	(
		EAsyncExecution::Thread,
		[this]()
		{
			while (isStillRunning)
			{
				this->execute();
			}
		},
		MoveTemp(callback)
	);
}

void UInfiniteAsyncTask::stop()
{
	Super::stop();
}
