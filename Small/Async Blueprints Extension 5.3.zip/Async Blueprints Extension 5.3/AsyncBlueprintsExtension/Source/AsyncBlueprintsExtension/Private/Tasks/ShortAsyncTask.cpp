// Copyright (c) 2022 Semyon Gritsenko

#include "Tasks/ShortAsyncTask.h"

#include "Async/Async.h"

#include "AsyncTasksManager.h"

void UShortAsyncTask::startThread(TFunction<void()>&& callback)
{
	FQueuedThreadPool* threadPool = UAsyncTasksManager::get().getThreadPool();
	TPromise<void> promise(MoveTemp(callback));
	
	future = promise.GetFuture();

	threadPool->AddQueuedWork(new TAsyncQueuedWork<void>([this]() { this->execute(); }, MoveTemp(promise)));
}

void UShortAsyncTask::stopThread()
{
	future.Wait();
}
