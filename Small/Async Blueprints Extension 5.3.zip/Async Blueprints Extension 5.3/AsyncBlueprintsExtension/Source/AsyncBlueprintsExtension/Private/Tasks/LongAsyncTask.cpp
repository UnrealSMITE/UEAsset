// Copyright (c) 2022 Semyon Gritsenko

#include "Tasks/LongAsyncTask.h"

#include "Async/Async.h"

void ULongAsyncTask::startThread(TFunction<void()>&& callback)
{
	future = Async(EAsyncExecution::Thread, [this]() { this->execute(); }, MoveTemp(callback));
}
