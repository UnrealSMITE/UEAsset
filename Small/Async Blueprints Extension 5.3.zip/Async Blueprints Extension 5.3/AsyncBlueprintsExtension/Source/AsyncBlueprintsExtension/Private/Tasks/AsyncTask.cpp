// Copyright (c) 2022 Semyon Gritsenko

#include "Tasks/AsyncTask.h"

#include "Engine/Engine.h"

#include "AsyncTasksManager.h"

void UAsyncTask::startThread(TFunction<void()>&& callback)
{
	PURE_VIRTUAL(&UAsyncTask::startThread);
}

void UAsyncTask::stopThread()
{
	PURE_VIRTUAL(&UAsyncTask::stopThread);
}

UAsyncTask::UAsyncTask() :
	isStillRunning(false)
{

}

bool UAsyncTask::run(TFunction<void()>&& callback)
{
	this->initialization();

	isStillRunning = true;

	this->startThread(MoveTemp(callback));

	UAsyncTasksManager::get().addTask(this);

	return true;
}

void UAsyncTask::stop()
{
	isStillRunning = false;

	future.Wait();
}

bool UAsyncTask::isWorldAvailable() const
{
	return static_cast<bool>(GetWorld());
}

UWorld* UAsyncTask::GetWorld() const
{
	return GEngine && !HasAnyFlags(RF_ClassDefaultObject) ? GEngine->GetWorldFromContextObject(GetOuter(), EGetWorldErrorMode::ReturnNull) : nullptr;
}
