// Copyright (c) 2022 Semyon Gritsenko

#include "AsyncTasksManager.h"

#include "Algo/Reverse.h"

#include "Tasks/ShortAsyncTask.h"
#include "Tasks/InfiniteAsyncTask.h"

UAsyncTasksManager& UAsyncTasksManager::get()
{
	static UAsyncTasksManager* tasksManager = nullptr;

	if (!tasksManager && StaticCast<bool>(GetTransientPackage()))
	{
		tasksManager = NewObject<UAsyncTasksManager>();
		tasksManager->threadPool = nullptr;

		tasksManager->AddToRoot();
	}

	return *tasksManager;
}

void UAsyncTasksManager::addTask(UAsyncTask* task)
{
	FScopeLock lock(&tasksMutex);

	task->AddToRoot();

	tasks.Add(task);
}

void UAsyncTasksManager::removeTask(UAsyncTask* task)
{
	FScopeLock lock(&tasksMutex);

	tasks.RemoveSingle(task);

	task->RemoveFromRoot();
}

void UAsyncTasksManager::stopAndWaitTask(UAsyncTask* task)
{
	task->stop();

	this->removeTask(task);
}

void UAsyncTasksManager::clearAllTasks()
{
	FScopeLock lock(&tasksMutex);

	for (UAsyncTask* task : tasks)
	{
		task->stop();

		task->RemoveFromRoot();
	}

	tasks.Empty();
}

void UAsyncTasksManager::clearInfiniteTasks()
{
	FScopeLock lock(&tasksMutex);
	TArray<UInfiniteAsyncTask*> tasksToRemove;

	for (UAsyncTask* task : tasks)
	{
		if (UInfiniteAsyncTask* infiniteTask = Cast<UInfiniteAsyncTask>(task))
		{
			tasksToRemove.Add(infiniteTask);

			task->stop();
		}
	}

	for (UInfiniteAsyncTask* task : tasksToRemove)
	{
		tasks.RemoveSingle(task);

		task->RemoveFromRoot();
	}
}

bool UAsyncTasksManager::createThreadPool(int32 threadsNumber, int32 stackSize, const FString& threadPoolName)
{
	if (threadPool)
	{
		delete threadPool;
	}

	threadPool = FQueuedThreadPool::Allocate();

	return threadPool->Create(threadsNumber, stackSize, EThreadPriority::TPri_Normal, *threadPoolName);
}

void UAsyncTasksManager::destroyThreadPool()
{
	if (threadPool)
	{
		delete threadPool;
	}

	threadPool = nullptr;
}

FQueuedThreadPool* UAsyncTasksManager::getThreadPool()
{
	return threadPool ? threadPool : GThreadPool;
}
