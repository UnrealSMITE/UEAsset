// Copyright 2021 ls Sun, Inc. All Rights Reserved.


#include "FileIOBlueprintFunctionLibrary.h"
#include "GameFramework/PlayerController.h"

AActor* UFileIOBlueprintFunctionLibrary::LoadFileAsync2StaticMeshActor(const FString& filePath, UWorld* world)
{
    if (!world)world = GWorld;
    TWeakObjectPtr<AActor> weakActor = FileIO::LoadFileAsyncStatic(filePath,world,nullptr,nullptr);
    return weakActor.Get();
}

AActor* UFileIOBlueprintFunctionLibrary::LoadFileAsync2ProceduralMeshActor(const FString& filePath, UWorld* world)
{
    if (!world)world = GWorld;
    TWeakObjectPtr<AActor> weakActor = FileIO::LoadFileAsync(filePath, world, nullptr, nullptr);
    return weakActor.Get();
}

AActor* UFileIOBlueprintFunctionLibrary::LoadFileSync2StaticMeshActor(const FString& filePath, UWorld* world)
{
    if (!world)world = GWorld;
    TWeakObjectPtr<AActor> weakActor = FileIO::LoadFileSyncStatic(filePath, world, nullptr, nullptr);
    return weakActor.Get();
}

AActor* UFileIOBlueprintFunctionLibrary::LoadFileSync2ProceduralMeshActor(const FString& filePath, UWorld* world)
{
    if (!world)world = GWorld;
    FileIO::FileImporter fip(filePath);
    fip.Load();
    AActor *actor = fip.MakeAsset(world);
    return actor;
}

void UFileIOBlueprintFunctionLibrary::FocusActor(AActor* actor)
{
	if (!actor)return;
	APlayerController* pController = actor->GetWorld()->GetFirstPlayerController();
	if (!pController)return;
	APawn* pPawn = pController->GetPawn();
	if (!pPawn)return;

	FBox box = FileIO::GetActorBoundWithChildren(actor);
	if (!box.IsValid)return;
	FVector orig = box.GetCenter();
	float Radius = box.GetExtent().Size() * 2;
	const float HalfFOVRadians = FMath::DegreesToRadians(90.f / 2);

	FVector vForward = pController->PlayerCameraManager->GetActorForwardVector();// pPawn->GetActorForwardVector();
	const float DistanceFromSphere = Radius / FMath::Tan(HalfFOVRadians);
	FVector newOrig = orig - DistanceFromSphere * vForward;
	pPawn->SetActorLocation(newOrig);
}