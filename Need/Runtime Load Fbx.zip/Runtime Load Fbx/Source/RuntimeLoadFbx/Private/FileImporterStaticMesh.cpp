// Copyright 2021 ls Sun, Inc. All Rights Reserved.


#include "FileImporterStaticMesh.h"
#include <Components/StaticMeshComponent.h>
#include <Async/TaskGraphInterfaces.h>
#include <Materials/MaterialInterface.h>
#include <Materials/MaterialInstanceDynamic.h>
#include <HAL/FileManager.h>
#include "PhysicsEngine/BodySetup.h"

using namespace FileIO;

class AsyncDataStatic
{
    static void CreateActorWithMatrixAndComponent(TWeakObjectPtr<UWorld> world, AActor*& pActorCreated, MeshIO::InterMesh* mesh)
    {
        bool bHaveMeshComponent = mesh->psubmeshs > 0;
        pActorCreated = CreateActor(world, !bHaveMeshComponent);

        FName fname(UTF8_TO_TCHAR(mesh->strNode));
        //�����mesh�򴴽����
        if (bHaveMeshComponent)
        {
            //FBX���־���ת���־������UE4Դ�룺FbxUtilsImport.cpp/FFbxDataConverter::ConvertMatrix
            //{
            FPlane inx(mesh->matrix[0], -mesh->matrix[1], mesh->matrix[2], mesh->matrix[3]);
            FPlane iny(-mesh->matrix[4], mesh->matrix[5], -mesh->matrix[6], -mesh->matrix[7]);
            FPlane inz(mesh->matrix[8], -mesh->matrix[9], mesh->matrix[10], mesh->matrix[11]);
            FPlane inw(mesh->matrix[12], -mesh->matrix[13], mesh->matrix[14], mesh->matrix[15]);
            FMatrix fMat(inx, iny, inz, inw);
            FTransform transform(fMat);

            //}

            UStaticMeshComponent* MeshCmp = NewObject<UStaticMeshComponent>(pActorCreated, fname);
            USceneComponent* parentComponent = pActorCreated->GetRootComponent();
            if (parentComponent)
            {
                MeshCmp->AttachToComponent(parentComponent, FAttachmentTransformRules::KeepRelativeTransform);
            }
            else
            {
                pActorCreated->SetRootComponent(MeshCmp);
            }
            MeshCmp->RegisterComponent();
            pActorCreated->SetActorTransform(transform);

        }
    }

    AActor* GameThreadCreateActor(MeshIO::InterMesh* mesh)
    {
        AActor* pActorCreated = 0;
        TWeakObjectPtr<UWorld> world = _world;

        if (!ReadFileTask.IsValid())
        {
            CreateActorWithMatrixAndComponent(world, pActorCreated, mesh);
        }
        else
        {
            FGraphEventRef task = FFunctionGraphTask::CreateAndDispatchWhenReady([world, &pActorCreated, mesh]()
                {
                    CreateActorWithMatrixAndComponent(world, pActorCreated, mesh);
                }, TStatId(), NULL, ENamedThreads::GameThread);

            FTaskGraphInterface::Get().WaitUntilTaskCompletes(task);
        }
        return pActorCreated;
    }

    static void GameThreadSetMeshMat(UMeshComponent* MeshCmp, int i, UMaterialInterface* pMat)
    {
        FFunctionGraphTask::CreateAndDispatchWhenReady([MeshCmp, i, pMat]()
            {
                MeshCmp->SetMaterial(i, pMat);
            }, TStatId(), NULL, ENamedThreads::GameThread);
    }

    void createFileActor(TArray<AActor*>& meshActors, const MeshIO::MeshVector& meshs)
    {
        for (int i = 0; i < meshs.count; ++i)
        {
            MeshIO::InterMesh* mesh = meshs.pMeshs[i];
            AActor* pchild = createAMesh(mesh);
            meshActors.Add(pchild);
        }
    }

    static void MakeRenderThreadBusy(FEvent* eventWait)
    {
        FGraphEventRef task = FFunctionGraphTask::CreateAndDispatchWhenReady([eventWait]()
        {
            eventWait->Wait(MAX_uint32);
            FPlatformProcess::ReturnSynchEventToPool(eventWait);
        }, TStatId(), NULL, ENamedThreads::ActualRenderingThread);
    }

    static void CreteStaticMesh(UStaticMeshComponent* MeshCmp, const FMeshDescription& MeshDescriptionOrg
        , const TArray<UMaterialInterface*>& sectionsMat)
    {
        FMeshDescription MeshDescription = MeshDescriptionOrg;
        // If we got some valid data.
        if (MeshDescription.Polygons().Num() > 0)
        {
            FString sName = MeshCmp->GetName();
            // Then find/create it.
            UPackage* Package = GetTransientPackage();//CreatePackage(TEXT("Game/MeshIO/Meshs"));
            check(Package);

            // Create StaticMesh object
            //UStaticMesh* StaticMesh = NewObject<UStaticMesh>(Package, NAME_None, RF_Public | RF_Standalone);
            UStaticMesh* StaticMesh = NewObject<UStaticMesh>(MeshCmp, *sName/*, RF_Public | RF_Standalone*/);
            /*StaticMesh->InitResources();
            StaticMesh->LightingGuid = FGuid::NewGuid();*/

            //���Ӳ��ʲ�ƥ������������
            FStaticMeshAttributes AttributeGetter(MeshDescription);
            TPolygonGroupAttributesRef<FName> PolygonGroupNames = AttributeGetter.GetPolygonGroupMaterialSlotNames();
            for (int i = 0; i < sectionsMat.Num(); ++i)
            {
                UMaterialInterface* pMat = sectionsMat[i];
                //StaticMesh->StaticMaterials.Add(FStaticMaterial(pMat));
                PolygonGroupNames[FPolygonGroupID(i)] = StaticMesh->AddMaterial(pMat);
            }
            TArray<const FMeshDescription*> MeshDescriptions;
            MeshDescriptions.Add(&MeshDescription);
            UStaticMesh::FBuildMeshDescriptionsParams Params;
            Params.bBuildSimpleCollision = false;
            Params.bMarkPackageDirty = false;
#if WITH_EDITOR

#else
            Params.bFastBuild = true;
            FEvent* sevent = FPlatformProcess::GetSynchEventFromPool(false);
			MakeRenderThreadBusy(sevent);
#endif

            

            StaticMesh->BuildFromMeshDescriptions(MeshDescriptions, Params);

            UBodySetup* NewBodySetup = StaticMesh->GetBodySetup();
            if (NewBodySetup)
            {
				NewBodySetup->CollisionTraceFlag = CTF_UseComplexAsSimple;
				StaticMesh->bAllowCPUAccess = true;
				MeshCmp->SetStaticMesh(StaticMesh);
            }

            //���Build+SetStaticMesh���ͷŶ�Render�̵߳�ռ��
#if WITH_EDITOR
#else
            sevent->Trigger();
#endif

            //MeshCmp->BodyInstance.UpdateTriMeshVertices(vertexsAll);
            //MeshCmp->UpdateCollisionFromStaticMesh();
        }
    }
    FGraphEventRef CreateStaticMeshFromDescription(UStaticMeshComponent* MeshCmp,const FMeshDescription& MeshDescriptionOrg
    , const TArray<UMaterialInterface*>& sectionsMat)
    {
        FGraphEventRef task;
        if (IsInGameThread())
        {
            CreteStaticMesh(MeshCmp,MeshDescriptionOrg,sectionsMat);
        }
        else
        {
            task = FFunctionGraphTask::CreateAndDispatchWhenReady([MeshCmp, MeshDescriptionOrg, sectionsMat]()
                {
                    CreteStaticMesh(MeshCmp, MeshDescriptionOrg, sectionsMat);
                }, TStatId(), NULL, ENamedThreads::GameThread);
        }
        return task;
    }

    AActor* createAMesh(MeshIO::InterMesh* mesh)
    {
        AActor* actor = GameThreadCreateActor(mesh);
        //actor->Rename(UTF8_TO_TCHAR(mesh->strNode));
        //��������
        {
            if (mesh->submeshCount > 0)
            {
                CreateUMesh(actor, mesh);
            }
        }
        //������
        TArray<AActor*> children;
        createFileActor(children, mesh->vChildrend);

        if (IsInGameThread())
        {
            for (AActor* child : children)
            {
                child->AttachToActor(actor, FAttachmentTransformRules::KeepWorldTransform);
            }
        }
        else
        {
            FGraphEventRef AttachTask = FFunctionGraphTask::CreateAndDispatchWhenReady([actor, children]()
                {
                    for (AActor* child : children)
                    {
                        child->AttachToActor(actor, FAttachmentTransformRules::KeepWorldTransform);
                    }
                }, TStatId(), NULL, ENamedThreads::GameThread);

            _AllParseTasks.Add(AttachTask);
        }
        return actor;
    }

    void CreateUMesh(TWeakObjectPtr<AActor> weakActor, MeshIO::InterMesh* mesh)
    {
        AActor* actor = weakActor.Get();
        if (!actor || !mesh || mesh->submeshCount < 1)return;

        UStaticMeshComponent* MeshCmp = Cast<UStaticMeshComponent>(actor->GetComponentByClass(UStaticMeshComponent::StaticClass()));
        if (!MeshCmp)return;
        //////////////////////////////////////////////////////////////////////////
        TArray<UMaterialInterface*> sectionsMat;
        FileMats* fileMats = &_fileMats;
        TArray<FVector> vertexsAllCollision;
        TArray<int32> indexsAllCollision;
        FMeshDescription MeshDescription = BuildMeshDescriptionFromInterMesh(mesh, fileMats, sectionsMat);
        FGraphEventRef createMeshTask = CreateStaticMeshFromDescription(MeshCmp,MeshDescription, sectionsMat);
        _AllParseTasks.Add(createMeshTask);

        /*for (int i = 0; i < matIDs.Num(); ++i)
        {
            int nMatId = matIDs[i];
            FGraphEventRef task2 = FFunctionGraphTask::CreateAndDispatchWhenReady([MeshCmp, i, nMatId, fileMats]()
                {
                    UMaterialInterface* pMat = fileMats->getMat(nMatId);
                    GameThreadSetMeshMat(MeshCmp, i, pMat);
                }, TStatId(), NULL, ENamedThreads::AnyBackgroundThreadNormalTask);
            _AllParseTasks.Add(task2);
        }*/

    }


public:
    FGraphEventRef ReadFileTask;//����
    TWeakObjectPtr < AActor> _rootActor;
    TWeakObjectPtr<UWorld> _world;
    FString _filePath;

    void* _scene;
    FileMats _fileMats;
    FGraphEventArray _AllParseTasks;//���е�����

    AsyncDataStatic() : _rootActor(0), _scene(0)
    {

    }
    ~AsyncDataStatic()
    {

    }

    bool valid()const
    {
        MeshIO::FbxFullData* fulldata = (MeshIO::FbxFullData*)(_scene);
        if (!fulldata || fulldata->meshs.count < 1)return false;
        return true;
    }



    void FileLoadedAsync(FileIO::ImportFinishFun2 FinishFunc, FileIO::progressfun2 progressFunction)
    {
        FbxIOSetting ios;
        ios.ConvertToAxis = 2;//תΪ����Z���ϣ�����Mesh�����uv��ת��������UnFbx::FFbxImporter::BuildStaticMeshFromGeometry
        ios.ConvertToUnit = 2;
        ios.progress = progressFunction;
        loadFbxMemory(TCHAR_TO_UTF8(*_filePath), _scene, &ios);

        MeshIO::FbxFullData* fulldata = (MeshIO::FbxFullData*)(_scene);
        if (!fulldata || fulldata->meshs.count < 1)return;

        MeshIO::MeshVector meshs = fulldata->meshs;
        _fileMats.setMat_p(fulldata->mats);

        TArray<AActor*> meshActors;
        createFileActor(meshActors, meshs);
        if(ReadFileTask.IsValid())//Async
            FTaskGraphInterface::Get().WaitUntilTasksComplete(_AllParseTasks);
        freeFbxMemory(_scene);

        TWeakObjectPtr < AActor> root = _rootActor;
        //���ڵ��׹���
        if(root.IsValid())
        {
            FBox box = FileIO::GetActorBoundWithChildren(meshActors);
            FVector vCenter = box.GetCenter();
            vCenter.Z = box.Min.Z;
            root->SetActorLocation(vCenter);

            if (ReadFileTask.IsValid())//Async
            {
                FGraphEventRef AttachTask = FFunctionGraphTask::CreateAndDispatchWhenReady([root, meshActors]()
                    {
                        for (AActor* actor : meshActors)
                        {
                            if (root.IsValid())
                                actor->AttachToActor(root.Get(), FAttachmentTransformRules::KeepWorldTransform);
                        }
                    }, TStatId(), NULL, ENamedThreads::GameThread);
                FTaskGraphInterface::Get().WaitUntilTaskCompletes(AttachTask);
            }
            else
            {
                for (AActor* actor : meshActors)
                {
                    if (root.IsValid())
                        actor->AttachToActor(root.Get(), FAttachmentTransformRules::KeepWorldTransform);
                }
            }
            
        }
        if (FinishFunc)
            FinishFunc(_rootActor);

        //_rootActor->GetRootComponent()->SetMobility(EComponentMobility::Type::Static);

    }
    static AActor* CreateActor(TWeakObjectPtr<UWorld> world,bool bCreateRoot = false)
    {
        if (!world.IsValid())
            return nullptr;
        AActor* aactor = world->SpawnActor<AActor>();
        if (bCreateRoot)
        {
            USceneComponent* SceneComponent = NewObject<USceneComponent>(aactor, "SceneComponent");
            aactor->SetRootComponent(SceneComponent);
        }

        return aactor;
    }
};

TWeakObjectPtr<AActor> FileIO::LoadFileAsyncStatic(const FString& filePath, UWorld* world, ImportFinishFun2 FinishFunc /*= 0*/, progressfun2 progressFunction /*= 0*/)
{
    AActor* rltActor = nullptr;

    if (!IFileManager::Get().FileExists(*filePath))
        return rltActor;

    rltActor = AsyncDataStatic::CreateActor(world,true);
    FString fileName = FPaths::GetBaseFilename(filePath);


    TSharedPtr<AsyncDataStatic> asyncdata = MakeShared<AsyncDataStatic>();
    asyncdata->_filePath = filePath;
    asyncdata->_rootActor = rltActor;
    asyncdata->_world = world;

    asyncdata->ReadFileTask = FFunctionGraphTask::CreateAndDispatchWhenReady([asyncdata, FinishFunc, progressFunction]()
        {
            asyncdata->FileLoadedAsync(FinishFunc, progressFunction);
        }, TStatId(), NULL, ENamedThreads::AnyBackgroundThreadNormalTask);


    return rltActor;
}

TWeakObjectPtr<AActor> FileIO::LoadFileSyncStatic(const FString& filePath, UWorld* world, ImportFinishFun2 FinishFunc /*= 0*/, progressfun2 progressFunction /*= 0*/)
{
    AActor* rltActor = nullptr;

    if (!IFileManager::Get().FileExists(*filePath))
        return rltActor;

    rltActor = AsyncDataStatic::CreateActor(world, true);
    FString fileName = FPaths::GetBaseFilename(filePath);


    TSharedPtr<AsyncDataStatic> asyncdata = MakeShared<AsyncDataStatic>();
    asyncdata->_filePath = filePath;
    asyncdata->_rootActor = rltActor;
    asyncdata->_world = world;
    asyncdata->FileLoadedAsync(FinishFunc, progressFunction);
    return rltActor;
}
