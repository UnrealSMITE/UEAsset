﻿// Copyright 2021 ls Sun, Inc. All Rights Reserved.


#include "FileImporter.h"
#include "FbxImExPort/LoadFbxC.h"
#include <FbxImExPort/InterData.h>
#include <StaticMeshAttributes.h>
#include <ProceduralMeshComponent.h>
#include <IImageWrapperModule.h>
#include <IImageWrapper.h>
#include <loadImage.h>
#include <HAL/FileManager.h>

namespace FileIO
{

    static AActor* CreateActor(UWorld* world)
    {
        AActor* aactor = world->SpawnActor<AActor>();
        USceneComponent* SceneComponent = NewObject<USceneComponent>(aactor, "SceneComponent");
        aactor->SetRootComponent(SceneComponent);
        return aactor;
    }

void createFileActor(UWorld* world, AActor* parent, const MeshIO::MeshVector& meshs, FileMats& fileMats);

FileImporter::FileImporter():_scene(0)
{
}

FileImporter::FileImporter(const FString& filePath):_filePath(filePath),_scene(0)
{

}

FileImporter::~FileImporter()
{
    freeFbxMemory(_scene);
    _scene = 0;
}

void FileImporter::Load()
{
    if(!IFileManager::Get().FileExists(*_filePath))
        return;
    FbxIOSetting ios;
    ios.ConvertToAxis = 2;//转为右手Z向上，下面Mesh顶点和uv反转，参照了UnFbx::FFbxImporter::BuildStaticMeshFromGeometry
    ios.ConvertToUnit = 2;
    loadFbxMemory(TCHAR_TO_UTF8(*_filePath), _scene, &ios);
    if (!_scene || ios.pErrorReturn)
    {

    }
}



void FillMesh(UProceduralMeshComponent* ProMeshCmp, MeshIO::InterMesh* mesh, FileMats& fileMats)
{
    bool bCreateCollision = true;
    //////////////////////////////////////////////////////////////////////////
    ForSeperateMesh TotalVertex;
    TotalVertex.Init(mesh->pts);

    //////////////////////////////////////////////////////////////////////////
    TArray<FProcMeshTangent> Tangents;

    for (int i = 0; i < mesh->submeshCount; ++i)
    {
        const MeshIO::InterSubMesh& subMesh = mesh->psubmeshs[i];
        TArray<int32> Triangles;

        //////////////////////////////////////////////////////////////////////////
        ForSeperateMesh subMeshVertex;
        if (!TotalVertex.addMeshToSub(subMesh, subMeshVertex, Triangles))
            continue;
        ProMeshCmp->CreateMeshSection(i, subMeshVertex.Vertices, Triangles
            , subMeshVertex.Normals, subMeshVertex.UV0
            , subMeshVertex.VertexClrs, Tangents
            , bCreateCollision);
        //////////////////////////////////////////////////////////////////////////

        //ProMeshCmp->ContainsPhysicsTriMeshData(true);
        UMaterialInterface * pMat = fileMats.getMat(subMesh.MatID);
        ProMeshCmp->SetMaterial(i, pMat);
    }
}

void CreateUMesh(AActor* actor,MeshIO::InterMesh* mesh, FileMats& fileMats)
{
    if(!actor||!mesh||mesh->submeshCount<1)return;
    FName fname(UTF8_TO_TCHAR(mesh->strNode));
    UProceduralMeshComponent * ProMeshCmp = NewObject<UProceduralMeshComponent>(actor, fname);
    USceneComponent* parentComponent = actor->GetRootComponent();
    ProMeshCmp->AttachToComponent(parentComponent, FAttachmentTransformRules::SnapToTargetNotIncludingScale);
    ProMeshCmp->RegisterComponent();
    
    //FBX右手矩阵转左手矩阵参照UE4源码：FbxUtilsImport.cpp/FFbxDataConverter::ConvertMatrix
    {
        FPlane inx(mesh->matrix[0], -mesh->matrix[1], mesh->matrix[2], mesh->matrix[3]);
        FPlane iny(-mesh->matrix[4], mesh->matrix[5], -mesh->matrix[6], -mesh->matrix[7]);
        FPlane inz(mesh->matrix[8], -mesh->matrix[9], mesh->matrix[10], mesh->matrix[11]);
        FPlane inw(mesh->matrix[12], -mesh->matrix[13], mesh->matrix[14], mesh->matrix[15]);
        FMatrix fMat(inx, iny, inz, inw);
        FTransform transform(fMat);

        actor->AddActorLocalTransform(transform);
    }

    FillMesh(ProMeshCmp,mesh,fileMats);    
}



AActor* createAMesh(UWorld* world,MeshIO::InterMesh *mesh, FileMats& fileMats)
{
    AActor* actor = CreateActor(world);
    //actor->Rename(UTF8_TO_TCHAR(mesh->strNode));
    //创建自身
    {
        if (mesh->submeshCount > 0)
        {
            CreateUMesh(actor,mesh, fileMats);
        }
    }
    //创建子
    createFileActor(world,actor,mesh->vChildrend, fileMats);
    return actor;
}

void createFileActor(UWorld* world, AActor* parent,const MeshIO::MeshVector& meshs,FileMats& fileMats)
{
    for (int i=0;i<meshs.count;++i)
    {
        MeshIO::InterMesh* mesh = meshs.pMeshs[i];
        AActor*pchild = createAMesh(world,mesh, fileMats);
        pchild->AttachToActor(parent, FAttachmentTransformRules::KeepRelativeTransform);
    }
}

AActor* FileImporter::MakeAsset(UWorld* world)
{
    MeshIO::FbxFullData *fulldata = (MeshIO::FbxFullData*)(_scene);
    if(!fulldata || fulldata->meshs.count<1)return nullptr;
    FileMats fileMats(fulldata->mats);
    

    AActor* actor = CreateActor(world);
    FString fileName = FPaths::GetBaseFilename(_filePath);
    //actor->Rename(*fileName);
    createFileActor(world,actor, fulldata->meshs, fileMats);
    //FRotator ro;
    //ro.Roll = -90.0f;
    //actor->AddActorLocalRotation(ro);
    //actor->SetActorRelativeScale3D(FVector(100,-100,100));
    return actor;
}
}
