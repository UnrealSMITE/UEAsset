﻿// Copyright 2021 ls Sun, Inc. All Rights Reserved.


#include "FileImporterAsync.h"
#include <HAL/FileManager.h>
namespace FileIO
{
    class AsyncData
    {
        AActor* GameThreadCreateActor(MeshIO::InterMesh* mesh)
        {
            AActor* pActorCreated = 0;
            TWeakObjectPtr<UWorld> world = _world;

            FGraphEventRef task = FFunctionGraphTask::CreateAndDispatchWhenReady([world, &pActorCreated, mesh]()
                {
                    bool bHaveMeshComponent = mesh->psubmeshs > 0;
                    pActorCreated = CreateActor(world, !bHaveMeshComponent);

                    FName fname(UTF8_TO_TCHAR(mesh->strNode));
                    //如果有mesh则创建组件
                    if (bHaveMeshComponent)
                    {
                        //FBX右手矩阵转左手矩阵参照UE4源码：FbxUtilsImport.cpp/FFbxDataConverter::ConvertMatrix
                        //{
                        FPlane inx(mesh->matrix[0], -mesh->matrix[1], mesh->matrix[2], mesh->matrix[3]);
                        FPlane iny(-mesh->matrix[4], mesh->matrix[5], -mesh->matrix[6], -mesh->matrix[7]);
                        FPlane inz(mesh->matrix[8], -mesh->matrix[9], mesh->matrix[10], mesh->matrix[11]);
                        FPlane inw(mesh->matrix[12], -mesh->matrix[13], mesh->matrix[14], mesh->matrix[15]);
                        FMatrix fMat(inx, iny, inz, inw);
                        FTransform transform(fMat);

                        //}

                        UProceduralMeshComponent* ProMeshCmp = NewObject<UProceduralMeshComponent>(pActorCreated, fname);
                        USceneComponent* parentComponent = pActorCreated->GetRootComponent();
                        if (parentComponent)
                        {
                            ProMeshCmp->AttachToComponent(parentComponent, FAttachmentTransformRules::KeepRelativeTransform);
                        }
                        else
                        {
                            pActorCreated->SetRootComponent(ProMeshCmp);
                        }
                        ProMeshCmp->RegisterComponent();
                        pActorCreated->SetActorTransform(transform);

                    }
                }, TStatId(), NULL, ENamedThreads::GameThread);

            FTaskGraphInterface::Get().WaitUntilTaskCompletes(task);
            return pActorCreated;
        }

        static void GameThreadSetMeshMat(UProceduralMeshComponent* ProMeshCmp, int i, UMaterialInterface* pMat)
        {
            FFunctionGraphTask::CreateAndDispatchWhenReady([ProMeshCmp, i, pMat]()
                {
                    ProMeshCmp->SetMaterial(i, pMat);
                }, TStatId(), NULL, ENamedThreads::GameThread);
        }

        void createFileActor(TArray<AActor*>& meshActors, const MeshIO::MeshVector& meshs)
        {
            for (int i = 0; i < meshs.count; ++i)
            {
                MeshIO::InterMesh* mesh = meshs.pMeshs[i];
                AActor* pchild = createAMesh(mesh);
                meshActors.Add(pchild);
            }
        }
        AActor* createAMesh(MeshIO::InterMesh* mesh)
        {
            AActor* actor = GameThreadCreateActor(mesh);
            //actor->Rename(UTF8_TO_TCHAR(mesh->strNode));
            //创建自身
            {
                if (mesh->submeshCount > 0)
                {
                    CreateUMesh(actor, mesh);
                }
            }
            //创建子
            TArray<AActor*> children;
            createFileActor(children, mesh->vChildrend);

            FGraphEventRef AttachTask = FFunctionGraphTask::CreateAndDispatchWhenReady([actor, children]()
                {
                    for (AActor* child : children)
                    {
                        child->AttachToActor(actor, FAttachmentTransformRules::KeepWorldTransform);
                    }
                }, TStatId(), NULL, ENamedThreads::GameThread);

            _AllParseTasks.Add(AttachTask);

            return actor;
        }

        void CreateUMesh(TWeakObjectPtr<AActor> weakActor, MeshIO::InterMesh* mesh)
        {
            AActor* actor = weakActor.Get();
            if (!actor || !mesh || mesh->submeshCount < 1)return;

            UProceduralMeshComponent* ProMeshCmp = Cast<UProceduralMeshComponent>(actor->GetComponentByClass(UProceduralMeshComponent::StaticClass()));
            if (!ProMeshCmp)return;
            //////////////////////////////////////////////////////////////////////////
            ForSeperateMesh TotalVertex;
            TotalVertex.Init(mesh->pts);
            //////////////////////////////////////////////////////////////////////////
            _AllParseTasks.Reserve(mesh->submeshCount * 2);
            for (int i = 0; i < mesh->submeshCount; ++i)
            {
                const MeshIO::InterSubMesh& subMesh = mesh->psubmeshs[i];
                TArray<int32> Triangles;
                //////////////////////////////////////////////////////////////////////////
                TSharedPtr<ForSeperateMesh> subMeshVertex = MakeShared<ForSeperateMesh>();
                if (!TotalVertex.addMeshToSub(subMesh, *subMeshVertex, Triangles))
                    continue;
                FGraphEventRef task1 = FFunctionGraphTask::CreateAndDispatchWhenReady([ProMeshCmp, i, subMeshVertex, Triangles]()
                    {
                        bool bCreateCollision = true;
                        TArray<FProcMeshTangent> Tangents;
                        ProMeshCmp->CreateMeshSection(i, subMeshVertex->Vertices, Triangles
                            , subMeshVertex->Normals, subMeshVertex->UV0
                            , subMeshVertex->VertexClrs, Tangents
                            , bCreateCollision);
                    }, TStatId(), NULL, ENamedThreads::GameThread);
                _AllParseTasks.Add(task1);

                //////////////////////////////////////////////////////////////////////////
                int nMatId = subMesh.MatID;
                FileMats* fileMats = &_fileMats;
                FGraphEventRef task2 = FFunctionGraphTask::CreateAndDispatchWhenReady([ProMeshCmp, i, nMatId, fileMats]()
                    {
                        UMaterialInterface* pMat = fileMats->getMat(nMatId);
                        GameThreadSetMeshMat(ProMeshCmp, i, pMat);
                    }, TStatId(), NULL, ENamedThreads::AnyBackgroundThreadNormalTask);

                _AllParseTasks.Add(task2);
            }
        }


    public:
        FGraphEventRef ReadFileTask;//任务
        TWeakObjectPtr < AActor> _rootActor;
        TWeakObjectPtr<UWorld> _world;
        FString _filePath;

        void* _scene;
        FileMats _fileMats;
        FGraphEventArray _AllParseTasks;//所有的任务

        AsyncData() : _rootActor(0), _scene(0)
        {

        }
        ~AsyncData()
        {

        }

        bool valid()const
        {
            MeshIO::FbxFullData* fulldata = (MeshIO::FbxFullData*)(_scene);
            if (!fulldata || fulldata->meshs.count < 1)return false;
            return true;
        }



        void FileLoadedAsync(FileIO::ImportFinishFun FinishFunc, FileIO::progressfun progressFunction)
        {
            FbxIOSetting ios;
            ios.ConvertToAxis = 2;//转为右手Z向上，下面Mesh顶点和uv反转，参照了UnFbx::FFbxImporter::BuildStaticMeshFromGeometry
            ios.ConvertToUnit = 2;
            ios.progress = progressFunction;
            loadFbxMemory(TCHAR_TO_UTF8(*_filePath), _scene, &ios);

            MeshIO::FbxFullData* fulldata = (MeshIO::FbxFullData*)(_scene);
            if (!fulldata || fulldata->meshs.count < 1)return;

            MeshIO::MeshVector meshs = fulldata->meshs;
            _fileMats.setMat_p(fulldata->mats);

            TArray<AActor*> meshActors;
            createFileActor(meshActors, meshs);
            FTaskGraphInterface::Get().WaitUntilTasksComplete(_AllParseTasks);
            freeFbxMemory(_scene);

            TWeakObjectPtr < AActor> root = _rootActor;
            //根节点归底归中
            if (root.IsValid())
            {
                FBox box = FileIO::GetActorBoundWithChildren(meshActors);
                FVector vCenter = box.GetCenter();
                vCenter.Z = box.Min.Z;
                root->SetActorLocation(vCenter);
                FGraphEventRef AttachTask = FFunctionGraphTask::CreateAndDispatchWhenReady([root, meshActors]()
                    {
                        for (AActor* actor : meshActors)
                        {
                            if (root.IsValid())
                                actor->AttachToActor(root.Get(), FAttachmentTransformRules::KeepWorldTransform);
                        }
                    }, TStatId(), NULL, ENamedThreads::GameThread);
                FTaskGraphInterface::Get().WaitUntilTaskCompletes(AttachTask);
            }
            if (FinishFunc)
                FinishFunc(_rootActor);

            //_rootActor->GetRootComponent()->SetMobility(EComponentMobility::Type::Static);

        }
        static AActor* CreateActor(TWeakObjectPtr<UWorld> world, bool bCreateRoot = false)
        {
            if (!world.IsValid())
                return nullptr;
            AActor* aactor = world->SpawnActor<AActor>();
            if (bCreateRoot)
            {
                USceneComponent* SceneComponent = NewObject<USceneComponent>(aactor, "SceneComponent");
                aactor->SetRootComponent(SceneComponent);
            }

            return aactor;
        }
    };

    TWeakObjectPtr<AActor> FileIO::LoadFileAsync(const FString& filePath, UWorld* world, ImportFinishFun FinishFunc /*= 0*/, progressfun progressFunction /*= 0*/)
    {
        AActor* rltActor = nullptr;

        if (!IFileManager::Get().FileExists(*filePath))
            return rltActor;

        rltActor = AsyncData::CreateActor(world, true);
        FString fileName = FPaths::GetBaseFilename(filePath);


        TSharedPtr<AsyncData> asyncdata = MakeShared<AsyncData>();
        asyncdata->_filePath = filePath;
        asyncdata->_rootActor = rltActor;
        asyncdata->_world = world;

        asyncdata->ReadFileTask = FFunctionGraphTask::CreateAndDispatchWhenReady([asyncdata, FinishFunc, progressFunction]()
            {
                asyncdata->FileLoadedAsync(FinishFunc, progressFunction);
            }, TStatId(), NULL, ENamedThreads::AnyBackgroundThreadNormalTask);


        return rltActor;
    }
}
