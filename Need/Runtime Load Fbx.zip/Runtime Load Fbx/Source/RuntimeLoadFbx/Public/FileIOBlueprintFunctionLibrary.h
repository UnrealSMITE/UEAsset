// Copyright 2021 ls Sun, Inc. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "Kismet/BlueprintFunctionLibrary.h"
#include "FileIOBlueprintFunctionLibrary.generated.h"

/**
 * 
 */
UCLASS()
class RUNTIMELOADFBX_API UFileIOBlueprintFunctionLibrary : public UBlueprintFunctionLibrary
{
	GENERATED_BODY()
public:

    UFUNCTION(BlueprintCallable, Category = "LoadFile|Async")
     static  AActor* LoadFileAsync2StaticMeshActor(const FString& filePath, UWorld* world);
    UFUNCTION(BlueprintCallable, Category = "LoadFile|Async")
    static  AActor* LoadFileAsync2ProceduralMeshActor(const FString& filePath, UWorld* world);

    UFUNCTION(BlueprintCallable, Category = "LoadFile|Sync")
    static  AActor* LoadFileSync2StaticMeshActor(const FString& filePath, UWorld* world);
    UFUNCTION(BlueprintCallable, Category = "LoadFile|Sync")
    static  AActor* LoadFileSync2ProceduralMeshActor(const FString& filePath, UWorld* world);

	UFUNCTION(BlueprintCallable, Category = "LoadFile|Focus")
	static  void FocusActor(AActor* actor);

};
