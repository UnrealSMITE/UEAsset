// Copyright 2021 ls Sun, Inc. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"

/**
 * 
 */
namespace FileIO
{

class FileImporter
{
public:
	FileImporter();
    FileImporter(const FString& filePath);
	~FileImporter();

    void Load();
    AActor* MakeAsset(UWorld *world);
protected:
    FString _filePath;
    void *_scene;
};
}

