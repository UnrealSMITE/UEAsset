// Copyright 2021 ls Sun, Inc. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include <Async/TaskGraphInterfaces.h>
#include <Materials/MaterialInterface.h>
#include <Materials/MaterialInstanceDynamic.h>
#include <ProceduralMeshComponent.h>

/**
 * 
 */

namespace FileIO
{
    typedef void(*progressfun)(float);
    typedef void(*ImportFinishFun)(TWeakObjectPtr<AActor>);
    RUNTIMELOADFBX_API TWeakObjectPtr<AActor> LoadFileAsync(const FString& filePath, UWorld* world, ImportFinishFun FinishFunc = 0, progressfun progressFunction = 0);
}
