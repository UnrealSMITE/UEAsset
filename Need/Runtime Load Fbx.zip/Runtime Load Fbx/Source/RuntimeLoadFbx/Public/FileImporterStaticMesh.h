// Copyright 2021 ls Sun, Inc. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include <Engine/StaticMesh.h>
/**
 * 
 */
namespace FileIO
{
    typedef void(*progressfun2)(float);
    typedef void(*ImportFinishFun2)(TWeakObjectPtr<AActor>);

    RUNTIMELOADFBX_API TWeakObjectPtr<AActor> LoadFileAsyncStatic(const FString& filePath, UWorld* world, ImportFinishFun2 FinishFunc = 0, progressfun2 progressFunction = 0);
    RUNTIMELOADFBX_API TWeakObjectPtr<AActor> LoadFileSyncStatic(const FString& filePath, UWorld* world, ImportFinishFun2 FinishFunc = 0, progressfun2 progressFunction = 0);

}