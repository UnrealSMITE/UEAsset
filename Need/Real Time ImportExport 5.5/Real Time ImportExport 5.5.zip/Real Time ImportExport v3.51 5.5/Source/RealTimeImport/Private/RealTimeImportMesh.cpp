// Copyright 2018-2020 David Romanski(Socke). All Rights Reserved.

#include "RealTimeImportMesh.h"


URealTimeImportMesh* URealTimeImportMesh::realTimeImportMesh;
URealTimeImportMesh::URealTimeImportMesh(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer) {
	realTimeImportMesh = this;

	
	STL = NewObject<URealTimeImportMeshSTL>(URealTimeImportMeshSTL::StaticClass());
	STL->AddToRoot();

	OBJ = NewObject<URealTimeImportMeshOBJ>(URealTimeImportMeshOBJ::StaticClass());
	OBJ->AddToRoot();

	FBX = NewObject<URealTimeImportMeshFBX>(URealTimeImportMeshFBX::StaticClass());
	FBX->AddToRoot();
}


URealTimeImportMesh* URealTimeImportMesh::getRealTimeImportMesh() {
	return realTimeImportMesh;
}

void URealTimeImportMesh::LoadMeshFile(ERTIMeshType fileType, ERTIDirectoryType directoryType, FString filePath, bool& success, FString& successMessage,
	TArray<FRTIModelStruct>& modelStructs,
	ERTICoordinateSystem coordinateSystem,
	bool calculateTangents,
	bool cacheTexture,
	bool autoDetectionNormalMap,
	bool useSRGB,
	bool createMipMaps,
	ERTIERGBFormat rgbFormat,
	URealTimeImportAsyncNodeLoadMesh* asyncNode) {

	//vertices.Empty();
	//normals.Empty();
	//UV0.Empty();
	modelStructs.Empty();

	FString dir;
	if (directoryType == ERTIDirectoryType::E_ad) {
		dir = FPaths::ConvertRelativePathToFull(filePath);
	}
	else {
		FString ProjectDir = FPaths::ProjectDir();
		dir = FPaths::ConvertRelativePathToFull(ProjectDir + filePath);
	}

	switch (fileType)
	{
	case ERTIMeshType::E_obj:

		OBJ->LoadOBJFile(
			dir,
			success,
			successMessage,
			modelStructs,
			coordinateSystem,
			calculateTangents,
			cacheTexture,
			autoDetectionNormalMap,
			useSRGB,
			createMipMaps,
			rgbFormat,
			asyncNode);

		break;
	case ERTIMeshType::E_fbx:
	case ERTIMeshType::E_fbxUV:

		FBX->LoadFBXFile(
			fileType,
			dir,
			success,
			successMessage,
			modelStructs,
			coordinateSystem,
			calculateTangents,
			cacheTexture,
			autoDetectionNormalMap,
			useSRGB,
			createMipMaps,
			rgbFormat,
			asyncNode);

		break;
	case ERTIMeshType::E_stl:
		TArray<uint8> stlFileData;
		if (!FFileHelper::LoadFileToArray(stlFileData, *dir)) {
			UE_LOG(LogTemp, Error, TEXT("RealTimeImportPlugin: Can't load file: %s"), *dir);
			success = false;
			successMessage = "Can't load file: " + dir;
			return;
		}

		if (stlFileData.Num() < 100) {
			UE_LOG(LogTemp, Error, TEXT("RealTimeImportPlugin: Can't load file (File corrupted): %s"), *dir);
			success = false;
			successMessage = "Can't load file (File corrupted): " + dir;
			return;
		}

		FString stlFileType = byteArrayToFString(stlFileData, 0, 5);

		//is ASCII or Binary type?
		if (stlFileType.Equals("solid")) {
			STL->LoadSTL_ASCIIFile(dir,
				stlFileData,
				coordinateSystem,
				success,
				successMessage,
				modelStructs,
				asyncNode);
		}
		else {
			STL->LoadSTL_BinaryFile(dir,
				stlFileData,
				coordinateSystem,
				success,
				successMessage,
				modelStructs,
				asyncNode);
		}


		break;
	}
	
}

FRTIModelStruct URealTimeImportMesh::makeModelStruct(FString name){
	return  URealTimeImportMesh::realTimeImportMesh->makeModelStructNonStatic(name);
}

FRTIModelStruct URealTimeImportMesh::makeModelStructNonStatic(FString name){
	FRTIModelStruct* model = new FRTIModelStruct();
	model->structID = FGuid::NewGuid().ToString();

	if (name.IsEmpty() == false) {
		model->name = name;
	}
	else {
		model->name = FGuid::NewGuid().ToString();
	}

	modelStructCache.Add(model->structID, model);
	return *model;
}

FRTIMeshStruct URealTimeImportMesh::makeMeshStruct(FString meshName, TArray<FVector> vertices, TArray<int32> triangles, TArray<FVector> normals,
	TArray<FVector2D> UV0, UPrimitiveComponent* materialComponent){
	

	FRTIMeshStruct meshStruct = FRTIMeshStruct();
	
	if (triangles.Num() == 0) {
		return meshStruct;
	}

	if (materialComponent != nullptr) {
		UMaterialInterface* material = materialComponent->GetMaterial(0);
		if (material != nullptr){
			UMaterialInstanceDynamic* dynamicMaterial = materialComponent->CreateDynamicMaterialInstance(0, material);
			if (dynamicMaterial != nullptr && dynamicMaterial->TextureParameterValues.Num() > 0) {
				FRTIMaterialStruct materialStruct = FRTIMaterialStruct();
				FString materialName;// = FGuid::NewGuid().ToString();
				dynamicMaterial->GetName(materialName);
				materialStruct.materialName = materialName;
				for (int32 i = 0; i < dynamicMaterial->TextureParameterValues.Num(); i++) {
					FTextureParameterValue textureValue = dynamicMaterial->TextureParameterValues[i];
					if (textureValue.ParameterValue != nullptr) {
						if (UTexture2D* texture2d = Cast<UTexture2D>(textureValue.ParameterValue)) {
							FRTITextureStruct textureStruct = FRTITextureStruct();
							textureStruct.texture = texture2d;
							FString textureName;// = FGuid::NewGuid().ToString();
							texture2d->GetName(textureName);
							textureStruct.textureName = textureName;
							materialStruct.textures.Add(textureName, textureStruct);
						}
					}
				}
				meshStruct.hasMaterialData = true;
				meshStruct.materialData = materialStruct;
			}
		}
	}



	if (meshName.IsEmpty() == false) {
		meshStruct.geometryName = meshName;
	}
	else {
		meshStruct.geometryName = FGuid::NewGuid().ToString();
	}
	
	meshStruct.vertices = vertices;
	meshStruct.triangles = triangles;
	meshStruct.normals = normals;
	meshStruct.UV0 = UV0;
	

	return meshStruct;
}

void URealTimeImportMesh::addMeshStructToModelStruct(FRTIModelStruct modelStruct, FRTIMeshStruct meshStruct){
	modelStruct.meshStructs.Add(meshStruct);

	if (URealTimeImportMesh::realTimeImportMesh->modelStructCache.Find(modelStruct.structID) != nullptr) {
		FRTIModelStruct* m = *URealTimeImportMesh::realTimeImportMesh->modelStructCache.Find(modelStruct.structID);
		m->meshStructs.Add(meshStruct);
	}
}

void URealTimeImportMesh::saveModelsToFile(UObject* WorldContextObject,UMaterial* exportMaterial,ERTICoordinateSystem coordinateSystem,
	ERTIMeshType fileType, ERTIDirectoryType directoryType, FString filePath,
	bool& success, FString& errorMessage, TArray<FRTIModelStruct> modelStructs){

	if (fileType == ERTIMeshType::E_obj) {
		URealTimeImportMesh::realTimeImportMesh->OBJ->saveModelsToFile(WorldContextObject,exportMaterial, coordinateSystem, directoryType, filePath, success, errorMessage, modelStructs);
	}
}


//Copy from the procedural mesh plugin. See UKismetProceduralMeshLibrary::CalculateTangentsForMesh.
void URealTimeImportMesh::calculateTangents(TMap<FVector, TArray<int32>>& overlappingVertices, const TArray<FVector>& Vertices, const TArray<int32>& Triangles, const TArray<FVector2D>& UVs, 
	TArray<FProcMeshTangent>& TangentsFull)
{
	// Number of triangles
	const int32 NumTris = Triangles.Num() / 3;
	// Number of verts
	const int32 NumVerts = Vertices.Num();

	// Map of vertex to triangles in Triangles array
	TMultiMap<int32, int32> VertToTriMap;
	// Map of vertex to triangles to consider for normal calculation
	TMultiMap<int32, int32> VertToTriSmoothMap;

	// Normal/tangents for each face
	TArray<FVector> FaceTangentX, FaceTangentY, FaceTangentZ;
	FaceTangentX.AddUninitialized(NumTris);
	FaceTangentY.AddUninitialized(NumTris);
	FaceTangentZ.AddUninitialized(NumTris);

	// Iterate over triangles
	for (int TriIdx = 0; TriIdx < NumTris; TriIdx++)
	{
		int32 CornerIndex[3];
		FVector P[3];

		for (int32 CornerIdx = 0; CornerIdx < 3; CornerIdx++)
		{
			// Find vert index (clamped within range)
			int32 VertIndex = FMath::Min(Triangles[(TriIdx * 3) + CornerIdx], NumVerts - 1);

			CornerIndex[CornerIdx] = VertIndex;
			P[CornerIdx] = Vertices[VertIndex];

			// Find/add this vert to index buffer
			//RealtimePlugin This part replaced with a map. Is much faster
			TArray<int32> VertOverlaps = overlappingVertices.FindRef(Vertices[VertIndex]);


			// Remember which triangles map to this vert
			VertToTriMap.AddUnique(VertIndex, TriIdx);
			VertToTriSmoothMap.AddUnique(VertIndex, TriIdx);

			// Also update map of triangles that 'overlap' this vert (ie don't match UV, but do match smoothing) and should be considered when calculating normal
			for (int32 OverlapIdx = 0; OverlapIdx < VertOverlaps.Num(); OverlapIdx++)
			{
				// For each vert we overlap..
				int32 OverlapVertIdx = VertOverlaps[OverlapIdx];

				// Add this triangle to that vert
				VertToTriSmoothMap.AddUnique(OverlapVertIdx, TriIdx);

				// And add all of its triangles to us
				TArray<int32> OverlapTris;
				VertToTriMap.MultiFind(OverlapVertIdx, OverlapTris);
				for (int32 OverlapTriIdx = 0; OverlapTriIdx < OverlapTris.Num(); OverlapTriIdx++)
				{
					VertToTriSmoothMap.AddUnique(VertIndex, OverlapTris[OverlapTriIdx]);
				}
			}
		}

		// Calculate triangle edge vectors and normal
		const FVector Edge21 = P[1] - P[2];
		const FVector Edge20 = P[0] - P[2];
		const FVector TriNormal = (Edge21 ^ Edge20).GetSafeNormal();

		// If we have UVs, use those to calc 
		if (UVs.Num() == Vertices.Num())
		{
			const FVector2D T1 = UVs[CornerIndex[0]];
			const FVector2D T2 = UVs[CornerIndex[1]];
			const FVector2D T3 = UVs[CornerIndex[2]];

			FMatrix	ParameterToLocal(
				FPlane(P[1].X - P[0].X, P[1].Y - P[0].Y, P[1].Z - P[0].Z, 0),
				FPlane(P[2].X - P[0].X, P[2].Y - P[0].Y, P[2].Z - P[0].Z, 0),
				FPlane(P[0].X, P[0].Y, P[0].Z, 0),
				FPlane(0, 0, 0, 1)
			);

			FMatrix ParameterToTexture(
				FPlane(T2.X - T1.X, T2.Y - T1.Y, 0, 0),
				FPlane(T3.X - T1.X, T3.Y - T1.Y, 0, 0),
				FPlane(T1.X, T1.Y, 1, 0),
				FPlane(0, 0, 0, 1)
			);

			// Use InverseSlow to catch singular matrices.  Inverse can miss this sometimes.
			const FMatrix TextureToLocal = ParameterToTexture.Inverse() * ParameterToLocal;

			FaceTangentX[TriIdx] = FVector(TextureToLocal.TransformVector(FVector(1, 0, 0)).GetSafeNormal());
			FaceTangentY[TriIdx] = FVector(TextureToLocal.TransformVector(FVector(0, 1, 0)).GetSafeNormal());
		}
		else
		{
			FaceTangentX[TriIdx] = Edge20.GetSafeNormal();
			FaceTangentY[TriIdx] = (FaceTangentX[TriIdx] ^ TriNormal).GetSafeNormal();
		}

		FaceTangentZ[TriIdx] = TriNormal;
	}


	// Arrays to accumulate tangents into
	TArray<FVector> VertexTangentXSum, VertexTangentYSum, VertexTangentZSum;
	VertexTangentXSum.AddZeroed(NumVerts);
	VertexTangentYSum.AddZeroed(NumVerts);
	VertexTangentZSum.AddZeroed(NumVerts);

	// For each vertex..
	for (int VertxIdx = 0; VertxIdx < Vertices.Num(); VertxIdx++)
	{
		// Find relevant triangles for normal
		TArray<int32> SmoothTris;
		VertToTriSmoothMap.MultiFind(VertxIdx, SmoothTris);

		for (int i = 0; i < SmoothTris.Num(); i++)
		{
			int32 TriIdx = SmoothTris[i];
			VertexTangentZSum[VertxIdx] += FaceTangentZ[TriIdx];
		}

		// Find relevant triangles for tangents
		TArray<int32> TangentTris;
		VertToTriMap.MultiFind(VertxIdx, TangentTris);

		for (int i = 0; i < TangentTris.Num(); i++)
		{
			int32 TriIdx = TangentTris[i];
			VertexTangentXSum[VertxIdx] += FaceTangentX[TriIdx];
			VertexTangentYSum[VertxIdx] += FaceTangentY[TriIdx];
		}
	}

	// Finally, normalize tangents and build output arrays
	TArray<FProcMeshTangent> Tangents;
	Tangents.AddUninitialized(NumVerts);

	for (int VertxIdx = 0; VertxIdx < NumVerts; VertxIdx++)
	{
		FVector& TangentX = VertexTangentXSum[VertxIdx];
		FVector& TangentY = VertexTangentYSum[VertxIdx];
		FVector& TangentZ = VertexTangentZSum[VertxIdx];

		TangentX.Normalize();
		TangentZ.Normalize();

		// Use Gram-Schmidt orthogonalization to make sure X is orth with Z
		TangentX -= TangentZ * (TangentZ | TangentX);
		TangentX.Normalize();

		// See if we need to flip TangentY when generating from cross product
		const bool bFlipBitangent = ((TangentZ ^ TangentX) | TangentY) < 0.f;

		Tangents[VertxIdx] = FProcMeshTangent((FVector)TangentX, bFlipBitangent);
	}

	TangentsFull.Append(Tangents);
	Tangents.Empty();
}

uint32 URealTimeImportMesh::byteArrayToInt32(TArray<uint8>& data, uint32 start){
	uint32 val = 0;
	FMemory::Memcpy(&val, data.GetData() + start, sizeof(val));

	return val;
}

int64 URealTimeImportMesh::byteArrayToInt64(TArray<uint8>& data, uint32 start) {
	int64 val = 0;
	FMemory::Memcpy(&val, data.GetData() + start, sizeof(val));

	return val;
}

TArray<int32> URealTimeImportMesh::byteArrayToInt32Tarray(TArray<uint8>& data, uint32 start, uint32 size){
	TArray<int32> a;
	a.AddUninitialized(size);
	FMemory::Memcpy(a.GetData(), data.GetData() + start, size);
	return a;
}


FString URealTimeImportMesh::byteArrayToFString(TArray<uint8>& data, uint32 start, uint32 size){

	TArray<uint8> fbxCheck;
	fbxCheck.AddUninitialized(size);
	FMemory::Memcpy(fbxCheck.GetData(), data.GetData()+start, size);
	fbxCheck.Add(0x00);// null-terminator

	return FString(UTF8_TO_TCHAR(fbxCheck.GetData()));
}

TArray<uint8> URealTimeImportMesh::cutByteArray(TArray<uint8>& original, uint32 start, uint32 size){
	TArray<uint8> copy;
	copy.AddUninitialized(size);
	FMemory::Memcpy(copy.GetData(), original.GetData() + start, size);
	return copy;
}

double URealTimeImportMesh::parseBytesToDouble(TArray<uint8>& data, uint32 start){

	double val = 0.0;
	FMemory::Memcpy(&val, data.GetData()+start, sizeof(val));

	return val;
}

float URealTimeImportMesh::parseBytesToFloat(TArray<uint8>& data, uint32 start){
	float val = 0.0;
	FMemory::Memcpy(&val, data.GetData() + start, sizeof(val));

	return val;
}

int32 URealTimeImportMesh::parseBytesToInt32(TArray<uint8>& data, uint32 start){
	int32 val = 0;
	FMemory::Memcpy(&val, data.GetData() + start, sizeof(val));

	return val;
}

//void URealTimeImportMesh::cacheModelStruct(FRTIModelStruct* modelStruct){
//	if (modelStruct == nullptr) {
//		return;
//	}
//
//	if (IsInGameThread()) {
//		modelStructsMap.Add(modelStruct->modelID, modelStruct);
//	}
//	else {
//		AsyncTask(ENamedThreads::GameThread, [modelStruct]() {
//			URealTimeImportMesh::getRealTimeImportMesh()->modelStructsMap.Add(modelStruct->modelID, modelStruct);
//		});
//	}
//	
//}



void URealTimeImportMesh::breakMeshStruct(FRTIMeshStruct meshStruct,
	FString& geometryName,
	TArray<int32>& triangles,
	TArray<FVector>& vertices,
	TArray<FVector>& normals,
	TArray<FVector2D>& UV0,
	TArray<FLinearColor>& vertexColors,
	TArray<FProcMeshTangent>& tangents,
	FRTIMaterialStruct& materialStruct) {

	geometryName = meshStruct.geometryName;
	triangles = meshStruct.triangles;
	vertices = meshStruct.vertices;
	normals = meshStruct.normals;
	UV0 = meshStruct.UV0;
	vertexColors = meshStruct.vertexColors;
	tangents = meshStruct.tangents;
	materialStruct = meshStruct.materialData;
}


void URealTimeImportMesh::breakMaterialStruct(FRTIMaterialStruct materialData,
	bool& hasTexture,
	FString& materialName,
	FString& textureName,
	TArray<FRTITextureStruct>& textures,
	FColor& ambient,
	FColor& diffuse,
	FColor& specular,
	FColor& emissive,
	FColor& transparent,
	FColor& reflection,
	float& specularExponent,
	float& dissolved,
	float& dissolvedInverted,
	float& emissiveFactor,
	float& ambientFactor,
	float& diffuseFactor,
	float& bumpFactor,
	float& transparencyFactor,
	float& displacementFactor,
	float& vectorDisplacementFactor,
	float& specularFactor,
	float& shininessExponent,
	float& reflectionFactor) {

	textures.Empty();

	hasTexture = !materialData.isEmpty;
	materialName = materialData.materialName;
	textureName = materialData.textureName;
	materialData.textures.GenerateValueArray(textures);

	ambient = materialData.ambient;
	diffuse = materialData.diffuse;
	specular = materialData.specular;
	emissive = materialData.emissive;
	transparent = materialData.transparent;
	reflection = materialData.reflection;
	specularExponent = materialData.specularExponent;
	dissolved = materialData.dissolved;
	dissolvedInverted = materialData.dissolvedInverted;
	emissiveFactor = materialData.emissiveFactor;
	ambientFactor = materialData.ambientFactor;
	diffuseFactor = materialData.diffuseFactor;
	bumpFactor = materialData.bumpFactor;
	transparencyFactor = materialData.transparencyFactor;
	displacementFactor = materialData.displacementFactor;
	vectorDisplacementFactor = materialData.vectorDisplacementFactor;
	specularFactor = materialData.specularFactor;
	shininessExponent = materialData.shininessExponent;
	reflectionFactor = materialData.reflectionFactor;

}


void URealTimeImportMesh::breakTextureStruct(FRTITextureStruct textureData, FString& textureName, UTexture2D*& texture, ERTITextureType& textureType) {
	textureName = textureData.textureName;
	texture = textureData.texture;
	textureType = textureData.textureType;
}

void URealTimeImportMesh::breakModelStruct(FRTIModelStruct modelStruct,
	int64& modelID,FString& name, FTransform& relativeTransform, TArray<FRTIMeshStruct>& meshStructs, 
	bool& hasParent, int64& parentModelID, TArray<int64>& childrenModelIDs,ERTIModelType& modelType) {

	meshStructs.Empty();
	childrenModelIDs.Empty();

	modelID = modelStruct.modelID;
	meshStructs = modelStruct.meshStructs;
	name = modelStruct.name;
	relativeTransform = modelStruct.relativeTransform;
	parentModelID = modelStruct.parent;
	childrenModelIDs = modelStruct.children;
	modelType = modelStruct.modelType;

	if (parentModelID == -1) {
		hasParent = false;
	}
	else {
		hasParent = true;
	}

}

void URealTimeImportMesh::triangulateFace(int32& triangulatedFacesCount, TArray<int32>& triangles, TArray<int32>& indeces, TArray<FVector>& vertices, ERTICoordinateSystem coordinateSystem){

	//TMap<FVector3f, int32> verticesIndexConnection;
	TMap<FVector, int32> triangleIndexByVertexMap;
	TArray<FVector> faceVertices;
	faceVertices.AddUninitialized(indeces.Num());
	//TArray<FVector> Points;
	//Points.AddUninitialized(indeces.Num());
	for (int32 i = 0; i < indeces.Num(); i++){
		//faceVertices[i] = vertices[indeces[i]];
		FVector v = vertices[indeces[i]];
		faceVertices[i] = FVector(v.X, v.Z, v.Y);
		//Points[i] = faceVertices[i];
		//verticesIndexConnection.Add((FVector3f)Points[i],indeces[i]);
		triangleIndexByVertexMap.Add(faceVertices[i], indeces[i]);
	}

	//normalize by Newell's Method. 
	FVector allFaceVerticesNormalizedVector = FVector::ZeroVector;
	FVector v1;
	FVector v2; 
	for (int32 i = 0; i < faceVertices.Num(); i++){

		if ((i + 1) == faceVertices.Num()) {
			v1 = faceVertices[i];
			v2 = faceVertices[0];
		}
		else {
			v1 = faceVertices[i];
			v2 = faceVertices[i + 1];
		}

		allFaceVerticesNormalizedVector.X += (v2.Y - v1.Y) * (v2.Z + v1.Z);
		allFaceVerticesNormalizedVector.Y += (v2.Z - v1.Z) * (v2.X + v1.X);
		allFaceVerticesNormalizedVector.Z += (v2.X - v1.X) * (v2.Y + v1.Y);
	}
	allFaceVerticesNormalizedVector.Normalize();

	bool defaultTriangulation = true;

	//check whether normal tringulation is sufficient or whether we need to use cut tringulation
	int8 lastVerticesBuildDirection = 0; // 1 = right, -1 left
	for (int32 i = 0; i < faceVertices.Num(); i++) {
		int32 indexPrev = i - 1;
		int32 indexCenter = i;
		int32 indexNext = i + 1;
		if (indexPrev < 0) {
			indexPrev = faceVertices.Num() - 1;
		}
		if (indexNext == faceVertices.Num()) {
			indexNext = 0;
		}

		FVector vectorPrev = faceVertices[indexPrev];
		FVector vectorCenter = faceVertices[indexCenter];
		FVector vectorNext = faceVertices[indexNext];

		int8 verticesBuildDirection = getVerticesDirection(faceVertices, vectorPrev, vectorCenter, vectorNext, allFaceVerticesNormalizedVector);

		if (verticesBuildDirection == 0) {
			continue;
		}
		if (lastVerticesBuildDirection == 0) {
			lastVerticesBuildDirection = verticesBuildDirection;
		}
		if (lastVerticesBuildDirection != verticesBuildDirection) {
			defaultTriangulation = false;
			break;
		}
	}



	if (defaultTriangulation) {
		if (coordinateSystem == ERTICoordinateSystem::E_RightHanded) {
			for (int32 k = 1; k < indeces.Num() - 1; k++) {
				triangles.Add(indeces[k]);
				triangles.Add(indeces[k + 1]);
				triangles.Add(indeces[0]);
			}
		}
		else {
			for (int32 k = 1; k < indeces.Num() - 1; k++) {
				triangles.Add(indeces[k + 1]);
				triangles.Add(indeces[k]);
				triangles.Add(indeces[0]);
			}
		}
		return;
	}

	triangulatedFacesCount++;

	/*** unreal triangualtion from GeomTools.h does not work ***/

	//FRTIClipSMPolygon InPoly(indeces.Num());
	////InPoly.FaceNormal = FVector(0, 0, 1);

	//const bool bHasCorrectWinding = IsPolygonWindingCorrect(Points);
	//if (bHasCorrectWinding)
	//{
	//	for (int32 Index = 0; Index < Points.Num(); Index++)
	//	{
	//		FRTIClipSMVertex vertex;
	//		vertex.Pos = (FVector3f)Points[Index];
	//		InPoly.Vertices.Add(vertex);
	//	}
	//}
	//else
	//{
	//	for (int32 Index = Points.Num() - 1; Index >= 0; Index--)
	//	{
	//		FRTIClipSMVertex vertex;
	//		vertex.Pos = (FVector3f)Points[Index];
	//		InPoly.Vertices.Add(vertex);
	//	}
	//}

	//TArray<FRTIClipSMTriangle> OutTris;

	//bool bTriangulated = TriangulatePoly(OutTris, InPoly, true);

	//UE_LOG(LogTemp, Warning, TEXT("Triangulation: %i: %i"),InPoly.Vertices.Num(), OutTris.Num());


	//for (int32 i = 0; i < OutTris.Num(); i++){

	//	if (verticesIndexConnection.Find(OutTris[i].Vertices[0].Pos) != nullptr &&
	//		verticesIndexConnection.Find(OutTris[i].Vertices[1].Pos) != nullptr &&
	//		verticesIndexConnection.Find(OutTris[i].Vertices[2].Pos) != nullptr){

	//		int32 indexA = *verticesIndexConnection.Find(OutTris[i].Vertices[0].Pos);
	//		int32 indexB = *verticesIndexConnection.Find(OutTris[i].Vertices[1].Pos);
	//		int32 indexC = *verticesIndexConnection.Find(OutTris[i].Vertices[2].Pos);

	//		triangles.Add(indexB);
	//		triangles.Add(indexC);
	//		triangles.Add(indexA);
	//	}
	//	else {
	//		UE_LOG(LogTemp, Error, TEXT("Triangulation: error"));
	//	}
	//}



	//cut triangulation, ear clipping method
	//https://en.wikipedia.org/wiki/Polygon_triangulation 
	//https://www.geometrictools.com/Documentation/TriangulationByEarClipping.pdf 
	while( faceVertices.Num() > 2)	{

		int32 i = getEarIndex(faceVertices, allFaceVerticesNormalizedVector);

		if (i == -1) {
			i = isOverlapping(faceVertices, allFaceVerticesNormalizedVector);
		}

		if (i == -1) {
			break;
		}

		int32 indexPrev = i - 1;
		int32 indexCenter = i;
		int32 indexNext = i + 1;
		if (indexPrev < 0) {
			indexPrev = faceVertices.Num() - 1;
		}
		if (indexNext == faceVertices.Num()) {
			indexNext = 0;
		}

		FVector vectorPrev = faceVertices[indexPrev];
		FVector vectorCenter = faceVertices[indexCenter];
		FVector vectorNext = faceVertices[indexNext];


		//UE_LOG(LogTemp, Warning, TEXT("RealTimeImportPlugin: X: %f, Y: %f, Z: %f "), vectorCenter.X, vectorCenter.Z,vectorCenter.Y);
		//UE_LOG(LogTemp, Warning, TEXT("RealTimeImportPlugin: X: %f, Y: %f, Z: %f "), vectorNext.X, vectorNext.Z,vectorNext.Y);
		//UE_LOG(LogTemp, Warning, TEXT("RealTimeImportPlugin: X: %f, Y: %f, Z: %f "), vectorPrev.X, vectorPrev.Z,vectorPrev.Y);




		if (coordinateSystem == ERTICoordinateSystem::E_RightHanded) {
			for (int32 k = 1; k < indeces.Num() - 1; k++) {

				if (triangleIndexByVertexMap.Find(vectorCenter) != nullptr) {
					triangles.Add(*triangleIndexByVertexMap.Find(vectorCenter));
				}
				if (triangleIndexByVertexMap.Find(vectorNext) != nullptr) {
					triangles.Add(*triangleIndexByVertexMap.Find(vectorNext));
				}
				if (triangleIndexByVertexMap.Find(vectorPrev) != nullptr) {
					triangles.Add(*triangleIndexByVertexMap.Find(vectorPrev));
				}
			}
		}
		else {
			for (int32 k = 1; k < indeces.Num() - 1; k++) {

				if (triangleIndexByVertexMap.Find(vectorNext) != nullptr) {
					triangles.Add(*triangleIndexByVertexMap.Find(vectorNext));
				}
				if (triangleIndexByVertexMap.Find(vectorCenter) != nullptr) {
					triangles.Add(*triangleIndexByVertexMap.Find(vectorCenter));
				}
				if (triangleIndexByVertexMap.Find(vectorPrev) != nullptr) {
					triangles.Add(*triangleIndexByVertexMap.Find(vectorPrev));
				}
			}
		}


		faceVertices.RemoveAt(i);
	}

	triangleIndexByVertexMap.Empty();
	faceVertices.Empty();
}

int8 URealTimeImportMesh::getVerticesDirection(TArray<FVector>& faceVertices, FVector& vectorPrev,FVector& vectorCenter, FVector& vectorNext,
	FVector& allFaceVerticesNormalizedVector){

	FVector normalVectorCurrMinusPrev = vectorCenter - vectorPrev;
	normalVectorCurrMinusPrev.Normalize();
	FVector crossVector = FVector::CrossProduct((vectorNext - vectorPrev), normalVectorCurrMinusPrev);
	double dotProduct = FVector::DotProduct(crossVector, allFaceVerticesNormalizedVector);

	if (dotProduct > +0.001) {
		return 1;
	}
	if (dotProduct < -0.001) {
		return -1;
	}

	return 0;
}

int32 URealTimeImportMesh::getEarIndex(TArray<FVector>& faceVertices, FVector& allFaceVerticesNormalizedVector){

	double maxZone = DBL_MIN;
	int32 indexToReturn = -1;

	for (int32 i = 0; i < faceVertices.Num(); i++){

		int32 indexPrev = i - 1;
		int32 indexCenter = i;
		int32 indexNext = i + 1;
		if (indexPrev < 0) {
			indexPrev = faceVertices.Num() - 1;
		}
		if (indexNext == faceVertices.Num()) {
			indexNext = 0;
		}

		FVector vectorPrev = faceVertices[indexPrev];
		FVector vectorCenter = faceVertices[indexCenter];
		FVector vectorNext = faceVertices[indexNext];

		if( faceVertices.Num() == 3 || hasEar(i,indexPrev, indexCenter,indexNext,vectorPrev,vectorCenter, vectorNext, faceVertices, allFaceVerticesNormalizedVector)){

			FVector crossVector = FVector::CrossProduct((vectorCenter - vectorPrev), (vectorNext - vectorPrev));
			double zone = (crossVector.X * crossVector.X + crossVector.Y * crossVector.Y + crossVector.Z * crossVector.Z) / (double)4;

			if( maxZone < zone ){
				maxZone = zone;
				indexToReturn = i;
			}
		}
	}
	return indexToReturn;
}

bool URealTimeImportMesh::hasEar(int32 index,int32 indexPrev, int32 indexCenter,int32 indexNext, 
	FVector& vectorPrev,FVector& vectorCenter, FVector& vectorNext,
	TArray<FVector>& faceVertices, FVector& allFaceVerticesNormalizedVector){

	bool edge = false;

	int8 direction = getVerticesDirection(faceVertices, vectorPrev, vectorCenter, vectorNext, allFaceVerticesNormalizedVector);
	if (direction != 1) {
		return false;
	}

	double minPosDouble = DBL_EPSILON;//smallest positive number that can be added to 1 so that the result is distinguishable from 1

	for( size_t i = 0; i < faceVertices.Num(); i++ ){
		if (i != indexPrev && i != indexCenter && i != indexNext) {

			FVector vector1 = vectorNext - vectorPrev;
			FVector vector2 = vectorCenter - vectorPrev;
			FVector vector3 = faceVertices[i] - vectorPrev;

			double dotProduct1 = FVector::DotProduct(vector1, vector1);
			double dotProduct2 = FVector::DotProduct(vector1, vector2);
			double dotProduct3 = FVector::DotProduct(vector1, vector3);
			double dotProduct4 = FVector::DotProduct(vector2, vector2);
			double dotProduct5 = FVector::DotProduct(vector2, vector3);

			double a = dotProduct1 * dotProduct4 - dotProduct2 * dotProduct2;
			if (FMath::Abs(a) < minPosDouble) {
				return false;
			}

			a = 1. / a;

			double b = (dotProduct4 * dotProduct3 - dotProduct2 * dotProduct5) * a;
			double c = (dotProduct1 * dotProduct5 - dotProduct2 * dotProduct3) * a;

			if ((b >= 0.0) && (c >= 0.0) && (b + c < 1.0)) {
				return false;
			}
		}
	}

	return true;
}


int32 URealTimeImportMesh::isOverlapping(TArray<FVector>& faceVertices, FVector& allFaceVerticesNormalizedVector)
{

	for (int32 i = 0; i < faceVertices.Num(); i++){
		int32 indexPrev = i - 1;
		int32 indexCenter = i;
		int32 indexNext = i + 1;
		if (indexPrev < 0) {
			indexPrev = faceVertices.Num() - 1;
		}
		if (indexNext == faceVertices.Num()) {
			indexNext = 0;
		}

		FVector vectorPrev = faceVertices[indexPrev];
		FVector vectorCenter = faceVertices[indexCenter];
		FVector vectorNext = faceVertices[indexNext];

		if (getVerticesDirection(faceVertices, vectorPrev, vectorCenter, vectorNext, allFaceVerticesNormalizedVector) != 0) {
			continue;
		}

		FVector vectorNormalPrev = vectorCenter - vectorPrev;
		vectorNormalPrev.Normalize();
		FVector vectorNormalNext = vectorNext - vectorCenter;
		vectorNormalNext.Normalize();

		double dotProduct = FVector::DotProduct(vectorNormalPrev, vectorNormalNext);
		if (dotProduct < 0) {
			return i;
		}
	}
	return -1;
}


//bool URealTimeImportMesh::TriangulatePoly(TArray<FRTIClipSMTriangle>& OutTris, const FRTIClipSMPolygon& InPoly, bool bKeepColinearVertices)
//{
//	// Can't work if not enough verts for 1 triangle
//	if(InPoly.Vertices.Num() < 3)
//	{
//		// Return true because poly is already a tri
//		return true;
//	}
//
//	// Vertices of polygon in order - make a copy we are going to modify.
//	TArray<FRTIClipSMVertex> PolyVerts = InPoly.Vertices;
//
//	// Keep iterating while there are still vertices
//	while(true)
//	{
//		if (!bKeepColinearVertices)
//		{
//			// Cull redundant vertex edges from the polygon.
//			for (int32 VertexIndex = 0; VertexIndex < PolyVerts.Num(); VertexIndex++)
//			{
//				const int32 I0 = (VertexIndex + 0) % PolyVerts.Num();
//				const int32 I1 = (VertexIndex + 1) % PolyVerts.Num();
//				const int32 I2 = (VertexIndex + 2) % PolyVerts.Num();
//				if (AreEdgesMergeable(PolyVerts[I0], PolyVerts[I1], PolyVerts[I2]))
//				{
//					PolyVerts.RemoveAt(I1);
//					VertexIndex--;
//				}
//			}
//		}
//
//		if(PolyVerts.Num() < 3)
//		{
//			break;
//		}
//		else
//		{
//			// Look for an 'ear' triangle
//			bool bFoundEar = false;
//			for(int32 EarVertexIndex = 0;EarVertexIndex < PolyVerts.Num();EarVertexIndex++)
//			{
//				// Triangle is 'this' vert plus the one before and after it
//				const int32 AIndex = (EarVertexIndex==0) ? PolyVerts.Num()-1 : EarVertexIndex-1;
//				const int32 BIndex = EarVertexIndex;
//				const int32 CIndex = (EarVertexIndex+1)%PolyVerts.Num();
//
//				// Check that this vertex is convex (cross product must be positive)
//				const FVector3f ABEdge = PolyVerts[BIndex].Pos - PolyVerts[AIndex].Pos;
//				const FVector3f ACEdge = PolyVerts[CIndex].Pos - PolyVerts[AIndex].Pos;
//				const float TriangleDeterminant = (ABEdge ^ ACEdge) | (FVector3f)InPoly.FaceNormal;
//				if(TriangleDeterminant < 0.0f)
//				{
//					continue;
//				}
//
//				bool bFoundVertInside = false;
//				// Look through all verts before this in array to see if any are inside triangle
//				for(int32 VertexIndex = 0;VertexIndex < PolyVerts.Num();VertexIndex++)
//				{
//					if(	VertexIndex != AIndex && VertexIndex != BIndex && VertexIndex != CIndex &&
//						PointInTriangle(PolyVerts[AIndex].Pos, PolyVerts[BIndex].Pos, PolyVerts[CIndex].Pos, PolyVerts[VertexIndex].Pos) )
//					{
//						bFoundVertInside = true;
//						break;
//					}
//				}
//
//				// Triangle with no verts inside - its an 'ear'! 
//				if(!bFoundVertInside)
//				{
//					// Add to output list..
//					FRTIClipSMTriangle NewTri(0);
//					NewTri.CopyFace(InPoly);
//					NewTri.Vertices[0] = PolyVerts[AIndex];
//					NewTri.Vertices[1] = PolyVerts[BIndex];
//					NewTri.Vertices[2] = PolyVerts[CIndex];
//					OutTris.Add(NewTri);
//
//					// And remove vertex from polygon
//					PolyVerts.RemoveAt(EarVertexIndex);
//
//					bFoundEar = true;
//					break;
//				}
//			}
//
//			// If we couldn't find an 'ear' it indicates something is bad with this polygon - discard triangles and return.
//			if(!bFoundEar)
//			{
//				UE_LOG(LogTemp, Log, TEXT("Triangulation of poly failed."));
//				OutTris.Empty();
//				return false;
//			}
//		}
//	}
//
//	return true;
//}
//
///** Determines whether two edges may be merged. */
//bool URealTimeImportMesh::AreEdgesMergeable(
//	const FRTIClipSMVertex& V0,
//	const FRTIClipSMVertex& V1,
//	const FRTIClipSMVertex& V2
//)
//{
//	const FVector3f MergedEdgeVector = V2.Pos - V0.Pos;
//	const float MergedEdgeLengthSquared = MergedEdgeVector.SizeSquared();
//	if(MergedEdgeLengthSquared > UE_DELTA)
//	{
//		// Find the vertex closest to A1/B0 that is on the hypothetical merged edge formed by A0-B1.
//		const float IntermediateVertexEdgeFraction =
//			((V2.Pos - V0.Pos) | (V1.Pos - V0.Pos)) / MergedEdgeLengthSquared;
//		const FRTIClipSMVertex InterpolatedVertex = InterpolateVert(V0,V2,IntermediateVertexEdgeFraction);
//
//		// The edges are merge-able if the interpolated vertex is close enough to the intermediate vertex.
//		return VertsAreEqual(InterpolatedVertex,V1);
//	}
//	else
//	{
//		return true;
//	}
//}
//
///** Take two static mesh verts and interpolate all values between them */
//FRTIClipSMVertex URealTimeImportMesh::InterpolateVert(const FRTIClipSMVertex& V0, const FRTIClipSMVertex& V1, float Alpha)
//{
//	FRTIClipSMVertex Result;
//
//	// Handle dodgy alpha
//	if(FMath::IsNaN(Alpha) || !FMath::IsFinite(Alpha))
//	{
//		Result = V1;
//		return Result;
//	}
//
//	Result.Pos = FMath::Lerp(V0.Pos, V1.Pos, Alpha);
//	Result.TangentX = FMath::Lerp(V0.TangentX,V1.TangentX,Alpha);
//	Result.TangentY = FMath::Lerp(V0.TangentY,V1.TangentY,Alpha);
//	Result.TangentZ = FMath::Lerp(V0.TangentZ,V1.TangentZ,Alpha);
//	for(int32 i=0; i<8; i++)
//	{
//		Result.UVs[i] = FMath::Lerp(V0.UVs[i], V1.UVs[i], Alpha);
//	}
//
//	Result.Color.R = FMath::Clamp( FMath::TruncToInt(FMath::Lerp(float(V0.Color.R), float(V1.Color.R), Alpha)), 0, 255 );
//	Result.Color.G = FMath::Clamp( FMath::TruncToInt(FMath::Lerp(float(V0.Color.G), float(V1.Color.G), Alpha)), 0, 255 );
//	Result.Color.B = FMath::Clamp( FMath::TruncToInt(FMath::Lerp(float(V0.Color.B), float(V1.Color.B), Alpha)), 0, 255 );
//	Result.Color.A = FMath::Clamp( FMath::TruncToInt(FMath::Lerp(float(V0.Color.A), float(V1.Color.A), Alpha)), 0, 255 );
//	return Result;
//}
//
///** Compare all aspects of two verts of two triangles to see if they are the same. */
//bool URealTimeImportMesh::VertsAreEqual(const FRTIClipSMVertex& A,const FRTIClipSMVertex& B)
//{
//	if( !A.Pos.Equals(B.Pos, UE_THRESH_POINTS_ARE_SAME) )
//	{
//		return false;
//	}
//
//	if( !A.TangentX.Equals(B.TangentX, UE_THRESH_NORMALS_ARE_SAME) )
//	{
//		return false;
//	}
//
//	if( !A.TangentY.Equals(B.TangentY, UE_THRESH_NORMALS_ARE_SAME) )
//	{
//		return false;
//	}
//
//	if( !A.TangentZ.Equals(B.TangentZ, UE_THRESH_NORMALS_ARE_SAME) )
//	{
//		return false;
//	}
//
//	if( A.Color != B.Color )
//	{
//		return false;
//	}
//
//	for(int32 i=0; i<UE_ARRAY_COUNT(A.UVs); i++)
//	{
//		if( !A.UVs[i].Equals(B.UVs[i], 1.0f / 1024.0f) )
//		{
//			return false;
//		}
//	}
//
//	return true;
//}
//
///** Util to see if P lies within triangle created by A, B and C. */
//bool URealTimeImportMesh::PointInTriangle(const FVector3f& A, const FVector3f& B, const FVector3f& C, const FVector3f& P, const float InsideTriangleDotProductEpsilon)
//{
//	// Cross product indicates which 'side' of the vector the point is on
//	// If its on the same side as the remaining vert for all edges, then its inside.	
//	if( VectorsOnSameSide(B-A, P-A, C-A, InsideTriangleDotProductEpsilon) &&
//		VectorsOnSameSide(C-B, P-B, A-B, InsideTriangleDotProductEpsilon) &&
//		VectorsOnSameSide(A-C, P-C, B-C, InsideTriangleDotProductEpsilon) )
//	{
//		return true;
//	}
//	else
//	{
//		return false;
//	}
//}
//
///** Given three direction vectors, indicates if A and B are on the same 'side' of Vec. */
//bool URealTimeImportMesh::VectorsOnSameSide(const FVector3f& Vec, const FVector3f& A, const FVector3f& B, const float SameSideDotProductEpsilon)
//{
//	const FVector3f CrossA = Vec ^ A;
//	const FVector3f CrossB = Vec ^ B;
//	float DotWithEpsilon = SameSideDotProductEpsilon + ( CrossA | CrossB );
//	return !(DotWithEpsilon < 0.0f);
//}
//
//bool URealTimeImportMesh::IsPolygonWindingCorrect(const TArray<FVector>& Verts)
//{
//	// this will work only for convex polys, but we're assuming that all logged polygons are convex in the first place
//	if (Verts.Num() >= 3)
//	{
//		const FVector SurfaceNormal = FVector::CrossProduct(Verts[1] - Verts[0], Verts[2] - Verts[0]);
//		const float TestDot = FVector::DotProduct(SurfaceNormal, FVector(0, 0, 1));
//		return TestDot > 0;
//	}
//
//	return false;
//}